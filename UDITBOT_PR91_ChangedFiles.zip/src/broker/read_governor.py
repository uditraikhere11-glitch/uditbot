"""Durable, account-scoped admission control for Dhan GETs.

Coordinates processes using the same state directory; it cannot observe other
VMs, manual clients, or broker-side counters. Never caches successful evidence
and never sleeps in a watcher. Local denial is explicitly not a broker response.
"""
from contextlib import closing
from datetime import timezone
from email.utils import parsedate_to_datetime
import hashlib
import math
from pathlib import Path
import sqlite3
import time


class ReadDeferred(RuntimeError):
    def __init__(self, seconds, reason):
        self.seconds = max(1, math.ceil(seconds))
        super().__init__(f'Dhan GET deferred locally for {self.seconds}s: {reason}')


class ReadGovernor:
    # Conservative local GET budgets, not a claim about Dhan endpoint categories.
    LIMITS = ((60, 200), (3600, 800), (86400, 5500))

    def __init__(self, directory, account_id, clock=time.time):
        self.directory = Path(directory)
        self.account_id = str(account_id if account_id is not None else '').strip()
        key = hashlib.sha256(self.account_id.encode('utf-8')).hexdigest()[:24]
        self.path = self.directory / f'dhan-reads-{key}.sqlite3'
        self.clock = clock

    def _connect(self):
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        conn = sqlite3.connect(self.path, timeout=0.05)
        try:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.execute('PRAGMA synchronous=FULL')
            conn.execute('CREATE TABLE IF NOT EXISTS reads (at REAL NOT NULL)')
            conn.execute('CREATE INDEX IF NOT EXISTS reads_at ON reads(at)')
            conn.execute('CREATE TABLE IF NOT EXISTS cooldown (id INTEGER PRIMARY KEY, until REAL, strikes INTEGER)')
            conn.commit()
            return conn
        except Exception:
            conn.close()
            raise

    def _run_with_busy_retry(self, fn):
        # At most two 50ms lock waits; never stall supervision for seconds.
        for attempt in range(2):
            try:
                with closing(self._connect()) as conn, conn:
                    return fn(conn)
            except sqlite3.OperationalError as exc:
                if ('locked' in str(exc).lower() or 'busy' in str(exc).lower()) and attempt == 0:
                    time.sleep(0.01)
                    continue
                raise

    def admit(self, *, historical=False, priority='normal'):
        now = float(self.clock())

        def _op(conn):
            conn.execute('BEGIN IMMEDIATE')
            row = conn.execute('SELECT until FROM cooldown WHERE id=1').fetchone()
            if row and row[0] is not None and float(row[0]) > now:
                raise ReadDeferred(float(row[0]) - now, 'shared broker rate-limit cooldown')
            conn.execute('DELETE FROM reads WHERE at <= ?', (now - 86400,))
            prio = str(priority or 'normal').strip().lower()
            if prio not in ('low', 'normal', 'identity', 'urgent'):
                raise ValueError('Unsupported Dhan GET admission priority')
            for window, limit in self.LIMITS:
                # Reserve the final 5% of each *local* rolling allowance for
                # account/profile and funds identity probes and urgent
                # protection recovery. Ordinary supervision can no longer
                # exhaust all 800 hourly slots immediately before 17:00.
                # The full budget remains a hard cap for every priority.
                if historical and limit > 1:
                    ceiling = max(1, int(limit * 0.8))
                elif prio == 'low' and limit > 1:
                    ceiling = max(1, int(limit * 0.9))
                elif prio == 'normal' and limit > 1:
                    ceiling = max(1, int(limit * 0.95))
                else:
                    ceiling = limit
                count, oldest = conn.execute(
                    'SELECT COUNT(*), MIN(at) FROM reads WHERE at > ?',
                    (now - window,),
                ).fetchone()
                if count >= ceiling:
                    wait_sec = (float(oldest) + window - now) if oldest is not None else float(window)
                    raise ReadDeferred(wait_sec, 'local GET budget exhausted')
            conn.execute('INSERT INTO reads(at) VALUES (?)', (now,))

        return self._run_with_busy_retry(_op)

    def seconds_until_capacity(self, *, required=1, priority='routine'):
        """Read-only scheduling hint; never reserves or resets a GET admission.

        'routine' keeps a 20% reserve for startup identity, urgent protection
        and order recovery. 'urgent' may consume the full existing allowance.
        Concurrent clients can consume slots after this snapshot: admit() is
        still the final authoritative decision immediately before every GET.
        An unreadable governor must raise and the watcher must fail closed.
        """
        now = float(self.clock())
        need = int(required)
        if need < 1 or need > 40:
            raise ValueError("Invalid required read capacity")
        if priority not in ('routine', 'normal', 'low', 'urgent'):
            raise ValueError("Invalid watcher read priority")
        if not self.path.is_file():
            return 0.0
        # Do not modify the durable governor journal, even to prune old reads.
        with closing(sqlite3.connect(
            self.path.resolve().as_uri() + '?mode=ro',
            uri=True, timeout=0.10
        )) as conn:
            row = conn.execute('SELECT until FROM cooldown WHERE id=1').fetchone()
            delay = max(0.0, float(row[0]) - now) if row and row[0] else 0.0
            for window, limit in self.LIMITS:
                # The preflight and final Dhan GET admission must use
                # compatible ceilings. Watcher GET transport is NORMAL (95%),
                # not URGENT (100%). Keep the separate conservative routine
                # and low-priority reserve hints for their own callers.
                fraction = {'routine': 0.80, 'normal': 0.95, 'low': 0.90, 'urgent': 1.0}[priority]
                ceiling = max(1, int(limit * fraction))
                if need > ceiling:
                    raise ValueError("Read requirement exceeds watcher allowance")
                count = conn.execute(
                    'SELECT COUNT(*) FROM reads WHERE at > ?', (now - window,)
                ).fetchone()[0]
                excess = count + need - ceiling
                if excess <= 0:
                    continue
                # The excess-th oldest admission must age out before there
                # are enough slots for this full planned supervision pass.
                oldest_required = conn.execute(
                    'SELECT at FROM reads WHERE at > ? '
                    'ORDER BY at ASC LIMIT 1 OFFSET ?',
                    (now - window, excess - 1),
                ).fetchone()
                if oldest_required is None:
                    raise sqlite3.DatabaseError("Inconsistent governor read window")
                delay = max(delay, float(oldest_required[0]) + window - now + 0.01)
            return max(0.0, delay)

    def throttled(self, retry_after=None):
        now = float(self.clock())
        delay = None
        if isinstance(retry_after, (int, float)) and not isinstance(retry_after, bool):
            delay = float(retry_after)
        elif isinstance(retry_after, str):
            clean_ra = retry_after.strip()
            try:
                delay = float(clean_ra)
            except ValueError:
                try:
                    dt = parsedate_to_datetime(clean_ra)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    delay = dt.timestamp() - now
                except (ValueError, TypeError, OverflowError):
                    pass
        if delay is not None and (not math.isfinite(delay) or delay <= 0):
            delay = None

        def _op(conn):
            conn.execute('BEGIN IMMEDIATE')
            row = conn.execute('SELECT until, strikes FROM cooldown WHERE id=1').fetchone()
            # No header: increase quiet period for repeat throttle responses.
            prev_strikes = int(row[1]) if (row and row[1] is not None) else 0
            prev_until = float(row[0]) if (row and row[0] is not None) else 0.0
            strikes = min(prev_strikes + 1, 7)
            eff_delay = max(60 * 2 ** (strikes - 1), delay or 0)
            until = max(prev_until, now + eff_delay)
            conn.execute('INSERT OR REPLACE INTO cooldown VALUES (1, ?, ?)', (until, strikes))
            return until - now

        return self._run_with_busy_retry(_op)

    def record_success(self):
        """Resets accumulated strike backoff once cooldown has expired and a live GET succeeds."""
        now = float(self.clock())

        def _op(conn):
            conn.execute('BEGIN IMMEDIATE')
            row = conn.execute('SELECT until, strikes FROM cooldown WHERE id=1').fetchone()
            if row and row[1] and (row[0] is None or float(row[0]) <= now):
                conn.execute('UPDATE cooldown SET strikes=0 WHERE id=1')

        try:
            self._run_with_busy_retry(_op)
        except (OSError, sqlite3.Error):
            pass
