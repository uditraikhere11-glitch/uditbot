"""
DhanHQ API v2 Client Interface + V13 Audit-Hardened Execution-Safety Edition.
Handles:
- Yahoo Finance Primary Price Tunnel (`get_yahoo_quote_details`, `fetch_yahoo_ltp`) with strict
  2.0-second UTC source timestamp validation (`regularMarketTime`) measured against post-HTTP wall clock
  (`V12-15`), mandatory venue/exchange/symbol/delay metadata (`exchangeDataDelayedBy == 0`), BSE `.BO`
  delayed-quote rejection for LIVE, and F&O underlying substitution blocking.
  IMPORTANT LIMITATION: Yahoo Finance's published market-data terms state that its information is
  not intended for trading; this integration is an owner-selected price tunnel and NOT an approved
  exchange-grade live execution feed.
- Shared Dhan Access Token Coordinator integration (`fresh_token`, `force_login`, `read_token`) with
  automatic mtime-based shared token adoption (`V12-20`) and zero recursive order resubmission (`Section E`).
- Structural HTTP 5xx / 408 / network timeout classification as `UNKNOWN` (`uncertain_outcome=True`),
  preserving in-flight correlation IDs (`V12-12`: full 30-char correlation ID on Super Orders; `V12-13`).
- Structured broker collection reads (`BrokerReadList` vs `BrokerReadFailure`) distinguishing `OK_EMPTY`,
  `OK_RECORDS`, `FAILED`, `MALFORMED`, and `UNAVAILABLE` (`Safety Correction C`).
- Authoritative Forever OCO and Super Order verification contract (`evaluate_forever_oco_protection`,
  `verify_forever_leg_active`, `evaluate_super_order_protection`, `verify_super_order_legs_active`)
  with zero weak fallback overrides (`Safety Correction B`).
"""

import base64
import hashlib
import hmac
import json
import logging
import math
import os
import re
import struct
import threading
import time
from datetime import datetime, time as clock_time
from zoneinfo import ZoneInfo
from typing import Any, Dict, List, Optional, Tuple, Union
import requests
import sqlite3
from src.broker.yahoo_observer import (
    YAHOO_HTTP_TIMEOUT,
    YAHOO_HTTP_HEADERS,
    configure_yahoo_http,
    parse_yahoo_response,
)
from src.config import AppConfig
from src.engine.emergency_stop import EmergencyStopManager
from src.models import (
    BrokerReadFailure,
    BrokerReadList,
    BrokerReadStatus,
    OrderRequest,
    OrderType,
    ProductType,
    ProtectionLevels,
    ProtectionVerificationResult,
    ProtectionVerificationStatus,
    QuoteResult,
    TradingMode,
    TransactionType,
)
from src.engine.latency_monitor import GLOBAL_LATENCY_MONITOR
from src.engine.broker_handoff import BrokerMutationNotSubmitted
from src.broker.dhan_token import (
    force_login,
    fresh_token,
    is_token_error as _shared_is_token_error,
    read_token,
    write_token_atomic,
)

logger = logging.getLogger(__name__)

BASE_URL = "https://api.dhan.co/v2"
AUTH_URL = "https://auth.dhan.co/app/generateAccessToken"

# A failing Dhan authentication endpoint must not be called again on every
# two-second Protection Watcher poll. These bound retries without changing
# order submission, reconciliation policy, or emergency STOP.
ON_DEMAND_AUTH_FAILURE_COOLDOWN_SEC = 120.0
# Keep the freshly issued token for a short broker-side propagation window.
NEW_TOKEN_PROPAGATION_GRACE_SEC = 20.0
BROKER_AUTH_LOG_INTERVAL_SEC = 60.0
# Bound synchronous on-demand TOTP recovery inside ProtectionWatcher / runtime reads
# so a slow or contending auth.dhan.co endpoint cannot stall 2-second watcher polling
# for 52 seconds, while preserving (5, 25) x 2 attempts for scheduled/CLI force refreshes.
ON_DEMAND_TOTP_HTTP_TIMEOUT = (3.0, 8.0)
ON_DEMAND_TOTP_MAX_ATTEMPTS = 1
ON_DEMAND_LOCK_TIMEOUT_SEC = 1.0
MAX_HISTORICAL_TRADE_WINDOW_DAYS = 31
MAX_HISTORICAL_TRADE_PAGES = 20


def _mask_client_id(acct: object) -> str:
    raw = str(acct or "").strip()
    if not raw:
        return "UNSET"
    if len(raw) <= 4:
        return raw
    return f"***{raw[-4:]}"


YAHOO_CHART_URL = "https://query1.finance.yahoo.com/v8/finance/chart/{ticker}?interval=1d&range=1d"

VALID_NSE_EXCHANGES = frozenset({"NSI", "NSE", "NATIONAL STOCK EXCHANGE OF INDIA"})
VALID_BSE_EXCHANGES = frozenset({"BSE", "BOM", "BOMBAY STOCK EXCHANGE"})
ACTIVE_BROKER_ORDER_STATES = frozenset({"PENDING", "OPEN", "TRANSIT", "CONFIRM", "ACTIVE"})
TERMINAL_OR_INACTIVE_ORDER_STATES = frozenset({"REJECTED", "CANCELLED", "EXPIRED", "TRADED", "CLOSED", "TRIGGERED"})


def compute_totp(secret: str, digits: int = 6, period: int = 30) -> str:
    """
    Computes standard RFC 6238 TOTP code using purely Python standard library.
    Zero external dependencies required.
    """
    clean_secret = secret.strip().replace(" ", "").upper()
    pad = len(clean_secret) % 8
    if pad:
        clean_secret += "=" * (8 - pad)
    key = base64.b32decode(clean_secret, casefold=True)
    counter = int(time.time() // period)
    msg = struct.pack(">Q", counter)
    h = hmac.new(key, msg, hashlib.sha1).digest()
    offset = h[-1] & 0x0f
    chunk = h[offset : offset + 4]
    val = struct.unpack(">I", chunk)[0] & 0x7fffffff
    return str(val % (10 ** digits)).zfill(digits)


def verify_forever_oco_group(
    matching_rows: List[Dict[str, Any]],
    forever_order_id: str,
    expected_security_id: Optional[str] = None,
    expected_qty: Optional[int] = None,
    expected_sl_trigger: Optional[float] = None,
    expected_target_price: Optional[float] = None,
    tick_size: float = 0.05,
    expected_account_id: Optional[str] = None,
    expected_segment: Optional[str] = None,
    expected_product_type: Optional[str] = None,
) -> ProtectionVerificationResult:
    """
    Authoritative Forever OCO verification contract shared by `DhanClient`, `ProtectionWatcher`,
    and `StartupReconciliationGate`.
    - Deduplicates two-leg OCO pairs under `forever_order_id` so a 5-share OCO pair counts as 5, never 10.
    - Rejects TRADED, CLOSED, TRIGGERED, CANCELLED, REJECTED, EXPIRED, or missing statuses.
    - Validates account, securityId, exchangeSegment, productType, SELL side, quantities, and prices.
    """
    oid = str(forever_order_id or "").strip()
    if not oid:
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            reason="Missing forever_order_id",
        )

    if expected_segment:
        exp_seg_up = str(expected_segment).strip().upper()
        if exp_seg_up not in ("NSE_EQ", "BSE_EQ"):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                reason=f"Forever OCO cannot cover non-equity segment '{exp_seg_up}'",
            )

    if expected_product_type:
        exp_prod_up = str(expected_product_type).strip().upper()
        if exp_prod_up not in ("CNC", "MTF"):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                reason=f"Forever OCO cannot cover productType '{exp_prod_up}' (requires CNC or MTF)",
            )

    if not matching_rows:
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.UNVERIFIED,
            is_verified=False,
            is_terminal_or_invalid=False,
            group_id=oid,
            reason=f"Forever order {oid} absent from broker forever book",
        )

    tol = max(float(tick_size or 0.05), 0.05) + 1e-4
    has_sl_leg = False
    has_target_leg = False
    sl_qty = 0
    target_qty = 0
    observed_sec = ""
    observed_seg = ""
    observed_prod = ""
    observed_acct = ""
    observed_sl = 0.0
    observed_target = 0.0

    for row in matching_rows:
        if not isinstance(row, dict):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                reason=f"Forever order {oid} contains malformed non-dict record",
            )

        acct = str(row.get("dhanClientId") or "").strip()
        if acct:
            observed_acct = acct
            if expected_account_id and acct != str(expected_account_id).strip():
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    reason=f"Forever order {oid} account mismatch ({acct} != {expected_account_id})",
                )

        st = str(row.get("orderStatus") or "").strip().upper()
        if not st:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                reason=f"Forever order {oid} missing orderStatus",
            )
        if st in TERMINAL_OR_INACTIVE_ORDER_STATES:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                reason=f"Forever order {oid} is in terminal or inactive state: {st}",
            )
        if st not in ACTIVE_BROKER_ORDER_STATES:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                reason=f"Forever order {oid} is not in an active resting state: '{st}'",
            )

        sec = str(row.get("securityId") or "").strip()
        if not sec:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                reason=f"Forever order {oid} missing securityId",
            )
        observed_sec = sec
        if expected_security_id is not None and sec != str(expected_security_id).strip():
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                security_id=sec,
                reason=f"Forever order {oid} securityId mismatch ('{sec}' != '{expected_security_id}')",
            )

        row_seg = str(row.get("exchangeSegment") or "").strip().upper()
        if row_seg:
            observed_seg = row_seg
            if row_seg not in ("NSE_EQ", "BSE_EQ"):
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    reason=f"Forever order {oid} has unsupported exchangeSegment '{row_seg}'",
                )
            if expected_segment and row_seg != str(expected_segment).strip().upper():
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    reason=f"Forever order {oid} exchangeSegment mismatch ('{row_seg}' != '{expected_segment}')",
                )

        row_prod = str(row.get("productType") or "").strip().upper()
        if row_prod:
            observed_prod = row_prod
            if row_prod not in ("CNC", "MTF"):
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    reason=f"Forever order {oid} has unsupported productType '{row_prod}'",
                )
            if expected_product_type and row_prod != str(expected_product_type).strip().upper():
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    reason=f"Forever order {oid} productType mismatch ('{row_prod}' != '{expected_product_type}')",
                )

        tx_type = str(row.get("transactionType") or "").strip().upper()
        if tx_type != "SELL":
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                reason=f"Forever order {oid} invalid or missing transactionType '{tx_type}' (expected SELL)",
            )

        raw_qty = row.get("remainingQuantity") if row.get("remainingQuantity") is not None else row.get("quantity")
        if raw_qty is None or isinstance(raw_qty, bool):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                reason=f"Forever order {oid} missing quantity evidence",
            )
        try:
            traded_q = int(row.get("tradedQuantity") or row.get("filledQty") or 0)
            row_qty = int(row["remainingQuantity"]) if row.get("remainingQuantity") is not None else (int(raw_qty) - traded_q)
        except (ValueError, TypeError):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                reason=f"Forever order {oid} non-integer quantity '{raw_qty}'",
            )

        if row_qty <= 0:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                reason=f"Forever order {oid} has non-positive remaining quantity ({row_qty})",
            )

        if expected_qty is not None and row_qty != int(expected_qty):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                reason=f"Forever order {oid} quantity mismatch ({row_qty} != {expected_qty})",
            )

        leg_name = str(row.get("legName") or "").strip().upper()
        if leg_name == "STOP_LOSS_LEG":
            trig = row.get("triggerPrice") if row.get("triggerPrice") is not None else row.get("price")
            if trig is None or float(trig) <= 0:
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.UNVERIFIED,
                    is_verified=False,
                    group_id=oid,
                    reason=f"Forever order {oid} STOP_LOSS_LEG missing triggerPrice",
                )
            if expected_sl_trigger is not None and abs(float(trig) - float(expected_sl_trigger)) > tol:
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    reason=f"Forever order {oid} STOP_LOSS_LEG price mismatch ({trig} != {expected_sl_trigger})",
                )
            has_sl_leg = True
            sl_qty = row_qty
            observed_sl = float(trig)
        elif leg_name == "TARGET_LEG":
            tgt = row.get("price") if row.get("price") is not None else row.get("triggerPrice")
            if tgt is None or float(tgt) <= 0:
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.UNVERIFIED,
                    is_verified=False,
                    group_id=oid,
                    reason=f"Forever order {oid} TARGET_LEG missing price",
                )
            if expected_target_price is not None and abs(float(tgt) - float(expected_target_price)) > tol:
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    reason=f"Forever order {oid} TARGET_LEG price mismatch ({tgt} != {expected_target_price})",
                )
            has_target_leg = True
            target_qty = row_qty
            observed_target = float(tgt)
        else:
            nested_legs = row.get("legDetails")
            if isinstance(nested_legs, list) and len(nested_legs) >= 2:
                for lg in nested_legs:
                    if not isinstance(lg, dict):
                        continue
                    lg_st = str(lg.get("orderStatus") or "").strip().upper()
                    if not lg_st or lg_st not in ACTIVE_BROKER_ORDER_STATES:
                        return ProtectionVerificationResult(
                            status=(
                                ProtectionVerificationStatus.TERMINAL_OR_INVALID
                                if lg_st in TERMINAL_OR_INACTIVE_ORDER_STATES
                                else ProtectionVerificationStatus.UNVERIFIED
                            ),
                            is_verified=False,
                            is_terminal_or_invalid=(lg_st in TERMINAL_OR_INACTIVE_ORDER_STATES),
                            group_id=oid,
                            reason=f"Forever OCO {oid} nested leg not active: '{lg_st or 'MISSING'}'",
                        )
                    ln = str(lg.get("legName") or "").strip().upper()
                    lg_q_raw = lg.get("remainingQuantity") if lg.get("remainingQuantity") is not None else lg.get("quantity")
                    lg_q = int(lg_q_raw) if lg_q_raw is not None else row_qty
                    if ln == "STOP_LOSS_LEG":
                        has_sl_leg = True
                        sl_qty = lg_q
                    elif ln == "TARGET_LEG":
                        has_target_leg = True
                        target_qty = lg_q
            else:
                q1_raw = row.get("quantity1")
                q1 = int(q1_raw) if q1_raw is not None else row_qty
                if expected_qty is not None and q1 != int(expected_qty):
                    return ProtectionVerificationResult(
                        status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                        is_verified=False,
                        is_terminal_or_invalid=True,
                        group_id=oid,
                        reason=f"Forever order {oid} leg1 quantity mismatch ({q1} != {expected_qty})",
                    )
                raw_sl = row.get("triggerPrice")
                raw_tgt = row.get("price1") if row.get("price1") is not None else row.get("triggerPrice1")
                if raw_sl is not None and float(raw_sl) > 0:
                    if expected_sl_trigger is not None and abs(float(raw_sl) - float(expected_sl_trigger)) > tol:
                        return ProtectionVerificationResult(
                            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                            is_verified=False,
                            is_terminal_or_invalid=True,
                            group_id=oid,
                            reason=f"Forever order {oid} SL trigger mismatch ({raw_sl} != {expected_sl_trigger})",
                        )
                    has_sl_leg = True
                    sl_qty = row_qty
                    observed_sl = float(raw_sl)
                if raw_tgt is not None and float(raw_tgt) > 0:
                    if expected_target_price is not None and abs(float(raw_tgt) - float(expected_target_price)) > tol:
                        return ProtectionVerificationResult(
                            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                            is_verified=False,
                            is_terminal_or_invalid=True,
                            group_id=oid,
                            reason=f"Forever order {oid} target price mismatch ({raw_tgt} != {expected_target_price})",
                        )
                    has_target_leg = True
                    target_qty = q1
                    observed_target = float(raw_tgt)

    if not (has_sl_leg and has_target_leg):
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            reason=f"Forever order {oid} missing complete two-leg OCO coverage (has_sl={has_sl_leg}, has_target={has_target_leg})",
        )

    paired_qty = min(sl_qty, target_qty)
    if paired_qty <= 0 or (expected_qty is not None and paired_qty < int(expected_qty)):
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            reason=f"Forever order {oid} paired coverage ({paired_qty}) insufficient for expected ({expected_qty})",
        )

    return ProtectionVerificationResult(
        status=ProtectionVerificationStatus.VERIFIED_ACTIVE,
        is_verified=True,
        is_terminal_or_invalid=False,
        protected_quantity=paired_qty,
        group_id=oid,
        security_id=observed_sec,
        exchange_segment=observed_seg or (str(expected_segment or "").strip().upper()),
        product_type=observed_prod or (str(expected_product_type or "").strip().upper()),
        account_id=observed_acct or (str(expected_account_id or "").strip()),
        sl_price=observed_sl,
        target_price=observed_target,
        reason=f"Forever order {oid} confirmed active with both SL and Target legs ({paired_qty} units)",
    )


def verify_super_order_record(
    candidate: Optional[Dict[str, Any]],
    order_id: str,
    expected_security_id: Optional[str] = None,
    expected_qty: Optional[int] = None,
    expected_sl_price: Optional[float] = None,
    expected_target_price: Optional[float] = None,
    tick_size: float = 0.05,
    expected_account_id: Optional[str] = None,
    expected_segment: Optional[str] = None,
    expected_product_type: Optional[str] = None,
) -> ProtectionVerificationResult:
    """
    Safety Correction B: Single authoritative Super Order verification contract shared across
    `DhanClient`, `ProtectionWatcher`, and `StartupReconciliationGate`.
    - Requires documented active `legDetails` containing both `STOP_LOSS_LEG` and `TARGET_LEG`.
    - Never accepts top-level `stopLossPrice` / `targetPrice` without active leg evidence.
    - Rejects `TRADED`, `CLOSED`, `TRIGGERED`, `CANCELLED`, `REJECTED`, `EXPIRED`, or missing `orderStatus`.
    - Requires positive remaining quantity evidence and tick-aligned prices on both protective legs.
    """
    oid = str(order_id or "").strip()
    if not oid:
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            reason="Missing super order_id",
        )

    if not isinstance(candidate, dict):
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.UNVERIFIED,
            is_verified=False,
            group_id=oid,
            parent_order_id=oid,
            reason=f"Super order {oid} readback returned None or non-dict",
        )

    cand_oid = str(candidate.get("orderId") or "").strip()
    if not cand_oid or cand_oid != oid:
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            parent_order_id=cand_oid,
            reason=f"Super order parent orderId mismatch ('{cand_oid}' != '{oid}')",
        )

    acct = str(candidate.get("dhanClientId") or "").strip()
    if acct and expected_account_id and acct != str(expected_account_id).strip():
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            parent_order_id=oid,
            reason=f"Super order {oid} account mismatch ('{acct}' != '{expected_account_id}')",
        )

    sec = str(candidate.get("securityId") or "").strip()
    if expected_security_id is not None:
        if not sec:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} missing securityId evidence",
            )
        if sec != str(expected_security_id).strip():
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                parent_order_id=oid,
                security_id=sec,
                reason=f"Super order {oid} securityId mismatch ('{sec}' != '{expected_security_id}')",
            )

    cand_seg = str(candidate.get("exchangeSegment") or "").strip().upper()
    if cand_seg and expected_segment and cand_seg != str(expected_segment).strip().upper():
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            parent_order_id=oid,
            reason=f"Super order {oid} exchangeSegment mismatch ('{cand_seg}' != '{expected_segment}')",
        )

    cand_prod = str(candidate.get("productType") or "").strip().upper()
    if cand_prod and expected_product_type and cand_prod != str(expected_product_type).strip().upper():
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            parent_order_id=oid,
            reason=f"Super order {oid} productType mismatch ('{cand_prod}' != '{expected_product_type}')",
        )

    parent_st = str(candidate.get("orderStatus") or "").strip().upper()
    if parent_st in ("REJECTED", "CANCELLED", "EXPIRED"):
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            parent_order_id=oid,
            reason=f"Super order {oid} parent is in terminal failed state: {parent_st}",
        )

    leg_details = candidate.get("legDetails")
    if not isinstance(leg_details, list) or len(leg_details) < 2:
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.UNVERIFIED,
            is_verified=False,
            group_id=oid,
            parent_order_id=oid,
            reason=f"Super order {oid} lacks active legDetails evidence (top-level prices alone do not prove resting coverage)",
        )

    tol = max(float(tick_size or 0.05), 0.05) + 1e-4
    has_target = False
    has_sl = False
    sl_rem_qty = 0
    target_rem_qty = 0
    observed_sl_price = 0.0
    observed_target_price = 0.0

    for leg in leg_details:
        if not isinstance(leg, dict):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} contains malformed non-dict leg in legDetails",
            )

        leg_name = str(leg.get("legName") or "").strip().upper()
        if leg_name not in ("STOP_LOSS_LEG", "TARGET_LEG"):
            continue

        leg_tx = str(leg.get("transactionType") or "").strip().upper()
        if leg_tx and leg_tx != "SELL":
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} leg {leg_name} has invalid transactionType '{leg_tx}' (expected SELL)",
            )

        leg_st = str(leg.get("orderStatus") or "").strip().upper()
        if not leg_st:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} leg {leg_name} is missing orderStatus",
            )
        if leg_st in TERMINAL_OR_INACTIVE_ORDER_STATES:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} leg {leg_name} is not active resting coverage ({leg_st})",
            )
        if leg_st not in ACTIVE_BROKER_ORDER_STATES:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} leg {leg_name} has unverified status '{leg_st}'",
            )

        raw_rem_qty = leg.get("remainingQuantity") if leg.get("remainingQuantity") is not None else leg.get("quantity")
        if raw_rem_qty is None or isinstance(raw_rem_qty, bool):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} leg {leg_name} is missing required quantity evidence",
            )
        try:
            traded_q = int(leg.get("tradedQuantity") or leg.get("filledQty") or 0)
            leg_qty = int(leg["remainingQuantity"]) if leg.get("remainingQuantity") is not None else (int(raw_rem_qty) - traded_q)
        except (ValueError, TypeError):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} leg {leg_name} has invalid quantity '{raw_rem_qty}'",
            )

        if leg_qty <= 0:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} leg {leg_name} has non-positive remaining quantity ({leg_qty})",
            )

        if expected_qty is not None and leg_qty < int(expected_qty):
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                group_id=oid,
                parent_order_id=oid,
                reason=f"Super order {oid} leg {leg_name} remaining quantity ({leg_qty}) < expected ({expected_qty})",
            )

        if leg_name == "TARGET_LEG":
            leg_price = (
                leg.get("price")
                if leg.get("price") is not None
                else (leg.get("targetPrice") if leg.get("targetPrice") is not None else leg.get("triggerPrice"))
            )
            if leg_price is None or float(leg_price) <= 0:
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.UNVERIFIED,
                    is_verified=False,
                    group_id=oid,
                    parent_order_id=oid,
                    reason=f"Super order {oid} TARGET_LEG missing price evidence",
                )
            if expected_target_price is not None and abs(float(leg_price) - float(expected_target_price)) > tol:
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    parent_order_id=oid,
                    reason=f"Super order {oid} TARGET_LEG price mismatch ({leg_price} != {expected_target_price})",
                )
            has_target = True
            target_rem_qty = leg_qty
            observed_target_price = float(leg_price)

        elif leg_name == "STOP_LOSS_LEG":
            leg_price = (
                leg.get("price")
                if leg.get("price") is not None
                else (leg.get("stopLossPrice") if leg.get("stopLossPrice") is not None else leg.get("triggerPrice"))
            )
            if leg_price is None or float(leg_price) <= 0:
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.UNVERIFIED,
                    is_verified=False,
                    group_id=oid,
                    parent_order_id=oid,
                    reason=f"Super order {oid} STOP_LOSS_LEG missing price evidence",
                )
            if expected_sl_price is not None and abs(float(leg_price) - float(expected_sl_price)) > tol:
                return ProtectionVerificationResult(
                    status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                    is_verified=False,
                    is_terminal_or_invalid=True,
                    group_id=oid,
                    parent_order_id=oid,
                    reason=f"Super order {oid} STOP_LOSS_LEG price mismatch ({leg_price} != {expected_sl_price})",
                )
            has_sl = True
            sl_rem_qty = leg_qty
            observed_sl_price = float(leg_price)

    if not (has_target and has_sl):
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            parent_order_id=oid,
            reason=f"Super order {oid} readback lacks complete active pair (has_sl={has_sl}, has_target={has_target})",
        )

    paired_qty = min(sl_rem_qty, target_rem_qty)
    if paired_qty <= 0 or (expected_qty is not None and paired_qty < int(expected_qty)):
        return ProtectionVerificationResult(
            status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
            is_verified=False,
            is_terminal_or_invalid=True,
            group_id=oid,
            parent_order_id=oid,
            reason=f"Super order {oid} active leg coverage ({paired_qty}) < expected ({expected_qty})",
        )

    return ProtectionVerificationResult(
        status=ProtectionVerificationStatus.VERIFIED_ACTIVE,
        is_verified=True,
        is_terminal_or_invalid=False,
        protected_quantity=paired_qty,
        group_id=oid,
        parent_order_id=oid,
        security_id=sec,
        exchange_segment=cand_seg or (str(expected_segment or "").strip().upper()),
        product_type=cand_prod or (str(expected_product_type or "").strip().upper()),
        account_id=acct or (str(expected_account_id or "").strip()),
        sl_price=observed_sl_price,
        target_price=observed_target_price,
        reason=f"Super order {oid} legs confirmed active via broker readback ({paired_qty} units)",
    )


class DhanClient:
    def __init__(
        self,
        config: AppConfig,
        stop_manager: Optional[EmergencyStopManager] = None,
        reconciliation_gate: Optional[Any] = None,
        auto_generate_token: bool = True,
    ):
        self.cfg = config
        from src.broker.read_governor import ReadGovernor
        self._read_governor = ReadGovernor(
            os.path.join(config.data_dir, "broker_read_control"), config.dhan_client_id
        )
        # The scheduled force-refresh must not perform a first implicit TOTP
        # login just because the token file is missing.
        self._auto_generate_token = auto_generate_token
        self.session = configure_yahoo_http(requests.Session())
        self.stop_manager = stop_manager or EmergencyStopManager(
            state_file=os.path.join(config.data_dir, "emergency_stop.json")
        )
        self.reconciliation_gate = reconciliation_gate
        self._token_mtime: float = 0.0
        self._token_file_signature = None
        self._auth_log_at = {}
        self.last_auth_account_mismatch: bool = False
        self._on_demand_totp_mode: bool = False
        self.token = self._load_token()
        self._quote_cache: Dict[Tuple[str, str], QuoteResult] = {}
        self._yahoo_quote_local = threading.local()
        self.last_ltp_meta: Optional[Dict[str, Any]] = None
        self.last_order_http_latency_ms: Optional[float] = None
        self.last_super_leg_mod_results: Dict[str, Dict[str, Any]] = {}
        self.last_order_broker_status: str = ""
        self.last_funds_is_fallback: bool = False

    def _is_isolated_test_default_token_path(self, token_path: str) -> bool:
        import sys
        if ("unittest" in sys.modules or "pytest" in sys.modules) and os.environ.get("AUDITBOT_ALLOW_HOME_TOKEN_IN_TESTS") != "1":
            default_home_tok = os.path.abspath(os.path.expanduser("~/.dhan_token"))
            if os.path.abspath(token_path) == default_home_tok:
                return True
        return False

    def _perform_totp_http_login(self) -> Tuple[bool, str, str]:
        """Executes raw TOTP HTTP call against Dhan auth endpoint and validates account identity."""
        self.last_auth_account_mismatch = False
        # Evidence from a candidate /v2/profile response is valid only for
        # the exact freshly issued token and only in this login process.
        # Never publish an unverified candidate or persist these details.
        self._last_candidate_profile_verification = None
        if not self.cfg.dhan_client_id or not self.cfg.dhan_pin or not self.cfg.dhan_totp_secret:
            return False, "", "Missing DHAN_CLIENT_ID, DHAN_PIN, or DHAN_TOTP_SECRET in config"
        try:
            totp_code = compute_totp(self.cfg.dhan_totp_secret)
            params = {
                "dhanClientId": self.cfg.dhan_client_id,
                "pin": self.cfg.dhan_pin,
                "totp": totp_code,
            }
            # Scheduled/CLI refreshes (force=True) use (5, 25) timeout with one retry.
            # On-demand runtime refreshes inside ProtectionWatcher (_on_demand_totp_mode=True)
            # use a bounded single attempt (3.0, 8.0) so a slow auth.dhan.co endpoint
            # never stalls 2-second ProtectionWatcher supervision for 52 seconds.
            on_demand = bool(getattr(self, "_on_demand_totp_mode", False))
            req_timeout = ON_DEMAND_TOTP_HTTP_TIMEOUT if on_demand else (5, 25)
            max_attempts = ON_DEMAND_TOTP_MAX_ATTEMPTS if on_demand else 2
            for attempt in range(max_attempts):
                try:
                    resp = self.session.post(AUTH_URL, params=dict(params), timeout=req_timeout)
                    break
                except (requests.exceptions.ConnectTimeout,
                    requests.exceptions.ReadTimeout,
                    requests.exceptions.ConnectionError) as exc:
                    if isinstance(exc, requests.exceptions.SSLError):
                        return False, "", "Dhan TOTP HTTPS/TLS verification failed"
                    if attempt >= max_attempts - 1:
                        return False, "", (
                            "Dhan TOTP authentication endpoint unavailable after "
                            f"bounded attempt(s) ({type(exc).__name__}); "
                            "check outbound connectivity to auth.dhan.co"
                        )
                    logger.warning(
                        "Dhan TOTP auth endpoint unavailable (%s); retrying "
                        "once with fresh TOTP after a short delay.",
                        type(exc).__name__,
                    )
                    time.sleep(2)
                    params["totp"] = compute_totp(self.cfg.dhan_totp_secret)
            if resp.status_code == 200:
                data = resp.json()
                if not isinstance(data, dict):
                    return False, "", f"Malformed TOTP response from Dhan: {resp.text}"
                resp_client_id = str(data.get("dhanClientId", "")).strip()
                expected_id = str(self.cfg.dhan_client_id).strip()
                if resp_client_id and expected_id and resp_client_id != expected_id:
                    self.last_auth_account_mismatch = True
                    return (
                        False,
                        "",
                        f"Dhan account mismatch in TOTP response: expected '{_mask_client_id(expected_id)}', got '{_mask_client_id(resp_client_id)}'",
                    )
                new_token = str(data.get("accessToken", "")).strip()
                if new_token:
                    jwt_claims = self._decode_jwt_claims(new_token)
                    jwt_cid = str(
                        jwt_claims.get("dhanClientId")
                        or jwt_claims.get("clientId")
                        or jwt_claims.get("client_id")
                        or ""
                    ).strip()
                    if jwt_cid and expected_id and jwt_cid != expected_id:
                        self.last_auth_account_mismatch = True
                        return (
                            False,
                            "",
                            f"Dhan account mismatch in JWT payload: expected '{_mask_client_id(expected_id)}', got '{_mask_client_id(jwt_cid)}'",
                        )
                    # Never trust the claimed client ID in AUTH_URL alone.
                    # Every candidate must pass an actual GET /v2/profile with
                    # that candidate token BEFORE sharing/writing it.
                    prof = self.verify_profile_and_token_expiry(
                        allow_refresh=False,
                        candidate_token=new_token,
                    )
                    if prof.get("identity_status") == "MISMATCH" or prof.get("identity_mismatch"):
                        self.last_auth_account_mismatch = True
                        return (
                            False, "",
                            "Dhan /v2/profile candidate account mismatch; token not published",
                        )
                    if not prof.get("identity_verified", False) or prof.get("token_expired", False):
                        return (
                            False, "",
                            "Dhan /v2/profile candidate token identity unverified; token not published",
                        )
                    self._last_candidate_profile_verification = {
                        "token_sha256": hashlib.sha256(new_token.encode("utf-8")).hexdigest(),
                        "account_id": expected_id,
                        "verified_at": time.time(),
                        "profile": {
                            k: prof.get(k) for k in (
                                "identity_status", "identity_verified",
                                "identity_mismatch", "profile_client_id",
                                "token_expiration_ts", "token_expiration_str",
                                "token_expired",
                            )
                        },
                    }
                    return True, new_token, "Token generated and account-verified"
                return False, "", f"Token missing in Dhan response: {resp.text}"
            return False, "", f"Dhan auth rejected TOTP ({resp.status_code}): {resp.text}"
        except Exception as e:
            return False, "", f"Exception generating token via TOTP: {e}"

    def generate_token_with_totp(
        self,
        force: bool = True,
        rejected_token: Optional[str] = None,
    ) -> Tuple[bool, str, str]:
        """
        V12-20: Generates or adopts a fresh 24-hour access token through the shared `fcntl.flock`
        coordinator (`force_login` when `force=True`, or `fresh_token` when `force=False`).
        """
        if not self.cfg.dhan_client_id or not self.cfg.dhan_pin or not self.cfg.dhan_totp_secret:
            return False, "", "Missing DHAN_CLIENT_ID, DHAN_PIN, or DHAN_TOTP_SECRET in config"

        token_path = os.path.expanduser(self.cfg.dhan_token_file)
        last_err = ["Token generation failed"]

        # Evaluated while holding the existing token-file flock, preventing
        # multiple clients from simultaneously generating TOTP credentials.
        # A token-specific digest allows a NEW token to seek recovery without
        # being blocked by yesterday's (or another process's) failed login.
        # The marker stores neither the token nor PIN/TOTP secret.
        retry_marker = token_path + ".auth_retry_after"
        rejected_for_cooldown = str(
            rejected_token if rejected_token is not None else self.token
        )
        def _token_digest(token: str) -> str:
            return hashlib.sha256(token.encode("utf-8")).hexdigest()

        rejected_digest = _token_digest(rejected_for_cooldown)

        def _write_retry_marker(token_digest: str, delay_sec: float) -> None:
            # Called under the token-file flock; advisory only, never secret.
            try:
                fd = os.open(
                    retry_marker, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600
                )
                with os.fdopen(fd, "w", encoding="ascii") as f:
                    f.write(f"{time.time() + delay_sec:.6f} {token_digest}")
                os.chmod(retry_marker, 0o600)
            except OSError:
                logger.warning("Unable to persist Dhan login retry cooldown.")

        def _login_cb() -> Optional[str]:
            now = time.time()
            if not force:
                try:
                    with open(retry_marker, "r", encoding="ascii") as f:
                        marker_parts = f.read().strip().split()
                    retry_after = float(marker_parts[0])
                    marker_digest = marker_parts[1] if len(marker_parts) > 1 else None
                    # Old one-field markers are honored until expiry; this
                    # avoids a retry stampede when upgrading from PR #74.
                    matches = marker_digest is None or marker_digest == rejected_digest
                    if (matches and now < retry_after
                            <= now + ON_DEMAND_AUTH_FAILURE_COOLDOWN_SEC):
                        last_err[0] = "Dhan TOTP endpoint recovery cooldown active"
                        return None
                except (FileNotFoundError, ValueError, OSError, IndexError):
                    pass

            prev_mode = getattr(self, "_on_demand_totp_mode", False)
            self._on_demand_totp_mode = not bool(force)
            try:
                ok, tok, msg = self._perform_totp_http_login()
            finally:
                self._on_demand_totp_mode = prev_mode
            last_err[0] = msg
            if ok and tok:
                # The coordinator writes this token before unlocking. If a
                # subsequent broker GET briefly returns 401, keep probing
                # with this token instead of immediately invalidating it with
                # another generated token.
                _write_retry_marker(
                    _token_digest(tok), NEW_TOKEN_PROPAGATION_GRACE_SEC
                )
                return tok

            # Failed logins get a longer 120-second per-rejected-token cooldown.
            # Force login still bypasses it on the next scheduled refresh.
            _write_retry_marker(
                rejected_digest, ON_DEMAND_AUTH_FAILURE_COOLDOWN_SEC
            )
            return None

        try:
            if force:
                new_token = force_login(_login_cb, path=token_path)
            else:
                rej = rejected_token if rejected_token is not None else self.token
                try:
                    new_token = fresh_token(
                        rej,
                        _login_cb,
                        path=token_path,
                        lock_timeout_sec=ON_DEMAND_LOCK_TIMEOUT_SEC,
                    )
                except BlockingIOError:
                    last_err[0] = "Dhan token refresh already in progress in another process"
                    new_token = None

            if new_token:
                self.token = new_token
                try:
                    if os.path.exists(token_path):
                        st = os.stat(token_path)
                        self._token_mtime = st.st_mtime
                        self._token_file_signature = self._token_stat_signature(st)
                except Exception:
                    pass
                logger.info(f"✅ Active Dhan access token coordinated via {token_path}")
                return True, new_token, "Token generated successfully"
            return False, "", last_err[0]
        except Exception as e:
            return False, "", f"Exception generating token via TOTP: {e}"

    @staticmethod
    def _token_stat_signature(stat_result):
        """Detect atomic replacements even if mtime is equal or moves backwards."""
        return (
            stat_result.st_dev, stat_result.st_ino, stat_result.st_size,
            stat_result.st_mtime_ns, stat_result.st_ctime_ns,
        )

    def _sync_shared_token_from_disk(self) -> None:
        """Adopt token changes by file identity, not mtime ordering alone.

        A systemd refresh writes via os.replace(), changing the inode even when
        timestamps are equal. Never log the token or return an empty token as
        successful authentication.
        """
        token_path = os.path.expanduser(self.cfg.dhan_token_file)
        if not token_path or self._is_isolated_test_default_token_path(token_path):
            return
        try:
            stat_before = os.stat(token_path)
            signature = self._token_stat_signature(stat_before)
            if signature == getattr(self, "_token_file_signature", None):
                return
            disk_tok = read_token(token_path)
            if not disk_tok:
                return
            # A concurrent atomic replacement may occur during reading. Recheck
            # and read the final file once, rather than adopting stale content.
            stat_after = os.stat(token_path)
            if self._token_stat_signature(stat_after) != signature:
                disk_tok = read_token(token_path)
                if not disk_tok:
                    return
                signature = self._token_stat_signature(stat_after)
            if disk_tok and disk_tok != self.token:
                self.token = disk_tok
                logger.info("Adopted rotated Dhan access token from shared file.")
            self._token_mtime = stat_after.st_mtime
            self._token_file_signature = signature
        except (FileNotFoundError, PermissionError, OSError):
            # A missing/unreadable file must never be interpreted as a valid
            # authenticated balance or an empty broker order book.
            return

    def _load_token(self) -> str:
        """
        CV13-06: Single authoritative access-token source (`~/.dhan_token`).
        Prefers the shared token file when present (unless isolated in a unit test),
        falling back to explicit in-memory config token or coordinated TOTP generation.
        """
        token_path = os.path.expanduser(self.cfg.dhan_token_file)
        is_isolated_default = self._is_isolated_test_default_token_path(token_path)

        if not is_isolated_default and token_path and os.path.exists(token_path):
            tok = read_token(token_path)
            if tok:
                try:
                    stat = os.stat(token_path)
                    self._token_mtime = stat.st_mtime
                    self._token_file_signature = self._token_stat_signature(stat)
                except OSError:
                    pass
                return tok

        if self.cfg.dhan_access_token:
            return self.cfg.dhan_access_token.strip()

        if (self._auto_generate_token and not is_isolated_default
                and self.cfg.dhan_client_id and self.cfg.dhan_pin and self.cfg.dhan_totp_secret):
            ok, tok, _ = self.generate_token_with_totp(force=False, rejected_token="")
            if ok and tok:
                return tok

        return ""

    def _headers(self) -> Dict[str, str]:
        self._sync_shared_token_from_disk()
        return {
            "access-token": self.token,
            "client-id": self.cfg.dhan_client_id,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _broker_mutating_http(self, method: str, url: str, **kwargs):
        """Opt-in durable handoff around actual Dhan order POST/PUT/DELETE.

        Disabled by default. Price-feed POST and auth POST are not order
        mutations and continue through their original transport unmodified.
        """
        fn = getattr(self.session, method.lower())
        if os.environ.get("UDITBOT_TRACKER_V2_ENABLE") != "1":
            return fn(url, **kwargs)
        from src.engine.broker_handoff import guarded_request
        return guarded_request(
            self.cfg.data_dir, self.cfg.dhan_client_id, method,
            lambda: fn(url, **kwargs),
        )

    def is_token_error(self, status_code: int, response_text: str) -> bool:
        """Detects Dhan expired or invalid token errors."""
        return _shared_is_token_error(status_code, response_text)


    @staticmethod
    def _decode_jwt_claims(token: str) -> Dict[str, Any]:
        raw = str(token or "").strip()
        parts = raw.split(".")
        if len(parts) != 3 or not parts[1]:
            return {}
        try:
            b64 = parts[1].replace("-", "+").replace("_", "/")
            pad = "=" * ((4 - len(b64) % 4) % 4)
            decoded = base64.b64decode((b64 + pad).encode("ascii"))
            payload = json.loads(decoded.decode("utf-8"))
            return payload if isinstance(payload, dict) else {}
        except Exception:
            return {}

    @classmethod
    def extract_token_expiration(
        cls,
        token: str,
        profile_payload: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Optional[float], str]:
        """
        Extracts actual verified token expiration timestamp (epoch seconds and IST formatted string)
        from JWT `exp` claim or Dhan `/v2/profile` `tokenValidity` field. Never fabricates an unverified expiry.
        """
        ist_tz = ZoneInfo("Asia/Kolkata")
        claims = cls._decode_jwt_claims(token)
        raw_exp = claims.get("exp")
        if raw_exp is not None and not isinstance(raw_exp, bool) and isinstance(raw_exp, (int, float, str)):
            try:
                exp_ts = float(raw_exp)
                if math.isfinite(exp_ts) and exp_ts > 0:
                    dt_ist = datetime.fromtimestamp(exp_ts, tz=ist_tz)
                    return exp_ts, dt_ist.strftime("%Y-%m-%d %H:%M:%S IST")
            except (ValueError, TypeError, OverflowError):
                pass

        if isinstance(profile_payload, dict):
            for key in ("tokenValidity", "expiryTime", "tokenExpiry", "expirationTime"):
                val = str(profile_payload.get(key) or "").strip()
                if not val or val.lower() in ("none", "null"):
                    continue
                for fmt in (
                    "%d/%m/%Y %H:%M:%S",
                    "%d/%m/%Y %H:%M",
                    "%Y-%m-%d %H:%M:%S",
                    "%Y-%m-%d %H:%M",
                    "%Y-%m-%dT%H:%M:%S",
                ):
                    try:
                        naive = datetime.strptime(val, fmt)
                        dt_ist = naive.replace(tzinfo=ist_tz)
                        return dt_ist.timestamp(), dt_ist.strftime("%Y-%m-%d %H:%M:%S IST")
                    except ValueError:
                        continue
                try:
                    dt_iso = datetime.fromisoformat(val)
                    if dt_iso.tzinfo is None:
                        dt_iso = dt_iso.replace(tzinfo=ist_tz)
                    else:
                        dt_iso = dt_iso.astimezone(ist_tz)
                    return dt_iso.timestamp(), dt_iso.strftime("%Y-%m-%d %H:%M:%S IST")
                except ValueError:
                    pass

        return None, ""

    def get_authenticated_profile(
        self,
        *,
        bypass_test_mode: bool = False,
        allow_refresh: bool = True,
        candidate_token: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Read-only Dhan /v2/profile call returning the full profile payload dict on HTTP 200."""
        if getattr(self.cfg, "trading_mode", None) == TradingMode.TEST and not bypass_test_mode:
            return None
        self._last_profile_local_deferral = False
        self._last_profile_http_status = None
        try:
            if candidate_token is not None:
                headers = {
                    "access-token": str(candidate_token).strip(),
                    "client-id": str(getattr(self.cfg, "dhan_client_id", "") or ""),
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                }
                resp = self._governed_get(
                    f"{BASE_URL}/profile", headers=headers, timeout=5,
                    priority="identity",
                )
            else:
                resp = self._get_with_auth_recovery(
                    f"{BASE_URL}/profile", allow_refresh=allow_refresh
                )
            self._last_profile_http_status = int(resp.status_code)
            if resp.status_code != 200:
                self._last_profile_local_deferral = (
                    str(resp.headers.get("X-AuditBot-Local-Deferral", "")) == "1"
                )
                if self._last_profile_local_deferral:
                    logger.warning(
                        "Dhan profile identity check locally deferred (HTTP %s); "
                        "no broker identity conclusion possible", resp.status_code
                    )
                else:
                    logger.warning(
                        "Dhan profile identity check broker HTTP %s; "
                        "account identity remains unverified", resp.status_code
                    )
                return None
            payload = resp.json()
            return payload if isinstance(payload, dict) else None
        except Exception as exc:
            logger.warning("Dhan profile identity check unavailable: %s", type(exc).__name__)
            return None

    def get_authenticated_profile_id(
        self,
        *,
        bypass_test_mode: bool = False,
        allow_refresh: bool = True,
    ) -> Optional[str]:
        """Read-only Dhan /v2/profile identity check; never infers identity from .env."""
        payload = self.get_authenticated_profile(
            bypass_test_mode=bypass_test_mode,
            allow_refresh=allow_refresh,
        )
        if not isinstance(payload, dict):
            return None
        account_id = str(payload.get("dhanClientId") or "").strip()
        return account_id if account_id.isdigit() else None

    def verify_profile_and_token_expiry(
        self,
        *,
        allow_refresh: bool = False,
        now_ts: Optional[float] = None,
        candidate_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        C1 (P0): Strictly verifies expected Dhan account identity via read-only `/v2/profile`
        and extracts actual verified token expiration timestamp.
        - Requires an explicit broker-returned `dhanClientId` from `/v2/profile` matching `cfg.dhan_client_id`.
        - Never substitutes unverified JWT claims or expected config ID when `/v2/profile` omits `dhanClientId`.
        - Contains zero test-framework or mock inspection branches.
        """
        eval_now = float(now_ts if now_ts is not None else time.time())
        expected_id = str(getattr(self.cfg, "dhan_client_id", "") or "").strip()
        if candidate_token is None and getattr(self, "last_auth_account_mismatch", False):
            return {
                "identity_status": "MISMATCH",
                "identity_verified": False,
                "identity_mismatch": True,
                "profile_client_id": "",
                "token_expiration_ts": None,
                "token_expiration_str": "",
                "token_expired": False,
                "reason": "Previous TOTP authentication detected account mismatch",
            }

        tok = str(
            candidate_token
            if candidate_token is not None
            else (getattr(self, "token", "") or "")
        ).strip()
        jwt_claims = self._decode_jwt_claims(tok)
        jwt_cid = str(
            jwt_claims.get("dhanClientId")
            or jwt_claims.get("clientId")
            or jwt_claims.get("client_id")
            or ""
        ).strip()
        if jwt_cid and expected_id and jwt_cid != expected_id:
            return {
                "identity_status": "MISMATCH",
                "identity_verified": False,
                "identity_mismatch": True,
                "profile_client_id": jwt_cid,
                "token_expiration_ts": None,
                "token_expiration_str": "",
                "token_expired": False,
                "reason": f"JWT client ID mismatch ({jwt_cid} != {expected_id})",
            }

        if not tok:
            return {
                "identity_status": "UNVERIFIED",
                "identity_verified": False,
                "identity_mismatch": False,
                "profile_client_id": "",
                "token_expiration_ts": None,
                "token_expiration_str": "",
                "token_expired": False,
                "reason": "Missing access token",
            }

        if candidate_token is not None:
            try:
                payload = self.get_authenticated_profile(
                    bypass_test_mode=True,
                    allow_refresh=False,
                    candidate_token=tok,
                )
            except (TypeError, AttributeError):
                # A candidate-unaware verifier must FAIL CLOSED, not verify
                # the previous self.token and substitute its identity.
                payload = None
        else:
            payload = self.get_authenticated_profile(
                bypass_test_mode=True,
                allow_refresh=allow_refresh,
            )

        exp_ts, exp_str = self.extract_token_expiration(tok, payload)
        token_expired = bool(exp_ts is not None and exp_ts <= eval_now)

        if not isinstance(payload, dict):
            return {
                "identity_status": "UNVERIFIED",
                "identity_verified": False,
                "identity_mismatch": False,
                "profile_client_id": "",
                "token_expiration_ts": exp_ts,
                "token_expiration_str": exp_str,
                "token_expired": token_expired,
                "reason": "Dhan /v2/profile response unavailable or non-dict",
            }

        prof_id = str(payload.get("dhanClientId") or "").strip()
        if not prof_id:
            return {
                "identity_status": "UNVERIFIED",
                "identity_verified": False,
                "identity_mismatch": False,
                "profile_client_id": "",
                "token_expiration_ts": exp_ts,
                "token_expiration_str": exp_str,
                "token_expired": token_expired,
                "reason": "Dhan /v2/profile response missing dhanClientId (cannot verify account identity)",
            }

        if not expected_id:
            return {
                "identity_status": "UNVERIFIED",
                "identity_verified": False,
                "identity_mismatch": False,
                "profile_client_id": prof_id,
                "token_expiration_ts": exp_ts,
                "token_expiration_str": exp_str,
                "token_expired": token_expired,
                "reason": "Expected DHAN_CLIENT_ID is not configured",
            }

        if prof_id != expected_id:
            return {
                "identity_status": "MISMATCH",
                "identity_verified": False,
                "identity_mismatch": True,
                "profile_client_id": prof_id,
                "token_expiration_ts": exp_ts,
                "token_expiration_str": exp_str,
                "token_expired": token_expired,
                "reason": f"Dhan /v2/profile account mismatch: expected '{expected_id}', got '{prof_id}'",
            }

        if token_expired:
            return {
                "identity_status": "EXPIRED",
                "identity_verified": False,
                "identity_mismatch": False,
                "profile_client_id": prof_id,
                "token_expiration_ts": exp_ts,
                "token_expiration_str": exp_str,
                "token_expired": True,
                "reason": f"Dhan access token expired at {exp_str or 'unknown'}",
            }

        return {
            "identity_status": "VERIFIED",
            "identity_verified": True,
            "identity_mismatch": False,
            "profile_client_id": prof_id,
            "token_expiration_ts": exp_ts,
            "token_expiration_str": exp_str,
            "token_expired": False,
            "reason": f"Verified /v2/profile account {prof_id}",
        }

    def verify_token_authenticated(self) -> Tuple[bool, float, str]:
        """
        P1 TOTP Recovery Guard: Verifies against Dhan /v2/fundlimit that the active token
        is genuinely authenticated at the broker, never masking errors with TEST-mode fallback.
        """
        if not self.token:
            return False, 0.0, "Missing access token"
        self.last_funds_is_fallback = False
        ok_f, avail, msg_f = self.get_fund_limits(retry=False)
        if not ok_f or getattr(self, "last_funds_is_fallback", False):
            return False, 0.0, msg_f
        return True, avail, msg_f

    def get_reconciliation_fund_limits(self) -> Tuple[bool, float, str]:
        """Startup-only, read-only funds verification using the reserved GET tier.

        All actual requests still obey the governor's hard daily/hourly caps.
        Ordinary signal funds checks remain NORMAL and cannot consume reserve.
        """
        return self.get_fund_limits(retry=True, _startup_reconciliation=True)

    def get_fund_limits(
        self, retry: bool = True, *, _startup_reconciliation: bool = False
    ) -> Tuple[bool, float, str]:
        """
        Retrieves available ledger balance from Dhan v2 /fundlimit endpoint.
        Returns: (success, available_balance, message)
        """
        self.last_funds_is_fallback = False
        if self.cfg.trading_mode == TradingMode.TEST:
            if not self.token:
                self.last_funds_is_fallback = True
                return True, 100000.0, "Test mode default balance (token missing)"
            url = f"{BASE_URL}/fundlimit"
            try:
                resp = self._get_with_auth_recovery(url, allow_refresh=retry)
                if resp.status_code == 200:
                    data = resp.json()
                    if isinstance(data, dict):
                        avail = float(data.get("availabelBalance", data.get("availableBalance", data.get("sodLimit", 0.0))))
                        self.last_funds_is_fallback = False
                        return True, avail, "Funds retrieved successfully from broker (HTTP 200)"
                    self.last_funds_is_fallback = True
                    return True, 100000.0, "Test mode fallback balance (Malformed response from Dhan)"
                elif self.is_token_error(resp.status_code, resp.text):
                    self.last_funds_is_fallback = True
                    return True, 100000.0, f"Test mode fallback balance (Dhan auth error {resp.status_code})"
                self.last_funds_is_fallback = True
                return True, 100000.0, f"Test mode fallback balance (Dhan returned {resp.status_code})"
            except Exception as e:
                self.last_funds_is_fallback = True
                return True, 100000.0, f"Test mode fallback balance (Dhan query exception: {e})"

        url = f"{BASE_URL}/fundlimit"
        try:
            if _startup_reconciliation:
                resp = self._get_with_auth_recovery(
                    url, allow_refresh=retry, priority="identity"
                )
            else:
                resp = self._get_with_auth_recovery(url, allow_refresh=retry)
            if resp.status_code == 200:
                data = resp.json()
                if not isinstance(data, dict):
                    return False, 0.0, f"Malformed Dhan funds response (expected dict, got {type(data).__name__})"
                exp_cid = str(getattr(self.cfg, "dhan_client_id", "") or "").strip()
                resp_cid = str(data.get("dhanClientId") or "").strip()
                if exp_cid and resp_cid and resp_cid != exp_cid:
                    self.last_auth_account_mismatch = True
                    return (
                        False,
                        0.0,
                        f"Dhan funds account mismatch: expected '{_mask_client_id(exp_cid)}', got '{_mask_client_id(resp_cid)}'",
                    )
                raw_bal = None
                for k_bal in ("availabelBalance", "availableBalance", "sodLimit"):
                    if k_bal in data and data.get(k_bal) is not None:
                        raw_bal = data.get(k_bal)
                        break
                if raw_bal is None or isinstance(raw_bal, bool):
                    return False, 0.0, "Malformed Dhan funds response: missing balance field"
                try:
                    avail = float(raw_bal)
                except (ValueError, TypeError):
                    return False, 0.0, f"Malformed Dhan funds response: non-numeric balance ({raw_bal!r})"
                if not math.isfinite(avail):
                    return False, 0.0, f"Malformed Dhan funds response: non-finite balance ({raw_bal!r})"
                return True, avail, "Funds retrieved successfully"
            elif str(getattr(resp, "headers", {}).get("X-AuditBot-Local-Deferral") or "") == "1":
                retry_sec = str(resp.headers.get("Retry-After") or "unknown")
                return False, 0.0, (
                    f"Local Dhan GET admission deferred ({retry_sec}s); "
                    "no broker request sent"
                )
            elif self.is_token_error(resp.status_code, resp.text):
                # The shared helper already made at most one read-only retry.
                return False, 0.0, f"Dhan auth error ({resp.status_code}): {resp.text}"
            else:
                return False, 0.0, f"Dhan funds API error ({resp.status_code}): {resp.text}"
        except Exception as e:
            return False, 0.0, f"HTTP exception fetching funds: {e}"

    # =========================================================================
    # SECTION A & V12-15: Yahoo Finance Primary Price Source with Strict 2.0s Freshness Gate
    # =========================================================================

    @property
    def last_quote_result(self) -> Optional[QuoteResult]:
        """Yahoo result from this thread only, never another signal/watcher's."""
        return getattr(self._yahoo_quote_local, "result", None)

    @last_quote_result.setter
    def last_quote_result(self, value: Optional[QuoteResult]) -> None:
        self._yahoo_quote_local.result = value

    def get_yahoo_quote_details(
        self,
        stock_symbol: str,
        exchange_segment: str = "NSE_EQ",
        security_id: str = "",
        now_utc: Optional[float] = None,
        max_quote_age_sec: Optional[float] = None,
        allow_cached: bool = False,
        cmp_policy: Optional[str] = None,
    ) -> QuoteResult:
        seg = (exchange_segment or "").strip().upper()
        clean_sym = (stock_symbol or "").replace("-EQ", "").strip().upper()
        max_age = float(max_quote_age_sec) if max_quote_age_sec is not None else float(getattr(self.cfg, "max_quote_age_sec", 2.0))
        current_utc = float(now_utc) if now_utc is not None else time.time()
        effective_policy = str(cmp_policy or getattr(self.cfg, "equity_cmp_execution_policy", "STRICT_TIMESTAMP") or "STRICT_TIMESTAMP").upper().strip()
        is_darvas_policy = (effective_policy == "DARVAS_HTTP_SUCCESS" and seg == "NSE_EQ")

        if seg in ("NSE_FNO", "BSE_FNO") or seg not in ("NSE_EQ", "BSE_EQ"):
            res = QuoteResult(
                is_valid=False,
                source="YAHOO_FINANCE",
                ticker=clean_sym,
                venue="UNKNOWN",
                security_id=str(security_id or ""),
                cmp_policy=effective_policy,
                failure_reason=(
                    f"Unsupported segment '{seg}' for Yahoo Finance equity price source: "
                    f"cannot substitute underlying equity quote for F&O option contract premium"
                ),
            )
            self.last_quote_result = res
            return res

        if not clean_sym:
            res = QuoteResult(
                is_valid=False,
                source="YAHOO_FINANCE",
                venue="UNKNOWN",
                security_id=str(security_id or ""),
                cmp_policy=effective_policy,
                failure_reason="Missing stock symbol for Yahoo Finance quote",
            )
            self.last_quote_result = res
            return res

        cache_key = (seg, clean_sym)
        if allow_cached and cache_key in self._quote_cache:
            cached = self._quote_cache[cache_key]
            recomputed_age = round(current_utc - cached.quote_timestamp, 6) if (cached.quote_timestamp is not None and cached.quote_timestamp > 0) else None
            if cached.is_valid and (recomputed_age is not None and 0.0 <= recomputed_age <= max_age) and (is_darvas_policy or cached.freshness_verified) and (not security_id or cached.security_id == str(security_id)):
                updated = cached.model_copy(update={"age_sec": recomputed_age}) if hasattr(cached, "model_copy") else cached.copy(update={"age_sec": recomputed_age})
                self.last_quote_result = updated
                return updated
            else:
                self._quote_cache.pop(cache_key, None)

        suffix = ".BO" if seg == "BSE_EQ" else ".NS"
        expected_ticker = f"{clean_sym}{suffix}"
        url = YAHOO_CHART_URL.format(ticker=expected_ticker)
        headers = YAHOO_HTTP_HEADERS

        t4_start_ns = time.perf_counter_ns()
        try:
            t_req_start = time.time()
            resp = self.session.get(url, headers=headers, timeout=YAHOO_HTTP_TIMEOUT)
            t4_end_ns = time.perf_counter_ns()
            http_latency_ms = round(max(0.0, (t4_end_ns - t4_start_ns) / 1_000_000.0), 3)
            http_elapsed = max(0.0, time.time() - t_req_start)
            eval_utc = (float(now_utc) + (http_elapsed if http_elapsed >= 0.05 else 0.0)) if now_utc is not None else time.time()

            if resp.status_code != 200:
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=seg,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Yahoo Finance returned HTTP {resp.status_code} for {expected_ticker}",
                )
                self.last_quote_result = res
                return res

            t5_start_ns = time.perf_counter_ns()
            data = parse_yahoo_response(resp)
            results = (data.get("chart") or {}).get("result") or []
            if not results or not isinstance(results[0], dict):
                t5_end_ns = time.perf_counter_ns()
                parse_latency_ms = round(max(0.0, (t5_end_ns - t5_start_ns) / 1_000_000.0), 3)
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=seg,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Empty chart result in Yahoo Finance response for {expected_ticker}",
                )
                self.last_quote_result = res
                return res

            meta = results[0].get("meta") or {}
            raw_price = meta.get("regularMarketPrice")
            raw_ts = meta.get("regularMarketTime")
            meta_sym = str(meta.get("symbol") or "").strip().upper()
            meta_exch = str(meta.get("exchangeName") or meta.get("fullExchangeName") or "").strip().upper()
            meta_curr = str(meta.get("currency") or "").strip().upper()
            market_state = str(meta.get("marketState") or "").strip().upper()
            observed_venue = meta_exch if meta_exch else "UNKNOWN"
            observed_currency = meta_curr if meta_curr else "UNKNOWN"
            observed_market_state = market_state if market_state else "UNKNOWN"
            meta_sec_id = str(meta.get("securityId") or "").strip()
            raw_delay = meta.get("exchangeDataDelayedBy")
            t5_end_ns = time.perf_counter_ns()
            parse_latency_ms = round(max(0.0, (t5_end_ns - t5_start_ns) / 1_000_000.0), 3)

            t6_start_ns = time.perf_counter_ns()
            if raw_price is None or isinstance(raw_price, bool) or not isinstance(raw_price, (int, float)):
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Missing or non-numeric regularMarketPrice for {expected_ticker}",
                )
                self.last_quote_result = res
                return res

            price = float(raw_price)
            if not math.isfinite(price) or price <= 0.0:
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=0.0,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Invalid non-positive or non-finite price ({raw_price}) for {expected_ticker}",
                )
                self.last_quote_result = res
                return res

            if not meta_sym or meta_sym != expected_ticker:
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=meta_sym or expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Instrument identity mismatch: requested '{expected_ticker}', response had '{meta_sym}'",
                )
                self.last_quote_result = res
                return res

            if meta_sec_id and security_id and meta_sec_id != str(security_id):
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=meta_sec_id,
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Security ID mismatch: expected '{security_id}', response had '{meta_sec_id}'",
                )
                self.last_quote_result = res
                return res

            if seg == "NSE_EQ" and (not meta_exch or meta_exch not in VALID_NSE_EXCHANGES):
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Venue mismatch or missing exchangeName for NSE_EQ: Yahoo returned exchange '{observed_venue}'",
                )
                self.last_quote_result = res
                return res

            if seg == "BSE_EQ" and (not meta_exch or meta_exch not in VALID_BSE_EXCHANGES):
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Venue mismatch or missing exchangeName for BSE_EQ: Yahoo returned exchange '{observed_venue}'",
                )
                self.last_quote_result = res
                return res

            if meta_curr != "INR":
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Unsupported or missing quote currency '{observed_currency}' (expected INR)",
                )
                self.last_quote_result = res
                return res

            if is_darvas_policy:
                # CV13-07: DARVAS_HTTP_SUCCESS policy for NSE_EQ
                from src.engine.market import is_market_open
                m_open = False
                try:
                    eval_dt = datetime.datetime.fromtimestamp(eval_utc, tz=IST) if eval_utc else None
                    m_open = is_market_open(now=eval_dt)
                except Exception:
                    pass

                delay_metadata_present = (raw_delay is not None and not isinstance(raw_delay, bool) and isinstance(raw_delay, (int, float)))
                delay_seconds = float(raw_delay) if delay_metadata_present else None
                is_delayed = bool(delay_seconds is not None and delay_seconds > 0.0)

                quote_ts: Optional[float] = None
                age_sec: Optional[float] = None
                quote_age_status = "QUOTE_AGE_UNKNOWN"
                freshness_verified = False
                quote_freshness_status = "ACCEPTED_UNVERIFIED_TIMESTAMP"
                if raw_ts is not None and not isinstance(raw_ts, bool) and isinstance(raw_ts, (int, float)):
                    cand_ts = float(raw_ts)
                    if math.isfinite(cand_ts) and cand_ts > 0.0:
                        quote_ts = cand_ts
                        calc_age = round(eval_utc - quote_ts, 6)
                        if calc_age >= 0.0:
                            age_sec = calc_age
                            quote_age_status = f"{age_sec:.2f}s"
                            if (
                                observed_market_state in ("REGULAR", "OPEN")
                                and delay_metadata_present
                                and not is_delayed
                                and age_sec <= max_age
                            ):
                                freshness_verified = True
                                quote_freshness_status = "FRESHNESS_VERIFIED"
                            elif age_sec > max_age:
                                freshness_verified = False
                                quote_freshness_status = f"ACCEPTED_BY_DARVAS_POLICY_EXCEEDS_2S ({age_sec:.2f}s > {max_age:.2f}s)"
                            else:
                                freshness_verified = False
                                quote_freshness_status = f"ACCEPTED_BY_DARVAS_POLICY (state={observed_market_state}, delay_verified={delay_metadata_present and not is_delayed})"
                        else:
                            quote_age_status = "FUTURE_TIMESTAMP_INVALID"
                            quote_freshness_status = "ACCEPTED_UNVERIFIED_TIMESTAMP"

                is_current_session = m_open and observed_market_state not in ("CLOSED", "POST", "PRE", "POSTPOST", "PREPRE")
                ref_label = "LIVE_REFERENCE" if is_current_session else "HISTORICAL_REFERENCE"
                auth_latency_ms = round(max(0.0, (time.perf_counter_ns() - t6_start_ns) / 1_000_000.0), 3)
                total_cmp_ms = round(http_latency_ms + parse_latency_ms + auth_latency_ms, 3)

                GLOBAL_LATENCY_MONITOR.record_yahoo_request(
                    True,
                    http_latency_ms,
                    age_sec if quote_age_status not in ("QUOTE_AGE_UNKNOWN", "FUTURE_TIMESTAMP_INVALID") else None,
                    symbol=clean_sym,
                )
                res = QuoteResult(
                    is_valid=True,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    security_id=str(security_id or ""),
                    currency=observed_currency,
                    market_state=observed_market_state,
                    quote_timestamp=quote_ts,
                    age_sec=age_sec,
                    is_delayed=is_delayed,
                    delay_seconds=delay_seconds,
                    delay_metadata_present=delay_metadata_present,
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    auth_latency_ms=auth_latency_ms,
                    total_cmp_latency_ms=total_cmp_ms,
                    quote_age_status=quote_age_status,
                    freshness_verified=freshness_verified,
                    quote_freshness_status=quote_freshness_status,
                    cmp_policy="DARVAS_HTTP_SUCCESS",
                    reference_label=ref_label,
                    failure_reason="",
                )
                self._quote_cache[cache_key] = res
                self.last_quote_result = res
                return res

            # STRICT_TIMESTAMP Policy
            if market_state not in ("REGULAR", "OPEN"):
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Non-regular or closed market session state: '{market_state}'",
                )
                self.last_quote_result = res
                return res

            delay_metadata_present = (raw_delay is not None and not isinstance(raw_delay, bool) and isinstance(raw_delay, (int, float)))
            delay_seconds = float(raw_delay) if delay_metadata_present else (900.0 if seg == "BSE_EQ" else 0.0)
            is_delayed = (delay_seconds > 0.0) or (seg == "BSE_EQ")
            if is_delayed:
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    is_delayed=True,
                    delay_seconds=delay_seconds,
                    delay_metadata_present=delay_metadata_present,
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=(
                        f"Delayed quote rejected for live execution ({expected_ticker}, venue={seg}, "
                        f"delay={delay_seconds:g}s — BSE .BO / delayed feeds are prohibited for automated orders)"
                    ),
                )
                self.last_quote_result = res
                return res

            if raw_ts is None or isinstance(raw_ts, bool) or not isinstance(raw_ts, (int, float)):
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    quote_age_status="QUOTE_AGE_UNKNOWN",
                    cmp_policy=effective_policy,
                    failure_reason=f"Missing or invalid source quote timestamp (regularMarketTime) for {expected_ticker}",
                )
                self.last_quote_result = res
                return res

            quote_ts = float(raw_ts)
            if not math.isfinite(quote_ts) or quote_ts <= 0.0:
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    quote_age_status="QUOTE_AGE_UNKNOWN",
                    cmp_policy=effective_policy,
                    failure_reason=f"Non-positive or non-finite regularMarketTime ({raw_ts}) for {expected_ticker}",
                )
                self.last_quote_result = res
                return res

            age_sec = round(eval_utc - quote_ts, 6)
            if age_sec < 0.0:
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    quote_timestamp=quote_ts,
                    age_sec=age_sec,
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Future source quote timestamp rejected (age={age_sec:.3f}s < 0.0s)",
                )
                self.last_quote_result = res
                return res

            if age_sec > max_age:
                GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, age_sec)
                res = QuoteResult(
                    is_valid=False,
                    price=price,
                    source="YAHOO_FINANCE",
                    ticker=expected_ticker,
                    venue=observed_venue,
                    currency=observed_currency,
                    market_state=observed_market_state,
                    security_id=str(security_id or ""),
                    quote_timestamp=quote_ts,
                    age_sec=age_sec,
                    quote_age_status=f"{age_sec:.2f}s",
                    http_latency_ms=http_latency_ms,
                    parse_latency_ms=parse_latency_ms,
                    cmp_policy=effective_policy,
                    failure_reason=f"Stale source quote rejected: age {age_sec:.2f}s exceeds {max_age:.2f}s maximum",
                )
                self.last_quote_result = res
                return res

            auth_latency_ms = round(max(0.0, (time.perf_counter_ns() - t6_start_ns) / 1_000_000.0), 3)
            total_cmp_ms = round(http_latency_ms + parse_latency_ms + auth_latency_ms, 3)
            GLOBAL_LATENCY_MONITOR.record_yahoo_request(True, http_latency_ms, age_sec, symbol=clean_sym)
            res = QuoteResult(
                is_valid=True,
                price=price,
                source="YAHOO_FINANCE",
                ticker=expected_ticker,
                venue=observed_venue,
                security_id=str(security_id or ""),
                currency=observed_currency,
                market_state=observed_market_state,
                quote_timestamp=quote_ts,
                age_sec=age_sec,
                is_delayed=False,
                delay_seconds=float(raw_delay) if delay_metadata_present else None,
                delay_metadata_present=delay_metadata_present,
                http_latency_ms=http_latency_ms,
                parse_latency_ms=parse_latency_ms,
                auth_latency_ms=auth_latency_ms,
                total_cmp_latency_ms=total_cmp_ms,
                quote_age_status=f"{age_sec:.2f}s",
                freshness_verified=True,
                quote_freshness_status="FRESHNESS_VERIFIED",
                cmp_policy=effective_policy,
                reference_label="LIVE_REFERENCE",
                failure_reason="",
            )
            self._quote_cache[cache_key] = res
            self.last_quote_result = res
            return res

        except Exception as e:
            http_latency_ms = round(max(0.0, (time.perf_counter_ns() - t4_start_ns) / 1_000_000.0), 3)
            GLOBAL_LATENCY_MONITOR.record_yahoo_request(False, http_latency_ms, None)
            res = QuoteResult(
                is_valid=False,
                source="YAHOO_FINANCE",
                ticker=expected_ticker,
                venue="UNKNOWN",
                security_id=str(security_id or ""),
                http_latency_ms=http_latency_ms,
                cmp_policy=effective_policy,
                failure_reason=f"Yahoo Finance exception for {expected_ticker}: {e}",
            )
            self.last_quote_result = res
            return res

    def _fetch_ltp(
        self,
        stock_symbol: str,
        exchange_segment: str = "NSE_EQ",
        now_utc: Optional[float] = None,
        max_quote_age_sec: Optional[float] = None,
        cmp_policy: Optional[str] = None,
    ) -> Optional[float]:
        ok, price, _ = self.fetch_yahoo_ltp(
            stock_symbol,
            exchange_segment=exchange_segment,
            now_utc=now_utc,
            max_quote_age_sec=max_quote_age_sec,
            cmp_policy=cmp_policy,
        )
        return price if ok else None

    def fetch_yahoo_ltp(
        self,
        stock_symbol: str,
        exchange_segment: str = "NSE_EQ",
        security_id: str = "",
        now_utc: Optional[float] = None,
        max_quote_age_sec: Optional[float] = None,
        cmp_policy: Optional[str] = None,
    ) -> Tuple[bool, float, str]:
        q = self.get_yahoo_quote_details(
            stock_symbol=stock_symbol,
            exchange_segment=exchange_segment,
            security_id=security_id,
            now_utc=now_utc,
            max_quote_age_sec=max_quote_age_sec,
            allow_cached=False,
            cmp_policy=cmp_policy,
        )
        if q.is_valid:
            age_label = q.quote_age_status or (f"{q.age_sec:.2f}s" if q.age_sec is not None else "QUOTE_AGE_UNKNOWN")
            return True, q.price, f"LTP retrieved via Yahoo Finance ({q.ticker}, age={age_label}, policy={q.cmp_policy})"
        return False, 0.0, q.failure_reason

    def get_ltp(
        self,
        exchange_segment: str,
        security_id: str,
        retry: bool = True,
        symbol: Optional[str] = None,
        now_utc: Optional[float] = None,
        max_quote_age_sec: Optional[float] = None,
        cmp_policy: Optional[str] = None,
    ) -> Tuple[bool, float, str]:
        seg = (exchange_segment or "").strip().upper()

        if seg in ("NSE_FNO", "BSE_FNO") and symbol and not self.token:
            q = self.get_yahoo_quote_details(
                stock_symbol=symbol,
                exchange_segment=seg,
                security_id=security_id,
                now_utc=now_utc,
                max_quote_age_sec=max_quote_age_sec,
                cmp_policy=cmp_policy,
            )
            return False, 0.0, q.failure_reason

        effective_policy = str(cmp_policy or getattr(self.cfg, "equity_cmp_execution_policy", "STRICT_TIMESTAMP") or "STRICT_TIMESTAMP").upper().strip()

        if symbol and seg in ("NSE_EQ", "BSE_EQ"):
            yf_ok, yf_ltp, yf_msg = self.fetch_yahoo_ltp(
                stock_symbol=symbol,
                exchange_segment=seg,
                security_id=security_id,
                now_utc=now_utc,
                max_quote_age_sec=max_quote_age_sec,
                cmp_policy=effective_policy,
            )
            if yf_ok and yf_ltp > 0:
                return True, yf_ltp, yf_msg
            # Never silently substitute an unverified Dhan marketfeed price after a Yahoo failure
            return False, 0.0, yf_msg

        if seg in ("NSE_EQ", "BSE_EQ") and effective_policy == "DARVAS_HTTP_SUCCESS":
            return (
                False,
                0.0,
                "DARVAS_HTTP_SUCCESS specifies Yahoo Finance as the executable CMP source; unverified Dhan marketfeed substitution is prohibited",
            )

        if not self.token:
            return False, 0.0, "No valid fresh quote from Yahoo Finance and no Dhan access token configured"

        url = f"{BASE_URL}/marketfeed/ltp"
        sec_key = int(security_id) if str(security_id).isdigit() else str(security_id)
        payload = {exchange_segment: [sec_key]}
        try:
            t_req_start = time.time()
            sent_headers = self._headers()
            resp = self.session.post(url, headers=sent_headers, json=payload, timeout=5)
            http_elapsed = max(0.0, time.time() - t_req_start)
            eval_utc = (float(now_utc) + (http_elapsed if http_elapsed >= 0.05 else 0.0)) if now_utc is not None else time.time()
            max_age = float(max_quote_age_sec) if max_quote_age_sec is not None else float(getattr(self.cfg, "max_quote_age_sec", 2.0))
            if resp.status_code == 200:
                data = resp.json()
                seg_data = data.get("data", {}).get(exchange_segment, {})
                sec_data = seg_data.get(str(security_id), {})
                ltp = float(sec_data.get("last_price", 0.0))
                if ltp > 0 and math.isfinite(ltp):
                    raw_src_ts = (
                        sec_data.get("last_trade_time")
                        if sec_data.get("last_trade_time") is not None
                        else (
                            sec_data.get("quoteTimestamp")
                            if sec_data.get("quoteTimestamp") is not None
                            else sec_data.get("timestamp")
                        )
                    )
                    src_ts: Optional[float] = None
                    if raw_src_ts is not None and not isinstance(raw_src_ts, bool) and isinstance(raw_src_ts, (int, float)):
                        cand_ts = float(raw_src_ts)
                        if math.isfinite(cand_ts) and cand_ts > 0.0:
                            src_ts = cand_ts
                            src_age = round(eval_utc - src_ts, 6)
                            if src_age < 0.0:
                                return False, 0.0, f"Future Dhan LTP source timestamp rejected (age={src_age:.2f}s < 0.0s)"
                            if src_age > max_age:
                                return False, 0.0, f"Stale Dhan LTP source timestamp rejected (age={src_age:.2f}s > {max_age:.2f}s)"
                    if seg in ("NSE_EQ", "BSE_EQ") and src_ts is None:
                        return False, 0.0, "Unverified Dhan marketfeed LTP rejected: missing source quote timestamp (last_trade_time)"
                    self.last_ltp_meta = {
                        "price": ltp,
                        "exchange_segment": exchange_segment,
                        "security_id": str(security_id),
                        "source_quote_timestamp": src_ts,
                        "local_retrieved_at": eval_utc,
                        "timestamp_type": "SOURCE_TIMESTAMP" if src_ts is not None else "LOCAL_RETRIEVAL",
                    }
                    return True, ltp, "LTP retrieved successfully from Dhan"
                return False, 0.0, f"LTP is 0 or missing in Dhan response: {resp.text}"
            elif retry and self._requires_token_refresh(resp.status_code, resp.text):
                if "806" not in resp.text and self.cfg.dhan_pin and self.cfg.dhan_totp_secret:
                    ok, _, _ = self.generate_token_with_totp(
                        force=False, rejected_token=sent_headers.get("access-token", "")
                    )
                    if ok:
                        return self.get_ltp(
                            exchange_segment, security_id, retry=False, symbol=symbol,
                            now_utc=now_utc, max_quote_age_sec=max_quote_age_sec,
                        )
                return False, 0.0, f"Dhan auth error ({resp.status_code}): {resp.text}"
            return False, 0.0, f"Dhan LTP API error ({resp.status_code}): {resp.text}"
        except Exception as e:
            return False, 0.0, f"HTTP exception fetching LTP: {e}"

    def get_order_by_correlation_id(self, correlation_id: str) -> Optional[Dict[str, Any]]:
        """
        Queries Dhan external correlation endpoint: GET /v2/orders/external/{correlation-id}.
        Provides durable order status lookup after crash or lost network ACK.
        """
        if self.cfg.trading_mode == TradingMode.TEST:
            return None

        url = f"{BASE_URL}/orders/external/{correlation_id}"
        try:
            resp = self._get_with_auth_recovery(url)
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list):
                    return data[0] if data and isinstance(data[0], dict) else None
                return data if isinstance(data, dict) and data.get("orderId") else None
            return None
        except Exception as e:
            logger.error(f"HTTP exception fetching order by correlation {correlation_id}: {e}")
            return None

    # =========================================================================
    # SAFETY CORRECTION C.A: Structured Broker Collection Reads
    # =========================================================================

    def _requires_token_refresh(self, status_code: int, body: str) -> bool:
        """Only refresh 403 when Dhan explicitly indicates token auth failure."""
        if status_code not in (401, 403) or not self.is_token_error(status_code, body):
            return False
        if status_code == 401:
            return True
        auth_text = str(body or "").lower()
        return any(marker in auth_text for marker in (
            "dh-901", "invalid_authentication", "invalid authentication",
            "invalid token", "token invalid", "token expired", "token is expired",
            "expired token", "access token expired", "access token is invalid",
            "jwt expired", "jwt invalid", "session expired",
            '"errorcode":"807"', '"errorcode":"808"', '"errorcode":"809"',
            '"errorcode": "807"', '"errorcode": "808"', '"errorcode": "809"',
        ))

    def _log_throttled_broker_auth_error(self, label: str, reason: str) -> None:
        """Keep an actionable warning without flooding systemd every two seconds."""
        state = getattr(self, "_auth_log_at", None)
        if not isinstance(state, dict):
            state = {}
            self._auth_log_at = state
        key = str(label)
        now = time.monotonic()
        last = state.get(key, -float("inf"))
        if now - last >= BROKER_AUTH_LOG_INTERVAL_SEC:
            logger.error("%s (repeated authentication errors are rate-limited)", reason)
            state[key] = now

    @staticmethod
    def _is_rate_limited_response(response) -> bool:
        if int(getattr(response, "status_code", 0) or 0) == 429:
            return True
        try:
            payload = response.json()
            if isinstance(payload, dict):
                code = str(payload.get("errorCode") or payload.get("internalErrorCode") or "").strip().upper()
                if code in ("DH-904", "805"):
                    return True
                inner = payload.get("data")
                if isinstance(inner, dict):
                    inner_code = str(inner.get("errorCode") or inner.get("internalErrorCode") or "").strip().upper()
                    if inner_code in ("DH-904", "805"):
                        return True
            return False
        except Exception:
            return False

    def _get_active_read_governor(self):
        from src.broker.read_governor import ReadGovernor
        gov = getattr(self, "_read_governor", None)
        if isinstance(gov, ReadGovernor):
            cfg_obj = getattr(self, "cfg", None)
            cur_acct = str(getattr(cfg_obj, "dhan_client_id", "") or "").strip()
            if gov.account_id != cur_acct:
                self._halt_for_read_deferral()
                raise ValueError("Dhan account configuration changed: recreate and verify the broker client before reads")
        return gov

    def _halt_for_read_deferral(self):
        gate = getattr(self, "reconciliation_gate", None)
        if gate is not None and hasattr(gate, "halt_new_entries"):
            state = getattr(gate, "state", None)
            state_name = getattr(state, "value", state)
            # ReconciliationState.BLOCKED is an Enum, not the literal "BLOCKED".
            # Repeated local deferrals must not spam halt events and SQLite.
            if getattr(gate, "is_accepting_entries", False) or str(state_name).upper() != "BLOCKED":
                gate.halt_new_entries(
                    "Dhan read throttled/unavailable: fresh broker evidence required before new entries"
                )

    def _read_deferral_response(self, exc):
        from src.broker.read_governor import ReadDeferred
        self._halt_for_read_deferral()
        result = requests.Response()
        result.status_code = 429 if isinstance(exc, ReadDeferred) else 503
        result._content = str(exc).encode("utf-8")
        result.headers["X-AuditBot-Local-Deferral"] = "1"
        if isinstance(exc, ReadDeferred):
            result.headers["Retry-After"] = str(exc.seconds)
        return result

    def _governed_get(self, url, *, headers, timeout, priority=None):
        """All Dhan GETs, including candidate-profile and auth retry, share admission."""
        from src.broker.read_governor import ReadDeferred
        governor = self._get_active_read_governor()
        try:
            if governor is not None:
                from urllib.parse import urlsplit
                path = urlsplit(url).path
                historical = bool(re.fullmatch(r"/v2/trades/\d{4}-\d{2}-\d{2}/\d{4}-\d{2}-\d{2}/\d+", path))
                if priority is not None:
                    get_priority = priority
                elif (path == "/v2/fundlimit"
                      and getattr(self, "_identity_verification_context", False)):
                    # Only the dedicated post-refresh funds probe can use the
                    # identity reserve; other routine funds readers cannot.
                    get_priority = "identity"
                elif path == "/v2/orders" or path.startswith("/v2/orders/external/"):
                    get_priority = "low"
                else:
                    get_priority = "normal"
                governor.admit(historical=historical, priority=get_priority)
        except (ReadDeferred, OSError, sqlite3.Error) as exc:
            return self._read_deferral_response(exc)
        # Transport exceptions retain the callers' UNAVAILABLE classification.
        response = self.session.get(url, headers=headers, timeout=timeout)
        if self._is_rate_limited_response(response):
            self._halt_for_read_deferral()
            if governor is not None:
                try:
                    governor.throttled(getattr(response, "headers", {}).get("Retry-After"))
                except (OSError, sqlite3.Error) as exc:
                    return self._read_deferral_response(exc)
            if int(response.status_code) != 429:
                result = requests.Response()
                result.status_code = 429
                result._content = b'{"errorCode":"DH-904","errorMessage":"Broker rate limit"}'
                return result
        elif governor is not None and hasattr(governor, "record_success"):
            status_code = int(getattr(response, "status_code", 0) or 0)
            if 200 <= status_code < 300:
                governor.record_success()
        return response

    def _get_with_auth_recovery(
        self, url: str, *, timeout: float = 5, allow_refresh: bool = True,
        priority: Optional[str] = None,
    ) -> requests.Response:
        """One coordinated token recovery and one read-only GET retry on Dhan 401/403.

        C5 (P1): Uses a bounded single-flight asynchronous auth coordinator per token path/account
        so a slow or hanging `auth.dhan.co` TOTP endpoint (>= 2s or >= 8s) never blocks the caller
        or stalls the 2-second ProtectionWatcher loop. Fast unit-test mocks (< 50ms) complete inline
        within the 50ms grace window; slow network refreshes continue in the single background worker
        while the current read returns the 401/403 response (`BrokerReadFailure` / `None`, never `[]`).
        Never retries POST/PUT/DELETE or any order submission.
        """
        import os as _os
        import threading as _threading

        headers = self._headers()
        sent_token = headers.get("access-token", "")
        admission_options = {"priority": priority} if priority is not None else {}
        response = self._governed_get(
            url, headers=headers, timeout=timeout, **admission_options
        )
        status = int(getattr(response, "status_code", 0) or 0)
        error_text = str(getattr(response, "text", "") or "")
        if not allow_refresh or not self._requires_token_refresh(status, error_text):
            return response

        rejected = sent_token
        self._sync_shared_token_from_disk()
        if self.token and self.token != rejected:
            logger.warning("Dhan read auth rejected; adopting updated shared token.")
        elif self.cfg.dhan_client_id and self.cfg.dhan_pin and self.cfg.dhan_totp_secret:
            coord_lock, inflight_map = globals().setdefault(
                "_ASYNC_AUTH_COORD_STATE", (_threading.Lock(), {})
            )
            raw_tok_file = str(getattr(self.cfg, "dhan_token_file", "") or "").strip()
            path_key = (
                _os.path.realpath(_os.path.abspath(_os.path.expanduser(raw_tok_file)))
                if raw_tok_file else f"client:{id(self)}"
            )
            account_key = str(getattr(self.cfg, "dhan_client_id", "") or "").strip()
            coord_key = (path_key, account_key)
            with coord_lock:
                # A misconfigured shared token file for DIFFERENT Dhan accounts
                # must not cause a token from one account to be published/adopted
                # by the other's authentication recovery worker.
                conflicting = any(
                    key[0] == path_key and key[1] != account_key
                    and item["thread"].is_alive()
                    for key, item in inflight_map.items()
                )
                if conflicting:
                    logger.error(
                        "Dhan async recovery blocked: distinct accounts share one active token-file path"
                    )
                    return response
                existing = inflight_map.get(coord_key)
                if existing is not None and existing["thread"].is_alive():
                    done_event = existing["done_event"]
                else:
                    done_event = _threading.Event()
                    result_box = {"ok": False, "msg": "in_progress"}

                    def _auth_worker() -> None:
                        try:
                            ok_w, _, msg_w = self.generate_token_with_totp(
                                force=False, rejected_token=rejected
                            )
                            result_box["ok"] = bool(ok_w)
                            result_box["msg"] = str(msg_w or "")
                        except Exception as exc:
                            result_box["ok"] = False
                            result_box["msg"] = type(exc).__name__
                        finally:
                            done_event.set()

                    worker = _threading.Thread(
                        target=_auth_worker,
                        name="dhan-auth-recovery",
                        daemon=True,
                    )
                    inflight_map[coord_key] = {
                        "thread": worker,
                        "done_event": done_event,
                        "result": result_box,
                    }
                    worker.start()

            # Short grace for mocks and fast shared-token adoption only; slow
            # auth network I/O NEVER blocks the protection watcher cycle.
            if not done_event.wait(timeout=0.05):
                return response
            # A successful worker writes through the per-file flock. Every
            # caller re-reads *its own* shared file; there is no broadcast of
            # token strings into unrelated DhanClient instances.
            self._sync_shared_token_from_disk()
        else:
            return response

        retry_headers = self._headers()
        retry_token = retry_headers.get("access-token", "")
        if not retry_token or retry_token == rejected:
            return response
        # A successful/failed second GET is terminal for this call. It must
        # never trigger a second token generation or a trading order replay.
        return self._governed_get(
            url, headers=retry_headers, timeout=timeout, **admission_options
        )

    def _read_collection(
        self,
        path_suffix: str,
        label: str,
        bypass_test_mode: bool = False,
    ) -> Union[BrokerReadList, BrokerReadFailure]:
        """
        Safety Correction C.A: Distinguishes:
        1. Successful response with zero records -> `BrokerReadList([], status="OK_EMPTY")`
        2. Successful response with records -> `BrokerReadList(records, status="OK_RECORDS")`
        3. Failed, malformed, or unavailable response -> `BrokerReadFailure(status=..., error=...)` (never `[]`)
        """
        if getattr(self.cfg, "trading_mode", None) == TradingMode.TEST and not bypass_test_mode:
            return BrokerReadList([], status=BrokerReadStatus.OK_EMPTY.value, status_code=200)

        url = f"{BASE_URL}{path_suffix}"
        try:
            resp = self._get_with_auth_recovery(url)
            status_code = int(getattr(resp, "status_code", 0) or 0)
            if status_code == 200:
                try:
                    data = resp.json()
                except Exception as e:
                    err = f"Malformed JSON in {label} response: {e}"
                    logger.error(err)
                    return BrokerReadFailure(status=BrokerReadStatus.MALFORMED.value, error=err, status_code=status_code)

                if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
                    err = f"Malformed {label} payload: expected list of dicts, got {type(data).__name__}"
                    logger.error(err)
                    return BrokerReadFailure(status=BrokerReadStatus.MALFORMED.value, error=err, status_code=status_code)

                return BrokerReadList(
                    data,
                    status=BrokerReadStatus.OK_RECORDS.value if len(data) > 0 else BrokerReadStatus.OK_EMPTY.value,
                    status_code=200,
                )

            err_text = str(getattr(resp, "text", "") or "")
            # X-AuditBot-Local-Deferral denotes a SYNTHETIC 429: no Dhan
            # request was sent. Return an unavailable sentinel without
            # mislabelling it as a broker throttle or spamming 5 errors.
            if str(getattr(resp, "headers", {}).get("X-AuditBot-Local-Deferral") or "") == "1":
                return BrokerReadFailure(
                    status=BrokerReadStatus.UNAVAILABLE.value,
                    error=f"Local GET admission deferred for {label}",
                    status_code=status_code,
                )
            err = f"Dhan {label} read failed (HTTP {status_code}): {err_text}"
            if self._requires_token_refresh(status_code, err_text):
                self._log_throttled_broker_auth_error(label, err)
            else:
                logger.error(err)
            return BrokerReadFailure(status=BrokerReadStatus.FAILED.value, error=err, status_code=status_code)
        except Exception as e:
            err = f"HTTP exception fetching {label}: {e}"
            logger.error(err)
            return BrokerReadFailure(status=BrokerReadStatus.UNAVAILABLE.value, error=err, status_code=0)

    def get_order_book(self, bypass_test_mode: bool = False) -> Union[BrokerReadList, BrokerReadFailure]:
        """Retrieves today's complete order book: GET /v2/orders."""
        return self._read_collection("/orders", "order_book", bypass_test_mode=bypass_test_mode)

    def get_super_orders(self, bypass_test_mode: bool = False) -> Union[BrokerReadList, BrokerReadFailure]:
        """V12-05: Retrieves all Super Orders with nested legDetails: GET /v2/super/orders."""
        return self._read_collection("/super/orders", "super_orders", bypass_test_mode=bypass_test_mode)

    def get_trade_book(self, bypass_test_mode: bool = False) -> Union[BrokerReadList, BrokerReadFailure]:
        """Retrieves today's trade executions: GET /v2/trades."""
        return self._read_collection("/trades", "trade_book", bypass_test_mode=bypass_test_mode)

    def get_positions(self, bypass_test_mode: bool = False) -> Union[BrokerReadList, BrokerReadFailure]:
        """Retrieves net positions: GET /v2/positions."""
        return self._read_collection("/positions", "positions", bypass_test_mode=bypass_test_mode)

    def get_holdings(self, bypass_test_mode: bool = False) -> Union[BrokerReadList, BrokerReadFailure]:
        """Retrieves delivery, T1 and MTF holdings: GET /v2/holdings."""
        return self._read_collection("/holdings", "holdings", bypass_test_mode=bypass_test_mode)

    def get_forever_orders(self, bypass_test_mode: bool = False) -> Union[BrokerReadList, BrokerReadFailure]:
        """Retrieves all Forever OCO orders: GET /v2/forever/orders."""
        return self._read_collection("/forever/orders", "forever_orders", bypass_test_mode=bypass_test_mode)

    # =========================================================================
    # SAFETY CORRECTION B & C: Authoritative Broker Protection Verification
    # =========================================================================

    def evaluate_forever_oco_protection(
        self,
        forever_order_id: str,
        expected_security_id: Optional[str] = None,
        expected_qty: Optional[int] = None,
        expected_sl_trigger: Optional[float] = None,
        expected_target_price: Optional[float] = None,
        tick_size: float = 0.05,
        expected_segment: Optional[str] = None,
        expected_product_type: Optional[str] = None,
        forever_orders_snapshot: Optional[Any] = None,
    ) -> ProtectionVerificationResult:
        if not forever_order_id:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                reason="Missing forever_order_id",
            )

        orders = forever_orders_snapshot if forever_orders_snapshot is not None else self.get_forever_orders()
        if isinstance(orders, BrokerReadFailure) or getattr(orders, "ok", True) is False or not isinstance(orders, list):
            err_msg = getattr(orders, "error", "Forever order book read failed or malformed")
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=str(forever_order_id),
                reason=f"Forever order {forever_order_id} unverified: {err_msg}",
            )

        if not orders:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.UNVERIFIED,
                is_verified=False,
                group_id=str(forever_order_id),
                reason=f"Forever order {forever_order_id} not found in broker forever book (empty book)",
            )

        matching_rows = [
            r for r in orders
            if isinstance(r, dict) and str(r.get("orderId", "")) == str(forever_order_id)
        ]
        return verify_forever_oco_group(
            matching_rows=matching_rows,
            forever_order_id=str(forever_order_id),
            expected_security_id=expected_security_id,
            expected_qty=expected_qty,
            expected_sl_trigger=expected_sl_trigger,
            expected_target_price=expected_target_price,
            tick_size=tick_size,
            expected_account_id=self.cfg.dhan_client_id,
            expected_segment=expected_segment,
            expected_product_type=expected_product_type,
        )

    def verify_forever_leg_active(
        self,
        forever_order_id: str,
        expected_security_id: Optional[str] = None,
        expected_qty: Optional[int] = None,
        expected_sl_trigger: Optional[float] = None,
        expected_target_price: Optional[float] = None,
        tick_size: float = 0.05,
        expected_segment: Optional[str] = None,
        expected_product_type: Optional[str] = None,
    ) -> Tuple[bool, str]:
        res = self.evaluate_forever_oco_protection(
            forever_order_id=forever_order_id,
            expected_security_id=expected_security_id,
            expected_qty=expected_qty,
            expected_sl_trigger=expected_sl_trigger,
            expected_target_price=expected_target_price,
            tick_size=tick_size,
            expected_segment=expected_segment,
            expected_product_type=expected_product_type,
        )
        return res.is_verified, res.reason

    def evaluate_super_order_protection(
        self,
        order_id: str,
        expected_security_id: Optional[str] = None,
        expected_qty: Optional[int] = None,
        expected_sl_price: Optional[float] = None,
        expected_target_price: Optional[float] = None,
        tick_size: float = 0.05,
        expected_segment: Optional[str] = None,
        expected_product_type: Optional[str] = None,
        super_orders_snapshot: Optional[Any] = None,
    ) -> ProtectionVerificationResult:
        if not order_id:
            return ProtectionVerificationResult(
                status=ProtectionVerificationStatus.TERMINAL_OR_INVALID,
                is_verified=False,
                is_terminal_or_invalid=True,
                reason="Missing super order_id",
            )

        candidate: Optional[Dict[str, Any]] = None
        super_book = super_orders_snapshot if super_orders_snapshot is not None else self.get_super_orders()
        if isinstance(super_book, list):
            for row in super_book:
                if isinstance(row, dict) and str(row.get("orderId", "")) == str(order_id):
                    candidate = row
                    break

        if candidate is None:
            st = self.order_status(order_id)
            if isinstance(st, dict):
                candidate = st

        return verify_super_order_record(
            candidate=candidate,
            order_id=str(order_id),
            expected_security_id=expected_security_id,
            expected_qty=expected_qty,
            expected_sl_price=expected_sl_price,
            expected_target_price=expected_target_price,
            tick_size=tick_size,
            expected_account_id=self.cfg.dhan_client_id,
            expected_segment=expected_segment,
            expected_product_type=expected_product_type,
        )

    def verify_super_order_legs_active(
        self,
        order_id: str,
        expected_security_id: Optional[str] = None,
        expected_qty: Optional[int] = None,
        expected_sl_price: Optional[float] = None,
        expected_target_price: Optional[float] = None,
        tick_size: float = 0.05,
        expected_segment: Optional[str] = None,
        expected_product_type: Optional[str] = None,
    ) -> Tuple[bool, str]:
        """
        Safety Correction B: Verifies that a Super Order has both `STOP_LOSS_LEG` and `TARGET_LEG`
        actively resting with required quantities, prices, and identity.
        Never accepts top-level `stopLossPrice`/`targetPrice` alone or `TRADED` legs.
        """
        res = self.evaluate_super_order_protection(
            order_id=order_id,
            expected_security_id=expected_security_id,
            expected_qty=expected_qty,
            expected_sl_price=expected_sl_price,
            expected_target_price=expected_target_price,
            tick_size=tick_size,
            expected_segment=expected_segment,
            expected_product_type=expected_product_type,
        )
        return res.is_verified, res.reason

    def _reconcile_uncertain_submission(self, corr_id: str, expected_security_id: str) -> Tuple[bool, Optional[str], str]:
        found = self.get_order_by_correlation_id(corr_id)
        if not found:
            ob = self.get_order_book()
            if isinstance(ob, list):
                for row in ob:
                    if isinstance(row, dict) and str(row.get("correlationId") or "") == corr_id:
                        found = row
                        break

        if isinstance(found, dict) and found.get("orderId"):
            sec = str(found.get("securityId") or "").strip()
            if sec and expected_security_id and sec != str(expected_security_id):
                return False, None, f"Reconciled correlation {corr_id} has mismatched securityId ({sec} != {expected_security_id})"
            st = str(found.get("orderStatus") or "PENDING").upper()
            if st == "REJECTED":
                return False, None, f"Reconciled order {found['orderId']} was REJECTED at Dhan"
            return True, str(found["orderId"]), f"Order {found['orderId']} confirmed via correlation reconciliation ({st})"

        return False, None, f"Ambiguous/uncertain response for correlation {corr_id}: outcome UNKNOWN (automatic resubmission prohibited)"

    def place_order(self, order_req: OrderRequest, retry: bool = True) -> Tuple[bool, Optional[str], str]:
        if order_req.transaction_type != TransactionType.BUY:
            return False, None, f"MUTATION BLOCKED: Direct {order_req.transaction_type} orders are forbidden on BUY-ONLY entry path"

        # AMO is a documented Dhan /orders flag. Keep independent segment
        # switches and do not allow naked F&O order entry in other cases.
        is_amo = bool(getattr(order_req, "after_market_order", False))
        is_fno_amo = is_amo and str(order_req.exchange_segment).upper() == "NSE_FNO"
        if is_amo:
            segment = str(order_req.exchange_segment).upper()
            if segment == "NSE_EQ":
                if (not bool(getattr(self.cfg, "equity_amo_enabled", False))
                        or order_req.product_type != ProductType.CNC):
                    return False, None, "Equity AMO BLOCKED: NSE_EQ CNC toggle/route invalid"
            elif segment == "NSE_FNO":
                if (not bool(getattr(self.cfg, "fno_amo_enabled", False))
                        or order_req.product_type != ProductType.MARGIN):
                    return False, None, "F&O AMO BLOCKED: NSE_FNO MARGIN toggle/route invalid"
            else:
                return False, None, (
                    "AMO BLOCKED: Only NSE_EQ CNC LIMIT or NSE_FNO MARGIN LIMIT "
                    "with amoTime=OPEN is supported (unsupported exchange segment)"
                )
            if (order_req.order_type != OrderType.LIMIT
                    or str(getattr(order_req, "amo_time", "OPEN")).upper() != "OPEN"
                    or not str(order_req.security_id).strip()
                    or int(order_req.quantity) <= 0 or float(order_req.price) <= 0):
                return False, None, "AMO BLOCKED: Requires positive LIMIT price/quantity, securityId and OPEN"
            if segment == "NSE_FNO":
                # Our 15:25 trading gate closes before Dhan's 15:30 F&O
                # AMO window begins. Refuse the 5-minute unsafe overlap.
                now_ist = datetime.now(ZoneInfo("Asia/Kolkata"))
                if (now_ist.weekday() < 5
                        and clock_time(9, 15) <= now_ist.time() < clock_time(15, 30)):
                    return False, None, "F&O AMO BLOCKED: Dhan F&O AMO window not yet open (15:30 IST)"
            from src.engine.market import market_status
            m_open, m_reason = market_status()
            if m_open or not m_reason.startswith((
                "Market Pre-Open / Closed", "Market Closed Post-Hours",
                "Market Closed (Saturday)", "Market Closed (Sunday)",
                "Market Closed (Exchange Holiday",
            )):
                return False, None, f"AMO BLOCKED: Not an eligible closed-market session ({m_reason})"

        corr_id = order_req.correlation_id[:30]
        if hasattr(self.stop_manager, "try_begin_mutation"):
            allowed, st = self.stop_manager.try_begin_mutation(corr_id)
            if not allowed:
                reason_msg = (
                    f"MUTATION BLOCKED: Durable EMERGENCY STOP active "
                    f"(triggered by {st.get('stopped_by')}: {st.get('reason')})"
                )
                logger.critical(f"[STOPPED] {reason_msg}")
                return False, None, reason_msg
        elif self.stop_manager.is_stopped():
            st = self.stop_manager.get_state()
            reason_msg = (
                f"MUTATION BLOCKED: Durable EMERGENCY STOP active "
                f"(triggered by {st.get('stopped_by')}: {st.get('reason')})"
            )
            logger.critical(f"[STOPPED] {reason_msg}")
            return False, None, reason_msg
        else:
            self.stop_manager.register_in_flight(corr_id)

        if self.reconciliation_gate and not self.reconciliation_gate.is_accepting_entries:
            self.stop_manager.deregister_in_flight(corr_id)
            reason_msg = "MUTATION BLOCKED: Startup reconciliation gate is CLOSED (broker state unverified)"
            logger.critical(f"[GATE_CLOSED] {reason_msg}")
            return False, None, reason_msg

        if self.cfg.trading_mode == TradingMode.TEST:
            self.stop_manager.deregister_in_flight(corr_id)
            return False, None, "ORDER BLOCKED: System is in TEST mode (Zero live orders allowed)"

        # B05: Enforce durable transition gate on all risk-increasing BUY entries (including RTRY- retry orders)
        intent_type = str(getattr(order_req, "intent_type", "NEW_ENTRY") or "NEW_ENTRY").upper()
        is_protective_exit = (order_req.transaction_type == TransactionType.SELL and intent_type == "PROTECTIVE_EXIT")
        if not is_protective_exit:
            try:
                from src.engine.config_manager import ConfigChangeTracker
                t_blocked, t_reason = ConfigChangeTracker(data_dir=self.cfg.data_dir).is_live_entry_blocked_by_transition()
                if t_blocked:
                    self.stop_manager.deregister_in_flight(corr_id)
                    reason_msg = f"MUTATION BLOCKED: {t_reason}"
                    logger.warning(f"[TRANSITION_GATE] {reason_msg}")
                    return False, None, reason_msg
            except Exception as e:
                self.stop_manager.deregister_in_flight(corr_id)
                return False, None, f"MUTATION BLOCKED: Could not verify mode transition gate (failing closed): {e}"

        url = f"{BASE_URL}/orders"
        payload = {
            "dhanClientId": self.cfg.dhan_client_id,
            "correlationId": corr_id,
            "transactionType": "BUY",
            "exchangeSegment": order_req.exchange_segment,
            "productType": order_req.product_type.value,
            "orderType": "LIMIT",
            "validity": "DAY",
            "securityId": str(order_req.security_id),
            "quantity": int(order_req.quantity),
            "price": float(order_req.price),
            "triggerPrice": 0.0,
            "disclosedQuantity": 0,
            "afterMarketOrder": is_amo,
        }
        if is_amo:
            payload["amoTime"] = "OPEN"

        uncertain_outcome = False
        self.last_order_http_latency_ms = None
        t_order_start_ns = time.perf_counter_ns()
        try:
            resp = self._broker_mutating_http("POST", url, headers=self._headers(), json=payload, timeout=5)
            self.last_order_http_latency_ms = round(max(0.0, (time.perf_counter_ns() - t_order_start_ns) / 1_000_000.0), 3)
            if resp.status_code in (200, 201):
                data = resp.json() if resp.text else {}
                raw_order_id = data.get("orderId", "")
                order_id = str(raw_order_id).strip() if raw_order_id is not None else ""
                if is_fno_amo and (not order_id.isascii() or not order_id.isdecimal() or len(order_id) < 6):
                    # No acknowledgement without an authentic Dhan order ID.
                    # Never resubmit an UNKNOWN broker outcome automatically.
                    uncertain_outcome = True
                    return False, None, "F&O AMO outcome UNKNOWN: Dhan did not return a valid order ID; manually reconcile correlation ID"
                if not order_id:
                    uncertain_outcome = True
                    rec_ok, rec_oid, rec_msg = self._reconcile_uncertain_submission(corr_id, str(order_req.security_id))
                    if rec_ok and rec_oid:
                        uncertain_outcome = False
                    return rec_ok, rec_oid, rec_msg
                raw_ord_st = str(data.get("orderStatus", "")).upper().strip()
                self.last_order_broker_status = raw_ord_st or "TRANSIT"
                if raw_ord_st == "REJECTED":
                    return False, None, f"Dhan order rejected by RMS: {data}"
                if is_fno_amo:
                    if raw_ord_st in ("CANCELLED", "EXPIRED", "FAILED"):
                        return False, None, f"F&O AMO not accepted by Dhan (status={raw_ord_st})"
                    if raw_ord_st not in ("TRANSIT", "PENDING"):
                        uncertain_outcome = True
                        return False, order_id, f"F&O AMO outcome UNKNOWN: unverified broker status={raw_ord_st or 'MISSING'}"
                return True, order_id, f"Order acknowledged by Dhan (status={self.last_order_broker_status})"
            elif self.is_token_error(resp.status_code, resp.text):
                uncertain_outcome = True
                if is_fno_amo:
                    return False, None, f"F&O AMO outcome UNKNOWN: Dhan authentication failure ({resp.status_code}); manual correlation reconciliation required"
                if self.cfg.dhan_pin and self.cfg.dhan_totp_secret:
                    logger.warning(f"Dhan auth error on /orders ({corr_id}). Refreshing token for read-reconciliation only (no resubmission)...")
                    self.generate_token_with_totp(force=False, rejected_token=self.token)
                rec_ok, rec_oid, rec_msg = self._reconcile_uncertain_submission(corr_id, str(order_req.security_id))
                if rec_ok and rec_oid:
                    uncertain_outcome = False
                    return True, rec_oid, rec_msg
                return False, None, f"Dhan auth error ({resp.status_code}) on {corr_id}; {rec_msg}"
            elif resp.status_code >= 500 or resp.status_code == 408:
                uncertain_outcome = True
                if is_fno_amo:
                    return False, None, f"F&O AMO outcome UNKNOWN: Dhan HTTP {resp.status_code}; check Dhan order book before resubmission"
                rec_ok, rec_oid, rec_msg = self._reconcile_uncertain_submission(corr_id, str(order_req.security_id))
                if rec_ok and rec_oid:
                    uncertain_outcome = False
                    return True, rec_oid, rec_msg
                return False, None, f"Dhan HTTP {resp.status_code} server error on {corr_id} (outcome UNKNOWN): {resp.text}"
            else:
                return False, None, f"Dhan order placement rejected ({resp.status_code}): {resp.text}"
        except BrokerMutationNotSubmitted as e:
            # Config barrier denied before the broker HTTP call. This is
            # NOT_SUBMITTED, not an unknown Dhan acknowledgement. Never strand
            # an emergency-stop in-flight intent for a request never sent.
            uncertain_outcome = False
            return False, None, f"MUTATION NOT_SUBMITTED (config fence): {e}"
        except Exception as e:
            uncertain_outcome = True
            return False, None, f"HTTP exception placing order: {e}"
        finally:
            if hasattr(self.stop_manager, "finalize_mutation"):
                self.stop_manager.finalize_mutation(corr_id, keep_persisted_if_uncertain=uncertain_outcome)
            elif not uncertain_outcome:
                self.stop_manager.deregister_in_flight(corr_id)

    # =========================================================================
    # SECTION E & V12-12: Dhan Super Order Placement & Protection Modification
    # =========================================================================

    def place_super_order(
        self,
        order_req: OrderRequest,
        stop_loss_price: float,
        target_price: float,
        trailing_jump: float = 0.0,
        retry: bool = False,
    ) -> Tuple[bool, Optional[str], str]:
        if order_req.transaction_type != TransactionType.BUY:
            return False, None, f"MUTATION BLOCKED: Direct {order_req.transaction_type} super orders are forbidden"

        corr_id = order_req.correlation_id[:30]
        if hasattr(self.stop_manager, "try_begin_mutation"):
            allowed, st = self.stop_manager.try_begin_mutation(corr_id)
            if not allowed:
                reason_msg = (
                    f"MUTATION BLOCKED: Durable EMERGENCY STOP active "
                    f"(triggered by {st.get('stopped_by')}: {st.get('reason')})"
                )
                logger.critical(f"[STOPPED] {reason_msg}")
                return False, None, reason_msg
        elif self.stop_manager.is_stopped():
            st = self.stop_manager.get_state()
            reason_msg = (
                f"MUTATION BLOCKED: Durable EMERGENCY STOP active "
                f"(triggered by {st.get('stopped_by')}: {st.get('reason')})"
            )
            logger.critical(f"[STOPPED] {reason_msg}")
            return False, None, reason_msg
        else:
            self.stop_manager.register_in_flight(corr_id)

        if self.reconciliation_gate and not self.reconciliation_gate.is_accepting_entries:
            self.stop_manager.deregister_in_flight(corr_id)
            reason_msg = "MUTATION BLOCKED: Startup reconciliation gate is CLOSED (broker state unverified)"
            logger.critical(f"[GATE_CLOSED] {reason_msg}")
            return False, None, reason_msg

        if self.cfg.trading_mode == TradingMode.TEST:
            self.stop_manager.deregister_in_flight(corr_id)
            return False, None, "SUPER ORDER BLOCKED: System is in TEST mode (Zero live orders allowed)"

        # B05: Enforce durable transition gate on all risk-increasing BUY entries (including RTRY- retry orders)
        intent_type = str(getattr(order_req, "intent_type", "NEW_ENTRY") or "NEW_ENTRY").upper()
        is_protective_exit = (order_req.transaction_type == TransactionType.SELL and intent_type == "PROTECTIVE_EXIT")
        if not is_protective_exit:
            try:
                from src.engine.config_manager import ConfigChangeTracker
                t_blocked, t_reason = ConfigChangeTracker(data_dir=self.cfg.data_dir).is_live_entry_blocked_by_transition()
                if t_blocked:
                    self.stop_manager.deregister_in_flight(corr_id)
                    reason_msg = f"MUTATION BLOCKED: {t_reason}"
                    logger.warning(f"[TRANSITION_GATE] {reason_msg}")
                    return False, None, reason_msg
            except Exception as e:
                self.stop_manager.deregister_in_flight(corr_id)
                return False, None, f"MUTATION BLOCKED: Could not verify mode transition gate (failing closed): {e}"

        if stop_loss_price <= 0 or target_price <= 0 or target_price <= stop_loss_price:
            self.stop_manager.deregister_in_flight(corr_id)
            return False, None, f"Invalid Super Order protection levels: SL={stop_loss_price}, Target={target_price}"

        url = f"{BASE_URL}/super/orders"
        payload = {
            "dhanClientId": self.cfg.dhan_client_id,
            "correlationId": corr_id,
            "transactionType": "BUY",
            "exchangeSegment": order_req.exchange_segment,
            "productType": order_req.product_type.value,
            "orderType": "LIMIT",
            "securityId": str(order_req.security_id),
            "quantity": int(order_req.quantity),
            "price": float(order_req.price),
            "targetPrice": float(target_price),
            "stopLossPrice": float(stop_loss_price),
            "trailingJump": float(trailing_jump),
        }

        uncertain_outcome = False
        self.last_order_http_latency_ms = None
        t_order_start_ns = time.perf_counter_ns()
        try:
            resp = self._broker_mutating_http("POST", url, headers=self._headers(), json=payload, timeout=5)
            self.last_order_http_latency_ms = round(max(0.0, (time.perf_counter_ns() - t_order_start_ns) / 1_000_000.0), 3)
            if resp.status_code in (200, 201):
                try:
                    data = resp.json() if resp.text else {}
                except Exception:
                    data = {}
                order_id = str(data.get("orderId", "")).strip()
                if not order_id:
                    uncertain_outcome = True
                    rec_ok, rec_oid, rec_msg = self._reconcile_uncertain_submission(corr_id, str(order_req.security_id))
                    if rec_ok and rec_oid:
                        uncertain_outcome = False
                    return rec_ok, rec_oid, rec_msg
                raw_ord_st = str(data.get("orderStatus", "")).upper().strip()
                self.last_order_broker_status = raw_ord_st or "TRANSIT"
                if raw_ord_st == "REJECTED":
                    return False, None, f"Dhan super order rejected by RMS: {data}"
                return True, order_id, f"Super order acknowledged by Dhan (status={self.last_order_broker_status})"
            elif self.is_token_error(resp.status_code, resp.text):
                uncertain_outcome = True
                if self.cfg.dhan_pin and self.cfg.dhan_totp_secret:
                    logger.warning(
                        f"Dhan token error ({resp.status_code}) on /super/orders ({corr_id}). "
                        f"Refreshing credentials for read-only correlation reconciliation (zero resubmission)..."
                    )
                    self.generate_token_with_totp(force=False, rejected_token=self.token)
                rec_ok, rec_oid, rec_msg = self._reconcile_uncertain_submission(corr_id, str(order_req.security_id))
                if rec_ok and rec_oid:
                    uncertain_outcome = False
                    return True, rec_oid, rec_msg
                return False, None, f"Dhan super order auth/ambiguous error ({resp.status_code}) for {corr_id}: {rec_msg}"
            elif resp.status_code >= 500 or resp.status_code == 408:
                uncertain_outcome = True
                rec_ok, rec_oid, rec_msg = self._reconcile_uncertain_submission(corr_id, str(order_req.security_id))
                if rec_ok and rec_oid:
                    uncertain_outcome = False
                    return True, rec_oid, rec_msg
                return False, None, f"Dhan HTTP {resp.status_code} server error on super order {corr_id} (outcome UNKNOWN): {resp.text}"
            return False, None, f"Dhan super order rejected ({resp.status_code}): {resp.text}"
        except BrokerMutationNotSubmitted as e:
            # Config barrier denied before the broker HTTP call. This is
            # NOT_SUBMITTED, not an unknown Dhan acknowledgement. Never strand
            # an emergency-stop in-flight intent for a request never sent.
            uncertain_outcome = False
            return False, None, f"MUTATION NOT_SUBMITTED (config fence): {e}"
        except Exception as e:
            uncertain_outcome = True
            return False, None, f"HTTP exception placing super order: {e}"
        finally:
            if hasattr(self.stop_manager, "finalize_mutation"):
                self.stop_manager.finalize_mutation(corr_id, keep_persisted_if_uncertain=uncertain_outcome)
            elif not uncertain_outcome:
                self.stop_manager.deregister_in_flight(corr_id)

    def modify_super_order_leg(
        self,
        order_id: str,
        leg_name: str,
        price: float,
        trailing_jump: float = 0.0,
    ) -> Tuple[bool, str, Dict[str, Any]]:
        """P0-04: Modifies a single Super Order leg (TARGET_LEG or STOP_LOSS_LEG) and returns structured outcome."""
        if self.cfg.trading_mode == TradingMode.TEST:
            return False, "SUPER ORDER MODIFY BLOCKED: System is in TEST mode", {"state": "REJECTED"}
        leg_clean = str(leg_name or "").strip().upper()
        if leg_clean == "TARGET_LEG":
            body: Dict[str, Any] = {
                "dhanClientId": self.cfg.dhan_client_id,
                "orderId": str(order_id),
                "legName": "TARGET_LEG",
                "targetPrice": float(price),
            }
        elif leg_clean == "STOP_LOSS_LEG":
            body = {
                "dhanClientId": self.cfg.dhan_client_id,
                "orderId": str(order_id),
                "legName": "STOP_LOSS_LEG",
                "stopLossPrice": float(price),
                "trailingJump": float(trailing_jump),
            }
        else:
            return False, f"Unsupported Super Order leg '{leg_name}'", {"state": "REJECTED"}

        url = f"{BASE_URL}/super/orders/{order_id}"
        try:
            resp = self._broker_mutating_http("PUT", url, headers=self._headers(), json=body, timeout=5)
            if resp.status_code not in (200, 202):
                st = "UNKNOWN" if (resp.status_code >= 500 or resp.status_code == 408) else "REJECTED"
                msg = f"Failed to modify {leg_clean} ({resp.status_code}): {resp.text}"
                return False, msg, {"state": st, "status_code": resp.status_code, "error": msg, "price": float(price)}
            data = resp.json() if resp.text else {}
            ord_st = str(data.get("orderStatus", "")).upper()
            if ord_st in ("REJECTED", "CANCELLED", "EXPIRED"):
                msg = f"Dhan rejected {leg_clean} modification: {data}"
                return False, msg, {"state": "REJECTED", "status_code": resp.status_code, "error": msg, "price": float(price)}
            return True, f"{leg_clean} modified to {price}", {
                "state": "ACKED",
                "status_code": resp.status_code,
                "orderStatus": ord_st or "PENDING",
                "price": float(price),
            }
        except Exception as e:
            msg = f"HTTP exception modifying super order {order_id} ({leg_clean}): {e}"
            return False, msg, {"state": "UNKNOWN", "error": msg, "price": float(price)}

    def modify_super_order_protection(
        self,
        order_id: str,
        stop_loss_price: float,
        target_price: float,
        trailing_jump: float = 0.0,
        legs_to_modify: Optional[List[str]] = None,
    ) -> Tuple[bool, str]:
        if self.cfg.trading_mode == TradingMode.TEST:
            return False, "SUPER ORDER MODIFY BLOCKED: System is in TEST mode"

        requested_legs = [str(x).upper() for x in (legs_to_modify or ["TARGET_LEG", "STOP_LOSS_LEG"])]
        leg_outcomes: Dict[str, Dict[str, Any]] = {}
        self.last_super_leg_mod_results[str(order_id)] = leg_outcomes

        if "TARGET_LEG" in requested_legs:
            ok_t, msg_t, info_t = self.modify_super_order_leg(
                order_id=order_id,
                leg_name="TARGET_LEG",
                price=float(target_price),
            )
            leg_outcomes["TARGET_LEG"] = info_t
            if not ok_t:
                leg_outcomes.setdefault("STOP_LOSS_LEG", {"state": "NOT_ATTEMPTED", "price": float(stop_loss_price)})
                return False, msg_t

        if "STOP_LOSS_LEG" in requested_legs:
            ok_sl, msg_sl, info_sl = self.modify_super_order_leg(
                order_id=order_id,
                leg_name="STOP_LOSS_LEG",
                price=float(stop_loss_price),
                trailing_jump=float(trailing_jump),
            )
            leg_outcomes["STOP_LOSS_LEG"] = info_sl
            if not ok_sl:
                return False, msg_sl

        logger.info(f"Dhan super order {order_id}: SL -> {stop_loss_price}, target -> {target_price}")
        return True, f"Super order {order_id} protection legs updated to SL={stop_loss_price}, Target={target_price}"

    def cancel_super_order_leg(self, order_id: str, leg_name: str = "ENTRY_LEG") -> Tuple[bool, str]:
        if not order_id or not isinstance(order_id, str) or not order_id.strip():
            return False, "Super order cancellation rejected: missing order_id"
        order_id_clean = order_id.strip()
        if not re.match(r"^[a-zA-Z0-9_-]+$", order_id_clean):
            return False, f"Super order cancellation rejected: invalid characters in '{order_id}'"

        if self.cfg.trading_mode == TradingMode.TEST:
            return True, f"TEST mode: simulated super order {leg_name} cancel accepted (HTTP 202)"

        url = f"{BASE_URL}/super/orders/{order_id_clean}/{leg_name}"
        try:
            resp = self._broker_mutating_http("DELETE", url, headers=self._headers(), timeout=5)
            if resp.status_code in (200, 202):
                return True, f"Super order {leg_name} cancellation accepted (HTTP {resp.status_code}) for {order_id_clean}"
            return False, f"Failed to cancel super order {leg_name} ({resp.status_code}): {resp.text}"
        except Exception as e:
            return False, f"HTTP exception cancelling super order {leg_name}: {e}"

    def cancel_order(self, order_id: str) -> Tuple[bool, str]:
        if not order_id or not isinstance(order_id, str) or not order_id.strip():
            return False, "Order cancellation rejected: missing or empty order_id"

        order_id_clean = order_id.strip()
        if not re.match(r"^[a-zA-Z0-9_-]+$", order_id_clean):
            return False, f"Order cancellation rejected: invalid characters in order_id '{order_id}'"

        if self.cfg.trading_mode == TradingMode.TEST:
            return True, "TEST mode: simulated cancel request accepted (HTTP 202)"

        url = f"{BASE_URL}/orders/{order_id_clean}"
        try:
            resp = self._broker_mutating_http("DELETE", url, headers=self._headers(), timeout=5)
            if resp.status_code == 202:
                return True, f"Order cancellation request accepted by broker (HTTP 202) for {order_id_clean}"
            elif resp.status_code == 200:
                return True, f"Order cancellation request acknowledged by broker (HTTP 200) for {order_id_clean}"
            elif resp.status_code == 401:
                return False, f"Dhan auth error (401): {resp.text}"
            elif resp.status_code == 429:
                return False, f"Dhan rate limit exceeded (429): {resp.text}"
            return False, f"Failed to cancel order ({resp.status_code}): {resp.text}"
        except Exception as e:
            return False, f"HTTP exception cancelling order: {e}"

    def place_forever_oco(
        self,
        correlation_id: str,
        security_id: str,
        exchange_segment: str,
        product_type: str,
        levels: ProtectionLevels,
        max_protectable_qty: Optional[int] = None,
        tick_size: float = 0.05,
    ) -> Tuple[bool, Optional[str], str]:
        if self.cfg.trading_mode == TradingMode.TEST:
            return False, None, "FOREVER OCO BLOCKED: System is in TEST mode"

        prod_upper = product_type.upper()
        if prod_upper not in ("CNC", "MTF"):
            err = f"Forever OCO unsupported for product '{product_type}'. Dhan v2 Forever orders require CNC or MTF."
            logger.critical(f"[PROTECTION_REJECTED] {err}")
            return False, None, err

        qty = int(levels.quantity)
        if qty <= 0:
            err = f"Forever OCO rejected: invalid quantity {qty} <= 0"
            logger.error(f"[PROTECTION_REJECTED] {err}")
            return False, None, err

        if max_protectable_qty is not None and qty > max_protectable_qty:
            err = (
                f"Forever OCO rejected: protective quantity ({qty}) exceeds confirmed net open position "
                f"({max_protectable_qty}) — oversell blocked"
            )
            logger.critical(f"[PROTECTION_REJECTED] {err}")
            return False, None, err

        sl_limit = float(levels.sl_limit)
        sl_trigger = float(levels.sl_trigger)
        target_price = float(levels.target_price)
        target_trigger = float(getattr(levels, "target_trigger", None) or levels.target_price)

        if sl_limit <= 0 or sl_trigger <= 0 or target_price <= 0 or target_trigger <= 0:
            err = "Forever OCO rejected: all price and trigger fields must be > 0"
            logger.error(f"[PROTECTION_REJECTED] {err}")
            return False, None, err

        if sl_limit > sl_trigger:
            err = f"Forever OCO rejected: SELL stop-loss limit price ({sl_limit}) must be <= trigger price ({sl_trigger})"
            logger.error(f"[PROTECTION_REJECTED] {err}")
            return False, None, err

        if target_price <= sl_trigger:
            err = f"Forever OCO rejected: target price ({target_price}) must be > stop-loss trigger ({sl_trigger})"
            logger.error(f"[PROTECTION_REJECTED] {err}")
            return False, None, err

        active_tick = tick_size if tick_size and tick_size > 0 else 0.05

        def _is_tick_aligned(p: float, tick: float = active_tick) -> bool:
            steps = round(p / tick, 4)
            return abs(steps - round(steps)) < 1e-4

        for name, p in [
            ("sl_limit", sl_limit),
            ("sl_trigger", sl_trigger),
            ("target_price", target_price),
            ("target_trigger", target_trigger),
        ]:
            if not _is_tick_aligned(p):
                err = f"Forever OCO rejected: {name} ({p}) is not aligned to tick grid ({active_tick})"
                logger.error(f"[PROTECTION_REJECTED] {err}")
                return False, None, err

        url = f"{BASE_URL}/forever/orders"
        payload = {
            "dhanClientId": self.cfg.dhan_client_id,
            "correlationId": correlation_id[:30],
            "orderFlag": "OCO",
            "transactionType": "SELL",
            "exchangeSegment": exchange_segment,
            "productType": prod_upper,
            "orderType": "LIMIT",
            "validity": "DAY",
            "securityId": str(security_id),
            "quantity": qty,
            "disclosedQuantity": 0,
            "price": sl_limit,
            "triggerPrice": sl_trigger,
            "price1": target_price,
            "triggerPrice1": target_trigger,
            "quantity1": qty,
        }

        try:
            resp = self._broker_mutating_http("POST", url, headers=self._headers(), json=payload, timeout=5)
            if resp.status_code in (200, 201):
                data = resp.json()
                order_status = str(data.get("orderStatus", "PENDING")).upper()
                if order_status == "REJECTED":
                    return False, None, f"Forever OCO rejected by broker RMS: {data}"
                forever_id = str(data.get("orderId", "")).strip()
                if not forever_id:
                    return False, None, f"Ambiguous Forever OCO response missing orderId for {correlation_id}: outcome UNKNOWN"
                return True, forever_id, "Forever OCO placed successfully on Dhan"
            elif resp.status_code >= 500 or resp.status_code == 408:
                return False, None, f"Dhan HTTP {resp.status_code} server error on Forever OCO {correlation_id} (outcome UNKNOWN): {resp.text}"
            return False, None, f"Forever OCO rejected ({resp.status_code}): {resp.text}"
        except Exception as e:
            return False, None, f"HTTP exception placing Forever OCO: {e}"

    def cancel_forever_order(self, forever_order_id: str) -> Tuple[bool, str]:
        """P0-05: Cancels a bot-owned Forever OCO order (`DELETE /v2/forever/orders/{order-id}`)."""
        if not forever_order_id or not isinstance(forever_order_id, str) or not forever_order_id.strip():
            return False, "Forever order cancellation rejected: missing forever_order_id"
        oid_clean = forever_order_id.strip()
        if not re.match(r"^[a-zA-Z0-9_-]+$", oid_clean):
            return False, f"Forever order cancellation rejected: invalid characters in '{forever_order_id}'"
        if self.cfg.trading_mode == TradingMode.TEST:
            return True, f"TEST mode: simulated Forever order cancel accepted (HTTP 202) for {oid_clean}"
        url = f"{BASE_URL}/forever/orders/{oid_clean}"
        try:
            resp = self._broker_mutating_http("DELETE", url, headers=self._headers(), timeout=5)
            if resp.status_code in (200, 202):
                return True, f"Forever order cancellation accepted (HTTP {resp.status_code}) for {oid_clean}"
            return False, f"Failed to cancel Forever order ({resp.status_code}): {resp.text}"
        except Exception as e:
            return False, f"HTTP exception cancelling Forever order {oid_clean}: {e}"

    def order_status(self, order_id: str, bypass_test_mode: bool = False) -> Optional[Dict[str, Any]]:
        # V14_MANUAL_CANCEL_READ_FALLBACK
        if getattr(self.cfg, "trading_mode", None) == TradingMode.TEST and not bypass_test_mode:
            return {"orderStatus": "TRADED", "filledQty": 0, "averageTradedPrice": 0.0}

        requested_id = str(order_id).strip()
        url = f"{BASE_URL}/orders/{requested_id}"

        try:
            resp = self._get_with_auth_recovery(url)
            if self._is_rate_limited_response(resp) or getattr(resp, "headers", {}).get("X-AuditBot-Local-Deferral") == "1":
                return None  # UNKNOWN; never amplify throttle/storage failure via fallback.
            if resp.status_code == 200:
                data = resp.json()
                candidates = [data] if isinstance(data, dict) else (
                    data if isinstance(data, list) else []
                )
                matches = [
                    x for x in candidates
                    if isinstance(x, dict)
                    and str(x.get("orderId") or "").strip() == requested_id
                    and x.get("orderStatus")
                ]
                if len(matches) == 1:
                    return matches[0]
            else:
                logger.warning(
                    "Dhan single-order read failed: %s HTTP %s",
                    requested_id, resp.status_code
                )
                if int(resp.status_code) in (401, 403) and self.is_token_error(
                    int(resp.status_code), str(getattr(resp, "text", "") or "")
                ):
                    # A failed auth recovery is UNKNOWN, not a cancelled/empty order.
                    # Avoid a second TOTP refresh via the order-book fallback.
                    return None
        except Exception as exc:
            logger.warning(
                "Dhan single-order read exception for %s: %s",
                requested_id, exc
            )

        # Read-only fallback for manually cancelled orders.
        book = self.get_order_book(bypass_test_mode=True) if bypass_test_mode else self.get_order_book()
        if isinstance(book, list) and getattr(book, "ok", True):
            matches = [
                x for x in book
                if isinstance(x, dict)
                and str(x.get("orderId") or "").strip() == requested_id
                and x.get("orderStatus")
            ]
            if len(matches) == 1:
                return matches[0]

        return None

    @staticmethod
    def normalize_order_trades_payload(
        raw_payload: Any,
        expected_order_id: Optional[str] = None,
        expected_account_id: Optional[str] = None,
        expected_security_id: Optional[str] = None,
        expected_transaction_type: Optional[str] = None,
        require_exchange_trade_id: bool = False,
    ) -> Tuple[bool, List[Dict[str, Any]], str]:
        """
        P0-06: Normalizes and strictly validates Dhan `/v2/trades/{order-id}` responses.
        Accepts BOTH:
        - Documented Dhan v2 single trade object (`dict`)
        - Multi-fill array of trade objects (`list` of `dict`s), or `{"data": [...]}` wrapper.
        Validates `orderId`, `dhanClientId`, `securityId`, `transactionType`, `exchangeTradeId`,
        `tradedQuantity > 0`, and `tradedPrice > 0.0`.
        """
        payload = raw_payload
        if isinstance(payload, dict) and "data" in payload and isinstance(payload["data"], (list, dict)):
            payload = payload["data"]

        if isinstance(payload, dict):
            if not payload:
                return True, [], "OK_EMPTY"
            if (
                "tradedQuantity" not in payload
                and "tradedPrice" not in payload
                and ("errorCode" in payload or "errorMessage" in payload or "error" in payload)
            ):
                return False, [], f"Broker error object in trades payload: {payload}"
            raw_list = [payload]
        elif isinstance(payload, list):
            if not payload:
                return True, [], "OK_EMPTY"
            if any(not isinstance(item, dict) for item in payload):
                return False, [], "Malformed trades payload: list contains non-dict items"
            raw_list = payload
        else:
            return False, [], f"Malformed trades payload: expected dict or list of dicts, got {type(payload).__name__}"

        validated: List[Dict[str, Any]] = []
        exp_oid = str(expected_order_id or "").strip()
        exp_acct = str(expected_account_id or "").strip()
        exp_sec = str(expected_security_id or "").strip()
        exp_side = str(expected_transaction_type or "").strip().upper()

        for idx, item in enumerate(raw_list):
            if not isinstance(item, dict):
                return False, [], "Malformed trade item: expected dict"

            t_oid = str(item.get("orderId") or "").strip()
            if exp_oid and t_oid and t_oid != exp_oid:
                return False, [], f"Trade orderId mismatch ({t_oid} != {exp_oid})"

            t_acct = str(item.get("dhanClientId") or "").strip()
            if exp_acct and t_acct and t_acct != exp_acct:
                return False, [], f"Trade dhanClientId mismatch ({t_acct} != {exp_acct})"

            t_sec = str(item.get("securityId") or "").strip()
            if exp_sec and t_sec and t_sec != exp_sec:
                return False, [], f"Trade securityId mismatch ({t_sec} != {exp_sec})"

            t_side = str(item.get("transactionType") or "").strip().upper()
            if exp_side and t_side and t_side != exp_side:
                return False, [], f"Trade transactionType mismatch ({t_side} != {exp_side})"

            raw_qty = item.get("tradedQuantity")
            if raw_qty is None or isinstance(raw_qty, bool):
                return False, [], f"Missing or boolean tradedQuantity in trade record #{idx}"
            try:
                if isinstance(raw_qty, float) and not raw_qty.is_integer():
                    return False, [], f"Fractional tradedQuantity ({raw_qty}) in trade record #{idx}"
                qty = int(raw_qty)
            except (ValueError, TypeError):
                return False, [], f"Invalid tradedQuantity ({raw_qty!r}) in trade record #{idx}"
            if qty <= 0:
                return False, [], f"Non-positive tradedQuantity ({qty}) in trade record #{idx}"

            raw_price = item.get("tradedPrice")
            if raw_price is None or isinstance(raw_price, bool):
                return False, [], f"Missing or boolean tradedPrice in trade record #{idx}"
            try:
                price = float(raw_price)
            except (ValueError, TypeError):
                return False, [], f"Invalid tradedPrice ({raw_price!r}) in trade record #{idx}"
            if not math.isfinite(price) or price <= 0.0:
                return False, [], f"Non-positive or non-finite tradedPrice ({price}) in trade record #{idx}"

            raw_etid = item.get("exchangeTradeId")
            if isinstance(raw_etid, bool):
                return False, [], f"Boolean exchangeTradeId in trade record #{idx}"
            etid = str(raw_etid or "").strip()
            if etid in ("0", "None", "null"):
                etid = ""
            if require_exchange_trade_id and not etid:
                return False, [], f"Missing exchangeTradeId in trade record #{idx}"

            norm_item = dict(item)
            norm_item["orderId"] = t_oid or exp_oid
            norm_item["tradedQuantity"] = qty
            norm_item["tradedPrice"] = price
            norm_item["transactionType"] = t_side or exp_side or "BUY"
            norm_item["exchangeTradeId"] = etid or f"{t_oid or exp_oid or 'ORD'}-TRD-{idx + 1}"
            norm_item["_has_explicit_exchange_trade_id"] = bool(etid)
            validated.append(norm_item)

        return True, validated, "OK"

    def get_trades_for_order(
        self,
        order_id: str,
        expected_security_id: Optional[str] = None,
        expected_transaction_type: Optional[str] = None,
        require_exchange_trade_id: bool = False,
        bypass_test_mode: bool = False,
    ) -> Union[BrokerReadList, BrokerReadFailure]:
        """
        P0-06: Queries `GET /v2/trades/{order-id}` and accepts both single-dict and list-of-dicts shapes.
        """
        if getattr(self.cfg, "trading_mode", None) == TradingMode.TEST and not bypass_test_mode:
            return BrokerReadList([], status=BrokerReadStatus.OK_EMPTY.value, status_code=200)

        url = f"{BASE_URL}/trades/{order_id}"
        try:
            resp = self._get_with_auth_recovery(url)
            status_code = int(getattr(resp, "status_code", 0) or 0)
            if status_code == 200:
                try:
                    raw_data = resp.json()
                except Exception as e:
                    return BrokerReadFailure(
                        status=BrokerReadStatus.MALFORMED.value,
                        error=f"Malformed JSON in /trades/{order_id}: {e}",
                        status_code=status_code,
                    )
                ok_norm, trades_list, norm_msg = self.normalize_order_trades_payload(
                    raw_data,
                    expected_order_id=str(order_id),
                    expected_account_id=self.cfg.dhan_client_id or None,
                    expected_security_id=expected_security_id,
                    expected_transaction_type=expected_transaction_type,
                    require_exchange_trade_id=require_exchange_trade_id,
                )
                if not ok_norm:
                    return BrokerReadFailure(
                        status=BrokerReadStatus.MALFORMED.value,
                        error=norm_msg,
                        status_code=status_code,
                    )
                return BrokerReadList(
                    trades_list,
                    status=BrokerReadStatus.OK_RECORDS.value if trades_list else BrokerReadStatus.OK_EMPTY.value,
                    status_code=200,
                )
            return BrokerReadFailure(
                status=BrokerReadStatus.FAILED.value,
                error=f"Dhan /trades/{order_id} failed (HTTP {status_code}): {getattr(resp, 'text', '')}",
                status_code=status_code,
            )
        except Exception as e:
            return BrokerReadFailure(
                status=BrokerReadStatus.UNAVAILABLE.value,
                error=f"HTTP exception fetching /trades/{order_id}: {e}",
                status_code=0,
            )

    def trades_avg_price(
        self,
        order_id: str,
        expected_security_id: Optional[str] = None,
        expected_transaction_type: Optional[str] = None,
        bypass_test_mode: bool = False,
    ) -> Optional[float]:
        """
        P0-06: Calculates volume-weighted average execution price from `GET /v2/trades/{order-id}`.
        Supports both Dhan's documented single-dict response and list-of-dicts responses.
        """
        if getattr(self.cfg, "trading_mode", None) == TradingMode.TEST and not bypass_test_mode:
            return None

        res = self.get_trades_for_order(
            order_id=order_id,
            expected_security_id=expected_security_id,
            expected_transaction_type=expected_transaction_type,
            require_exchange_trade_id=False,
            bypass_test_mode=bypass_test_mode,
        )
        if isinstance(res, list) and res:
            total_val = sum(float(t["tradedPrice"]) * int(t["tradedQuantity"]) for t in res)
            total_qty = sum(int(t["tradedQuantity"]) for t in res)
            if total_qty > 0:
                return round(total_val / total_qty, 4)
        return None

    @classmethod
    def validate_historical_trade_record(
        cls,
        item: Any,
        *,
        expected_account_id: Optional[str] = None,
        expected_order_id: Optional[str] = None,
        expected_security_id: Optional[str] = None,
        expected_exchange_segment: Optional[str] = None,
        expected_product_type: Optional[str] = None,
        expected_transaction_type: Optional[str] = "BUY",
        allow_missing_exchange_trade_id: bool = False,
    ) -> Tuple[bool, Optional[Dict[str, Any]], str]:
        """
        Strictly validates a single historical trade record from `GET /v2/trades/{from-date}/{to-date}/{page}`.
        - Requires explicit, non-empty `dhanClientId`, `orderId`, `securityId`, `exchangeSegment`,
          `productType`, `transactionType`, positive integer `tradedQuantity`, positive finite `tradedPrice`,
          and a real broker `exchangeTradeId` (never synthetic).
        - Rejects any mismatch against expected account, order, security, segment, product, or side.
        """
        if not isinstance(item, dict):
            return False, None, f"Historical trade item is not a dict ({type(item).__name__})"

        t_acct = str(item.get("dhanClientId") or "").strip()
        if not t_acct:
            return False, None, "Historical trade record missing dhanClientId"
        exp_acct = str(expected_account_id or "").strip()
        if exp_acct and t_acct != exp_acct:
            return False, None, f"Historical trade dhanClientId mismatch ({t_acct} != {exp_acct})"

        t_oid = str(item.get("orderId") or "").strip()
        if not t_oid or t_oid in ("0", "None", "null"):
            return False, None, "Historical trade record missing orderId"
        exp_oid = str(expected_order_id or "").strip()
        if exp_oid and t_oid != exp_oid:
            return False, None, f"Historical trade orderId mismatch ({t_oid} != {exp_oid})"

        raw_etid = item.get("exchangeTradeId")
        if isinstance(raw_etid, bool):
            return False, None, "Historical trade record has boolean exchangeTradeId"
        etid = str(raw_etid or "").strip()
        missing_exchange_trade_id = not etid or etid in ("0", "None", "null")
        if not missing_exchange_trade_id and any(
            marker in etid for marker in ("-TRD-", "-FILL-", "-RECON-")
        ):
            return False, None, f"Historical trade record missing or synthetic exchangeTradeId ({etid!r})"
        if missing_exchange_trade_id and not allow_missing_exchange_trade_id:
            return False, None, f"Historical trade record missing or synthetic exchangeTradeId ({etid!r})"

        # R01: Distinguish missing exchange execution IDs from exchange ORDER IDs.
        # This alternate evidence must undergo further unique-order, date and
        # broker-holdings checks before it can affect the journal.
        exchange_order_id = str(item.get("exchangeOrderId") or "").strip()
        exchange_time = str(item.get("exchangeTime") or "").strip()
        if missing_exchange_trade_id:
            if exchange_order_id in ("", "0", "None", "null"):
                return False, None, "Historical trade missing usable exchangeOrderId for zero-ID fallback"
            try:
                exchange_dt = datetime.fromisoformat(
                    exchange_time.replace("Z", "+00:00").replace(" ", "T")
                )
                if exchange_dt.year < 2000 or exchange_dt.year > 2100:
                    raise ValueError("out-of-range date")
            except (ValueError, TypeError, OverflowError):
                return False, None, "Historical trade missing valid exchangeTime for zero-ID fallback"

        t_sec = str(item.get("securityId") or "").strip()
        if not t_sec or t_sec in ("0", "None", "null"):
            return False, None, "Historical trade record missing securityId"
        exp_sec = str(expected_security_id or "").strip()
        if exp_sec and t_sec != exp_sec:
            return False, None, f"Historical trade securityId mismatch ({t_sec} != {exp_sec})"

        t_seg = str(item.get("exchangeSegment") or "").strip().upper()
        if not t_seg:
            return False, None, "Historical trade record missing exchangeSegment"
        exp_seg = str(expected_exchange_segment or "").strip().upper()
        if exp_seg and t_seg != exp_seg:
            return False, None, f"Historical trade exchangeSegment mismatch ({t_seg} != {exp_seg})"

        t_prod = str(item.get("productType") or "").strip().upper()
        if not t_prod:
            return False, None, "Historical trade record missing productType"
        exp_prod = str(expected_product_type or "").strip().upper()
        if exp_prod and t_prod != exp_prod:
            return False, None, f"Historical trade productType mismatch ({t_prod} != {exp_prod})"

        t_side = str(item.get("transactionType") or "").strip().upper()
        if t_side not in ("BUY", "SELL"):
            return False, None, f"Historical trade record invalid transactionType ({t_side!r})"
        exp_side = str(expected_transaction_type or "").strip().upper()
        if exp_side and t_side != exp_side:
            return False, None, f"Historical trade transactionType mismatch ({t_side} != {exp_side})"

        raw_qty = item.get("tradedQuantity")
        if raw_qty is None or isinstance(raw_qty, bool):
            return False, None, "Historical trade record missing or boolean tradedQuantity"
        try:
            if isinstance(raw_qty, float) and not raw_qty.is_integer():
                return False, None, f"Historical trade record fractional tradedQuantity ({raw_qty})"
            qty = int(raw_qty)
        except (ValueError, TypeError):
            return False, None, f"Historical trade record invalid tradedQuantity ({raw_qty!r})"
        if qty <= 0:
            return False, None, f"Historical trade record non-positive tradedQuantity ({qty})"

        raw_price = item.get("tradedPrice")
        if raw_price is None or isinstance(raw_price, bool):
            return False, None, "Historical trade record missing or boolean tradedPrice"
        try:
            price = float(raw_price)
        except (ValueError, TypeError):
            return False, None, f"Historical trade record invalid tradedPrice ({raw_price!r})"
        if not math.isfinite(price) or price <= 0.0:
            return False, None, f"Historical trade record non-positive or non-finite tradedPrice ({price})"

        norm = dict(item)
        norm["dhanClientId"] = t_acct
        norm["orderId"] = t_oid
        norm["exchangeTradeId"] = None if missing_exchange_trade_id else etid
        norm["_broker_attested_no_execution_id"] = missing_exchange_trade_id
        norm["exchangeOrderId"] = exchange_order_id
        norm["exchangeTime"] = exchange_time
        norm["securityId"] = t_sec
        norm["exchangeSegment"] = t_seg
        norm["productType"] = t_prod
        norm["transactionType"] = t_side
        norm["tradedQuantity"] = qty
        norm["tradedPrice"] = price
        norm["_has_explicit_exchange_trade_id"] = not missing_exchange_trade_id
        return True, norm, "OK"

    def get_historical_trades_page(
        self,
        from_date: str,
        to_date: str,
        page: int = 0,
        *,
        bypass_test_mode: bool = False,
    ) -> Union[BrokerReadList, BrokerReadFailure]:
        """
        Read-only Dhan v2 historical trade page query: `GET /v2/trades/{from-date}/{to-date}/{page}`.
        Validates every returned record for explicit account identity (`cfg.dhan_client_id`) and
        mandatory execution fields. Never performs any broker mutation.
        """
        if getattr(self.cfg, "trading_mode", None) == TradingMode.TEST and not bypass_test_mode:
            return BrokerReadList([], status=BrokerReadStatus.OK_EMPTY.value, status_code=200)

        exp_acct = str(getattr(self.cfg, "dhan_client_id", "") or "").strip()
        if not exp_acct:
            return BrokerReadFailure(
                status=BrokerReadStatus.FAILED.value,
                error="Cannot query historical trades without configured DHAN_CLIENT_ID",
                status_code=0,
            )
        if isinstance(page, bool) or not isinstance(page, int) or page < 0:
            return BrokerReadFailure(
                status=BrokerReadStatus.MALFORMED.value,
                error=f"Invalid historical trade page index: {page!r}",
                status_code=0,
            )

        url = f"{BASE_URL}/trades/{from_date}/{to_date}/{page}"
        try:
            resp = self._get_with_auth_recovery(url)
            status_code = int(getattr(resp, "status_code", 0) or 0)
            if status_code != 200:
                err_text = str(getattr(resp, "text", "") or "")
                return BrokerReadFailure(
                    status=BrokerReadStatus.FAILED.value,
                    error=f"Dhan historical trades {from_date}..{to_date} page {page} failed (HTTP {status_code}): {err_text}",
                    status_code=status_code,
                )
            try:
                raw_data = resp.json()
            except Exception as exc:
                return BrokerReadFailure(
                    status=BrokerReadStatus.MALFORMED.value,
                    error=f"Malformed JSON in historical trades page {page}: {exc}",
                    status_code=status_code,
                )

            if isinstance(raw_data, dict) and "data" in raw_data and isinstance(raw_data["data"], list):
                raw_list = raw_data["data"]
            elif isinstance(raw_data, list):
                raw_list = raw_data
            else:
                return BrokerReadFailure(
                    status=BrokerReadStatus.MALFORMED.value,
                    error=f"Malformed historical trades payload on page {page}: expected list, got {type(raw_data).__name__}",
                    status_code=status_code,
                )

            if not raw_list:
                return BrokerReadList([], status=BrokerReadStatus.OK_EMPTY.value, status_code=200)

            validated_rows: List[Dict[str, Any]] = []
            for idx, row in enumerate(raw_list):
                ok_v, norm_row, v_err = self.validate_historical_trade_record(
                    row,
                    expected_account_id=exp_acct,
                    expected_transaction_type=None,
                    allow_missing_exchange_trade_id=True,
                )
                if not ok_v or norm_row is None:
                    return BrokerReadFailure(
                        status=BrokerReadStatus.MALFORMED.value,
                        error=f"Historical trade validation failed on page {page} record #{idx}: {v_err}",
                        status_code=status_code,
                    )
                validated_rows.append(norm_row)

            return BrokerReadList(
                validated_rows,
                status=BrokerReadStatus.OK_RECORDS.value,
                status_code=200,
            )
        except Exception as exc:
            return BrokerReadFailure(
                status=BrokerReadStatus.UNAVAILABLE.value,
                error=f"HTTP exception fetching historical trades page {page}: {exc}",
                status_code=0,
            )

    def get_historical_trades(
        self,
        from_date: str,
        to_date: str,
        *,
        max_pages: int = MAX_HISTORICAL_TRADE_PAGES,
        page_delay_sec: float = 0.25,
        bypass_test_mode: bool = False,
    ) -> Union[BrokerReadList, BrokerReadFailure]:
        """
        Paginates `GET /v2/trades/{from-date}/{to-date}/{page}` across pages `0..max_pages`
        until a terminal empty page (`[]`) is confirmed.
        - Deduplicates across pages by `exchangeTradeId` while rejecting conflicting duplicate records.
        - Never treats partial pagination or hitting `max_pages` without an empty terminal page as complete history.
        """
        if getattr(self.cfg, "trading_mode", None) == TradingMode.TEST and not bypass_test_mode:
            return BrokerReadList([], status=BrokerReadStatus.OK_EMPTY.value, status_code=200)

        try:
            from_dt = datetime.strptime(str(from_date or "").strip(), "%Y-%m-%d").date()
            to_dt = datetime.strptime(str(to_date or "").strip(), "%Y-%m-%d").date()
        except ValueError as exc:
            return BrokerReadFailure(
                status=BrokerReadStatus.MALFORMED.value,
                error=f"Invalid historical trade date format ({from_date!r}..{to_date!r}): {exc}",
                status_code=0,
            )

        span_days = (to_dt - from_dt).days
        if span_days < 0:
            return BrokerReadFailure(
                status=BrokerReadStatus.MALFORMED.value,
                error=f"Historical trade from_date ({from_date}) is after to_date ({to_date})",
                status_code=0,
            )
        if span_days > MAX_HISTORICAL_TRADE_WINDOW_DAYS:
            return BrokerReadFailure(
                status=BrokerReadStatus.FAILED.value,
                error=f"Historical trade range ({span_days} days) exceeds maximum supported window ({MAX_HISTORICAL_TRADE_WINDOW_DAYS} days)",
                status_code=0,
            )
        if max_pages <= 0:
            return BrokerReadFailure(
                status=BrokerReadStatus.FAILED.value,
                error=f"Invalid max_pages={max_pages}",
                status_code=0,
            )

        deduped_trades: List[Dict[str, Any]] = []
        seen_by_etid: Dict[str, Tuple[str, str, int, float, str]] = {}
        reached_empty_terminal_page = False

        for page_idx in range(max_pages + 1):
            if page_idx == max_pages:
                # We already fetched max_pages non-empty pages; probe or fail closed because
                # terminal empty page was not reached within max_pages.
                return BrokerReadFailure(
                    status=BrokerReadStatus.FAILED.value,
                    error=(
                        f"Historical trade pagination reached max_pages={max_pages} "
                        f"for {from_date}..{to_date} without reaching a terminal empty page"
                    ),
                    status_code=200,
                )
            if page_idx > 0 and page_delay_sec > 0:
                time.sleep(min(float(page_delay_sec), 1.0))

            page_res = self.get_historical_trades_page(
                from_date,
                to_date,
                page=page_idx,
                bypass_test_mode=bypass_test_mode,
            )
            if isinstance(page_res, BrokerReadFailure) or getattr(page_res, "ok", True) is False:
                return page_res
            if not page_res:
                reached_empty_terminal_page = True
                break

            for row in page_res:
                # Do not deduplicate zero-ID records by a shared "0" or NULL.
                # Retain every occurrence; order-level recovery will reject
                # all multi-row/ambiguous missing-ID executions.
                if row.get("_broker_attested_no_execution_id"):
                    deduped_trades.append(row)
                    continue
                etid = str(row["exchangeTradeId"])
                sig = (
                    str(row["orderId"]),
                    str(row["securityId"]),
                    int(row["tradedQuantity"]),
                    round(float(row["tradedPrice"]), 6),
                    str(row["transactionType"]),
                )
                if etid in seen_by_etid:
                    if seen_by_etid[etid] != sig:
                        return BrokerReadFailure(
                            status=BrokerReadStatus.MALFORMED.value,
                            error=f"Conflicting duplicate exchangeTradeId '{etid}' across historical trade pages",
                            status_code=200,
                        )
                    continue
                seen_by_etid[etid] = sig
                deduped_trades.append(row)

        if not reached_empty_terminal_page:
            return BrokerReadFailure(
                status=BrokerReadStatus.FAILED.value,
                error=f"Historical trade pagination incomplete for {from_date}..{to_date}",
                status_code=200,
            )

        return BrokerReadList(
            deduped_trades,
            status=BrokerReadStatus.OK_RECORDS.value if deduped_trades else BrokerReadStatus.OK_EMPTY.value,
            status_code=200,
        )

