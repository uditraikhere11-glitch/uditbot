"""
Persistent Protection Watcher Engine — V13 Safety-Corrected Edition (CV13-01 through CV13-05).
Implements:
- Safety Correction A & CV13-01: Durable protection-attempt lifecycle (`protection_attempts` table + strict pre-POST commit)
  for both Forever OCO (`FOREVER_OCO`) and Super Order (`SUPER_ORDER`) routes.
  * Creates unique attempt identity (`attempt_id`, `correlation_id`) and commits `SUBMITTING` state before any POST or PUT.
  * Restores unresolved `FOREVER_OCO` and `SUPER_ORDER` attempts on startup with expected quantity, prices, broker identity, and state.
  * Reconciles existing unresolved attempts through current broker readback before creating any new attempt.
  * Handles additional partial fills separately after reconciling the earlier attempt, re-anchoring using current cumulative fills.
- Safety Correction B: Single authoritative Super Order & Forever OCO verification contract.
- CV13-02: Persists explicit cancellation origin (`BOT_TIMEOUT`, `MANUAL_OPERATOR`, `EXTERNAL_OR_UNKNOWN`,
  `SIGNAL_WITHDRAWAL`, `EMERGENCY_STOP`) and `retry_eligible` before requesting cancellation; defaults legacy
  records without a reliable cancellation reason to `retry_eligible=False`.
- CV13-03: Tracks `entry_timeout_elapsed`, `cancel_requested`, `cancel_acknowledged`, `cancel_uncertain`, and
  `terminal_confirmed` separately; continues bounded-backoff cancellation recovery after failed/uncertain requests
  and alerts without closing if automatic cancellation attempts are exhausted.
- CV13-04: Revalidates live clock quote age, future timestamps, F&O local vs source timestamp distinction,
  emergency stop, and reconciliation gate immediately before retry submission; records `NOT_SUBMITTED` distinctly
  from `UNKNOWN` when final validation fails after a durable retry reservation.
"""

import asyncio
import copy
from datetime import date, datetime
from enum import Enum
import inspect
import json
import logging
import math
import os
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from src.engine.latency_monitor import GLOBAL_LATENCY_MONITOR
from src.models import (
    OrderRequest,
    OrderType,
    PositionLifecycleState,
    ProductType,
    ProtectionLevels,
    ProtectionRoute,
    ProtectionVerificationResult,
    QuoteResult,
    TradingMode,
    TransactionType,
    infer_record_protection_route,
)
from src.engine.sizer import calculate_protection_levels, round_to_tick
from src.engine.market import IST, is_lifecycle_open, is_market_open
from src.instruments.resolver import INDEX_SYMBOLS
from src.journal.db import generate_correlation_id
from src.broker.dhan_client import verify_forever_oco_group, verify_super_order_record
from src.engine.watch_poll_policy import watcher_cadence_seconds, supervision_read_requirement, manual_risk_only, has_urgent_obligation, supervision_preflight_priority

logger = logging.getLogger(__name__)

DEFAULT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "data",
    "pending_protection.json",
)

POLL_INTERVAL_SEC = 2.0
RETRY_AFTER_SEC = 60.0
TICK = 0.05

PROHIBITED_CANCEL_ORIGINS = frozenset({
    "MANUAL",
    "MANUAL_OPERATOR",
    "OPERATOR",
    "EXTERNAL",
    "EXTERNAL_OR_UNKNOWN",
    "UNKNOWN",
    "SIGNAL",
    "SIGNAL_WITHDRAWAL",
    "SIGNAL_CANCEL",
    "EMERGENCY_STOP",
    "STOP",
    "LEGACY_UNKNOWN",
})


class OrderLifecycleState(str, Enum):
    PENDING = "PENDING"
    PART_FILLED = "PART_FILLED"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    CANCEL_PENDING = "CANCEL_PENDING"
    CANCELLED = "CANCELLED"
    TRADED = "TRADED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


TERMINAL_STATES = {
    OrderLifecycleState.CANCELLED,
    OrderLifecycleState.TRADED,
    OrderLifecycleState.REJECTED,
    OrderLifecycleState.EXPIRED,
}


def _is_ambiguous_message(msg: str) -> bool:
    m = str(msg or "").lower()
    return any(
        k in m
        for k in (
            "timeout",
            "timed out",
            "connection",
            "http exception",
            "ambiguous",
            "outcome unknown",
            "unknown",
            "500",
            "502",
            "503",
            "504",
            "408",
        )
    )


def _normalize_cancel_origin(raw_origin: Optional[str]) -> str:
    val = str(raw_origin or "").strip().upper()
    if not val:
        return "MANUAL_OPERATOR"
    if val in ("BOT_TIMEOUT", "TIMEOUT"):
        return "BOT_TIMEOUT"
    if val in ("MANUAL", "MANUAL_OPERATOR", "OPERATOR"):
        return "MANUAL_OPERATOR"
    if val in ("EXTERNAL", "EXTERNAL_OR_UNKNOWN", "UNKNOWN"):
        return "EXTERNAL_OR_UNKNOWN"
    if val in ("SIGNAL", "SIGNAL_WITHDRAWAL", "SIGNAL_CANCEL"):
        return "SIGNAL_WITHDRAWAL"
    if val in ("EMERGENCY_STOP", "STOP"):
        return "EMERGENCY_STOP"
    if val == "LEGACY_UNKNOWN":
        return "LEGACY_UNKNOWN"
    return val


class ProtectionWatcher:
    def __init__(
        self,
        broker: Any,
        sl_pct: float = 3.0,
        target_pct: float = 3.0,
        sl_limit_buffer_pct: float = 1.0,
        path: Optional[str] = None,
        dry_run: bool = True,
        clock: Optional[Callable[[], float]] = None,
        journal_db: Optional[Any] = None,
        require_broker_leg_confirmation: bool = False,
        order_timeout_sec: Optional[float] = None,
        fno_timeout_sec: float = 180.0,
        retry_timeout_sec: Optional[float] = None,
        risk_manager: Optional[Any] = None,
        auto_retry_enabled: bool = True,
        max_cancel_attempts: int = 3,
        cancel_backoff_sec: float = 2.0,
        equity_sl_pct: Optional[float] = None,
        equity_target_pct: Optional[float] = None,
        fno_sl_pct: Optional[float] = None,
        fno_target_pct: Optional[float] = None,
        orphan_cancel_ack_timeout_sec: float = 10.0,
        orphan_cancel_retry_backoff_sec: float = 5.0,
        orphan_cancel_max_attempts: int = 3,
        orphan_cancel_deadline_sec: float = 60.0,
    ):
        self.broker = broker
        # Legacy fields apply only to previously tracked records without an
        # explicit policy snapshot and older direct ProtectionWatcher callers.
        self.sl_pct = sl_pct
        self.target_pct = target_pct
        self.equity_sl_pct = sl_pct if equity_sl_pct is None else equity_sl_pct
        self.equity_target_pct = target_pct if equity_target_pct is None else equity_target_pct
        self.fno_sl_pct = sl_pct if fno_sl_pct is None else fno_sl_pct
        self.fno_target_pct = target_pct if fno_target_pct is None else fno_target_pct
        self.sl_limit_buffer_pct = sl_limit_buffer_pct
        self.path = path or os.environ.get("PENDING_PROTECTION_FILE") or DEFAULT_PATH
        self.dry_run = dry_run
        self.clock = clock or time.time
        self.journal_db = journal_db
        self.require_broker_leg_confirmation = require_broker_leg_confirmation
        cfg_obj = getattr(broker, "cfg", None)
        cfg_timeout = getattr(cfg_obj, "order_timeout_sec", 60.0)
        cfg_retry_timeout = getattr(cfg_obj, "partial_fill_retry_timeout_sec", 2.0)
        self.order_timeout_sec = (
            float(order_timeout_sec)
            if order_timeout_sec is not None
            else float(cfg_timeout if isinstance(cfg_timeout, (int, float)) else 60.0)
        )
        self.fno_timeout_sec = float(fno_timeout_sec)
        self.retry_timeout_sec = (
            float(retry_timeout_sec)
            if retry_timeout_sec is not None
            else float(cfg_retry_timeout if isinstance(cfg_retry_timeout, (int, float)) else 2.0)
        )
        self.risk_manager = risk_manager
        self.auto_retry_enabled = bool(auto_retry_enabled)
        self.max_cancel_attempts = max(1, int(max_cancel_attempts))
        self.cancel_backoff_sec = max(0.0, float(cancel_backoff_sec))
        self.orphan_cancel_ack_timeout_sec = max(1.0, float(orphan_cancel_ack_timeout_sec))
        self.orphan_cancel_retry_backoff_sec = max(1.0, float(orphan_cancel_retry_backoff_sec))
        self.orphan_cancel_max_attempts = max(1, int(orphan_cancel_max_attempts))
        self.orphan_cancel_deadline_sec = max(5.0, float(orphan_cancel_deadline_sec))
        self.pending: Dict[str, dict] = {}
        self.terminal_orders: Dict[str, dict] = {}
        self._lock = threading.RLock()
        self._pass_lock = threading.RLock()
        self._running_lock = threading.Lock()
        self._is_running = False
        self.execution_reporter = None  # read-only observer; set by TradingBotPipeline
        self._load()

    def _hydrate_loaded_record_defaults(self, rec: dict, is_term: bool = False) -> None:
        """
        CV13-02 & CV13-03: Ensures legacy records loaded from persistence without an explicit
        cancellation origin default to `retry_eligible=False`, and initializes all separate
        cancellation/timeout tracking flags.
        """
        raw_origin = rec.get("cancel_origin")
        if raw_origin is None or str(raw_origin).strip() == "":
            rec["cancel_origin"] = "LEGACY_UNKNOWN"
            rec["retry_eligible"] = False
        else:
            norm_orig = _normalize_cancel_origin(str(raw_origin))
            rec["cancel_origin"] = norm_orig
            if norm_orig != "BOT_TIMEOUT":
                rec["retry_eligible"] = False
            else:
                can_still_retry = (
                    int(rec.get("retry_count") or 0) < int(rec.get("max_retries") or 1)
                    and not bool(rec.get("retry_reserved", False))
                )
                rec["retry_eligible"] = bool(rec.get("retry_eligible", False)) and can_still_retry

        rec.setdefault("cancel_reason", "")
        rec.setdefault("entry_timeout_elapsed", bool(rec.get("timed_out_cancel", False)))
        rec.setdefault("is_amo", False)
        rec.setdefault("entry_only_amo", False)
        rec.setdefault("amo_manual_risk_alerted", False)
        if rec.get("entry_only_amo"):
            rec["retry_eligible"] = False
            rec["max_retries"] = 0
        rec.setdefault("amo_activated_at", 0.0)
        rec.setdefault(
            "cancel_requested",
            bool(rec.get("cancel_requested_at"))
            or rec.get("state") in (OrderLifecycleState.CANCEL_REQUESTED.value, OrderLifecycleState.CANCEL_PENDING.value),
        )
        rec.setdefault("cancel_acknowledged", rec.get("state") == OrderLifecycleState.CANCEL_PENDING.value)
        rec.setdefault("cancel_uncertain", False)
        rec.setdefault(
            "terminal_confirmed",
            bool(is_term) or rec.get("state") in {s.value for s in TERMINAL_STATES},
        )
        rec.setdefault("cancel_attempts", 1 if rec.get("cancel_requested") else 0)
        rec.setdefault("max_cancel_attempts", self.max_cancel_attempts)
        rec.setdefault("next_cancel_retry_at", 0.0)
        rec.setdefault("cancel_exhausted", False)
        rec.setdefault("cancel_exhausted_alerted", False)
        rec.setdefault("confirmed_protection_ids", [])
        if not rec.get("protection_route") or (
            rec.get("entry_only_amo") is True
            and str(rec.get("protection_route") or "").strip().upper() == ProtectionRoute.UNKNOWN.value
        ):
            rec["protection_route"] = infer_record_protection_route(rec)
        default_pos_state = (
            PositionLifecycleState.UNPROTECTED.value
            if (rec.get("entry_only_amo") is True or str(rec.get("protection_route") or "").strip().upper() == "ENTRY_ONLY_AMO")
            and max(0, int(rec.get("filled_qty") or 0) - int(rec.get("exit_filled_qty") or 0)) > 0
            and bool(is_term)
            else PositionLifecycleState.PROTECTED.value if int(rec.get("protected_qty") or 0) > 0
            else PositionLifecycleState.ENTRY.value
        )
        rec.setdefault("position_state", default_pos_state)
        if (
            bool(is_term)
            and (rec.get("entry_only_amo") is True or str(rec.get("protection_route") or "").strip().upper() == "ENTRY_ONLY_AMO")
            and max(0, int(rec.get("filled_qty") or 0) - int(rec.get("exit_filled_qty") or 0)) > 0
            and rec.get("position_state") in (PositionLifecycleState.ENTRY.value, PositionLifecycleState.POSITION_OPEN.value)
        ):
            rec["position_state"] = PositionLifecycleState.UNPROTECTED.value
        rec.setdefault("exit_filled_qty", 0)
        rec.setdefault("exit_vwap", 0.0)
        rec.setdefault("realized_pnl", 0.0)
        rec.setdefault("confirmed_position_open_qty", max(0, int(rec.get("filled_qty") or 0) - int(rec.get("exit_filled_qty") or 0)))
        rec.setdefault("verified_leg_order_ids", [])
        rec.setdefault("verified_leg_map", {})
        rec.setdefault("orphaned_leg_cancel_states", {})
        rec.setdefault("orphaned_leg_cancel_details", {})
        rec.setdefault("orphaned_legs_cancelled", False)
        rec.setdefault("orphaned_legs_manual_intervention_required", False)
        rec.setdefault("orphaned_legs_escalation_alerted", False)
        rec.setdefault("uncommitted_broker_sell_trades", [])
        rec.setdefault("reconciliation_required", False)
        rec.setdefault("persistence_uncertain", False)

    def _load(self):
        with self._lock:
            loaded_from_db = False
            if self.journal_db and hasattr(self.journal_db, "load_watcher_state"):
                try:
                    db_pending, db_term = self.journal_db.load_watcher_state()
                    if db_pending or db_term:
                        self.pending = db_pending
                        self.terminal_orders = db_term
                        loaded_from_db = True
                except Exception as e:
                    logger.warning(f"[Protection] Could not load watcher state from SQLite: {e}")

            if not loaded_from_db:
                if os.path.exists(self.path):
                    try:
                        with open(self.path, "r", encoding="utf-8") as f:
                            self.pending = json.load(f)
                    except Exception as e:
                        logger.warning(f"[Protection] Could not read {self.path}: {e}")
                        self.pending = {}

                term_path = f"{self.path}.terminal.json"
                if os.path.exists(term_path):
                    try:
                        with open(term_path, "r", encoding="utf-8") as f:
                            self.terminal_orders = json.load(f)
                    except Exception as e:
                        logger.warning(f"[Protection] Could not read {term_path}: {e}")
                        self.terminal_orders = {}

                if (self.pending or self.terminal_orders) and self.journal_db and hasattr(self.journal_db, "save_watcher_state"):
                    try:
                        self.journal_db.save_watcher_state(self.pending, self.terminal_orders)
                    except Exception:
                        pass

            for rec in self.pending.values():
                if isinstance(rec, dict):
                    self._hydrate_loaded_record_defaults(rec, is_term=False)
            for rec in self.terminal_orders.values():
                if isinstance(rec, dict):
                    self._hydrate_loaded_record_defaults(rec, is_term=True)

            # Hydrate cancellation metadata from SQLite order_intents if available
            if self.journal_db and hasattr(self.journal_db, "_get_conn"):
                try:
                    with self.journal_db._get_conn() as conn:
                        rows = conn.execute(
                            "SELECT correlation_id, broker_order_id, cancel_origin, cancel_reason, retry_eligible, "
                            "cancel_attempts, cancel_acknowledged, cancel_uncertain, entry_timeout_elapsed FROM order_intents "
                            "WHERE cancel_origin IS NOT NULL AND cancel_origin != ''"
                        ).fetchall()
                        for r in rows:
                            oid = str(r["broker_order_id"] or r["correlation_id"] or "")
                            target = self.pending.get(oid) or self.terminal_orders.get(oid)
                            if isinstance(target, dict) and target.get("cancel_origin") in ("", "LEGACY_UNKNOWN"):
                                c_orig = _normalize_cancel_origin(r["cancel_origin"])
                                target["cancel_origin"] = c_orig
                                target["cancel_reason"] = str(r["cancel_reason"] or "")
                                target["retry_eligible"] = (
                                    bool(r["retry_eligible"])
                                    and c_orig == "BOT_TIMEOUT"
                                    and int(target.get("retry_count") or 0) < int(target.get("max_retries") or 1)
                                    and not bool(target.get("retry_reserved", False))
                                )
                                target["cancel_attempts"] = max(int(target.get("cancel_attempts") or 0), int(r["cancel_attempts"] or 0))
                                target["cancel_acknowledged"] = bool(target.get("cancel_acknowledged") or r["cancel_acknowledged"])
                                target["cancel_uncertain"] = bool(target.get("cancel_uncertain") or r["cancel_uncertain"])
                                target["entry_timeout_elapsed"] = bool(target.get("entry_timeout_elapsed") or r["entry_timeout_elapsed"])
                except Exception:
                    pass

            # Safety Correction A & CV13-01: Restore any unresolved SQLite protection_attempts
            # across BOTH FOREVER_OCO and SUPER_ORDER routes into self.pending
            if self.journal_db and hasattr(self.journal_db, "get_unresolved_protection_attempts"):
                try:
                    unresolved = self.journal_db.get_unresolved_protection_attempts()
                    for row in unresolved:
                        p_oid = str(row.get("parent_order_id") or "")
                        if not p_oid:
                            continue
                        route_val = str(row.get("route") or "FOREVER_OCO").upper()
                        rec = self.pending.get(p_oid)
                        if rec is None and p_oid in self.terminal_orders:
                            rec = self.terminal_orders.pop(p_oid)
                            self.pending[p_oid] = rec
                        if rec is not None:
                            if route_val == "SUPER_ORDER":
                                rec["is_super_order"] = True
                            existing_p = rec.get("pending_oco")
                            if (
                                not isinstance(existing_p, dict)
                                or existing_p.get("correlation_id") == row.get("correlation_id")
                                or existing_p.get("attempt_id") == row.get("attempt_id")
                            ):
                                rec["pending_oco"] = self._attempt_row_to_pending_dict(row, rec, p_oid, route_val)
                except Exception as e:
                    logger.warning(f"[Protection] Could not restore protection_attempts from SQLite: {e}")

            # H11: Detect and repair any inconsistent watcher_orders rows (e.g. one-field SQL is_terminal=1
            # with stale record_json state='PENDING'/filled_qty=0, or verified fills in SQLite not reflected in record_json).
            if self.journal_db and hasattr(self.journal_db, "get_position_accounting"):
                needs_migration_save = False
                all_ids = list(set(list(self.pending.keys()) + list(self.terminal_orders.keys())))
                for oid in all_ids:
                    in_term = oid in self.terminal_orders
                    rec = self.terminal_orders.get(oid) if in_term else self.pending.get(oid)
                    if not isinstance(rec, dict):
                        continue
                    try:
                        acct = self.journal_db.get_position_accounting(oid)
                    except Exception:
                        acct = None
                    ver_buy_qty = int((acct or {}).get("buy_filled_qty") or 0)
                    ver_buy_vwap = float((acct or {}).get("buy_vwap") or 0.0)
                    ver_sell_qty = int((acct or {}).get("sell_filled_qty") or 0)
                    req_qty = int(rec.get("qty") or ver_buy_qty or 0)
                    cur_state = str(rec.get("state") or OrderLifecycleState.PENDING.value).upper()

                    if ver_buy_qty > 0:
                        if int(rec.get("filled_qty") or 0) != ver_buy_qty:
                            rec["filled_qty"] = ver_buy_qty
                            needs_migration_save = True
                        if ver_buy_vwap > 0 and abs(float(rec.get("avg_fill_price") or 0.0) - ver_buy_vwap) > 1e-4:
                            rec["avg_fill_price"] = ver_buy_vwap
                            needs_migration_save = True
                        rec["exit_filled_qty"] = max(int(rec.get("exit_filled_qty") or 0), ver_sell_qty)
                        open_q = max(0, ver_buy_qty - int(rec.get("exit_filled_qty") or 0))
                        rec["confirmed_position_open_qty"] = open_q

                        if req_qty > 0 and ver_buy_qty >= req_qty:
                            if cur_state != OrderLifecycleState.TRADED.value:
                                rec["state"] = OrderLifecycleState.TRADED.value
                                rec["terminal_confirmed"] = True
                                needs_migration_save = True
                            if not in_term and not rec.get("pending_oco"):
                                self.pending.pop(oid, None)
                                self.terminal_orders[oid] = rec
                                needs_migration_save = True
                        elif 0 < ver_buy_qty < req_qty:
                            if cur_state != OrderLifecycleState.PART_FILLED.value:
                                rec["state"] = OrderLifecycleState.PART_FILLED.value
                                rec["terminal_confirmed"] = False
                                needs_migration_save = True
                            if in_term:
                                self.terminal_orders.pop(oid, None)
                                self.pending[oid] = rec
                                needs_migration_save = True

                        prot_q = int(rec.get("protected_qty") or 0)
                        is_man_ack = (
                            hasattr(self.journal_db, "is_manual_risk_acknowledged")
                            and self.journal_db.is_manual_risk_acknowledged(oid, str(rec.get("correlation_id") or ""))
                        )
                        if open_q == 0:
                            target_pos_state = PositionLifecycleState.POSITION_CLOSED.value
                        elif prot_q >= open_q:
                            target_pos_state = PositionLifecycleState.PROTECTED.value
                        elif is_man_ack:
                            target_pos_state = "UNPROTECTED_MANUAL_RISK"
                            rec["manual_risk_acknowledged"] = True
                        else:
                            target_pos_state = PositionLifecycleState.UNPROTECTED.value

                        if rec.get("position_state") != target_pos_state:
                            rec["position_state"] = target_pos_state
                            needs_migration_save = True
                        self._sync_position_lifecycle(rec)
                    elif (
                        in_term
                        and int(rec.get("filled_qty") or 0) < max(1, int(rec.get("qty") or 1))
                        and cur_state in ("PENDING", "PART_FILLED", "ACKED", "TRANSIT", "TRIGGERED")
                    ):
                        # H11: Reject one-field SQL shortcut (`is_terminal=1` while JSON state is still PENDING/PART_FILLED with 0 fills)
                        rec["terminal_confirmed"] = False
                        self.terminal_orders.pop(oid, None)
                        self.pending[oid] = rec
                        needs_migration_save = True

                if needs_migration_save:
                    self._save()

    def _attempt_row_to_pending_dict(self, row: dict, rec: dict, p_oid: str, route_val: str) -> dict:
        return {
            "attempt_id": row.get("attempt_id"),
            "parent_order_id": p_oid,
            "root_order_id": row.get("root_order_id") or p_oid,
            "account_id": row.get("account_id") or "",
            "symbol": row.get("symbol") or rec.get("symbol", ""),
            "trading_symbol": row.get("trading_symbol") or rec.get("trading_symbol", ""),
            "security_id": str(row.get("security_id") or rec.get("security_id", "")),
            "exchange_segment": row.get("exchange_segment") or rec.get("segment", ""),
            "product_type": row.get("product_type") or rec.get("product_type", ""),
            "route": route_val,
            "uncovered_from_qty": int(row.get("uncovered_from_qty") or 0),
            "qty": int(row.get("quantity") or row.get("qty") or 0),
            "executed_price": float(row.get("executed_price") or 0.0),
            "sl_trigger": float(row.get("sl_trigger") or 0.0),
            "sl_limit": float(row.get("sl_limit") or 0.0),
            "target_price": float(row.get("target_price") or 0.0),
            "tick_size": float(row.get("tick_size") or rec.get("tick_size") or TICK),
            "correlation_id": row.get("correlation_id"),
            "oco_id": row.get("broker_order_id") or row.get("oco_id") or (p_oid if route_val == "SUPER_ORDER" else None),
            "state": row.get("state") or "SUBMITTING",
        }

    def _write_files_strict(self) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        tmp = f"{self.path}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.pending, f, indent=2)
        os.replace(tmp, self.path)

        if self.terminal_orders:
            term_path = f"{self.path}.terminal.json"
            term_tmp = f"{term_path}.tmp"
            with open(term_tmp, "w", encoding="utf-8") as f:
                json.dump(self.terminal_orders, f, indent=2)
            os.replace(term_tmp, term_path)

    def _save_strict(self) -> None:
        """
        Safety Correction A: Commits watcher state to SQLite and disk WITHOUT swallowing exceptions.
        Used before any broker mutation so a persistence failure blocks the mutation.
        """
        with self._lock:
            if self.journal_db and hasattr(self.journal_db, "save_watcher_state"):
                self.journal_db.save_watcher_state(self.pending, self.terminal_orders)
            self._write_files_strict()

    def _save(self) -> bool:
        """Persist both watcher copies; callers may require positive readback."""
        with self._lock:
            success = True
            if self.journal_db and hasattr(self.journal_db, "save_watcher_state"):
                try:
                    self.journal_db.save_watcher_state(self.pending, self.terminal_orders)
                except Exception as e:
                    logger.warning(f"[Protection] Could not sync watcher state to SQLite: {e}")
                    success = False

            try:
                self._write_files_strict()
            except Exception as e:
                logger.error(f"[Protection] Could not write {self.path}: {e}")
                success = False
            return success

    def _protection_for_segment(self, segment: str) -> tuple[float, float]:
        """Choose separate Equity or stock-option protection for NEW orders."""
        seg = str(segment or "").strip().upper()
        if seg in ("NSE_EQ", "BSE_EQ"):
            return float(self.equity_sl_pct), float(self.equity_target_pct)
        if seg in ("NSE_FNO", "BSE_FNO", "NSE_FO", "BSE_FO"):
            return float(self.fno_sl_pct), float(self.fno_target_pct)
        # Legacy compatibility for direct non-trading watcher callers.
        return float(self.sl_pct), float(self.target_pct)

    def track(
        self,
        order_id: str,
        symbol: str,
        security_id: str,
        segment: str,
        qty: int,
        product_type: str = "CNC",
        dry_price: Optional[float] = None,
        original_market_price: Optional[float] = None,
        is_super_order: bool = False,
        tick_size: float = TICK,
        lot_size: int = 1,
        option_type: str = "",
        strike: float = 0.0,
        expiry: Optional[Any] = None,
        trading_symbol: str = "",
        correlation_id: str = "",
        preserve_existing: bool = True,
        retry_count: int = 0,
        max_retries: int = 1,
        retry_reserved: bool = False,
        root_order_id: str = "",
        notification_meta: Optional[dict] = None,
        is_amo: bool = False,
        entry_only_amo: bool = False,
        protection_sl_pct: Optional[float] = None,
        protection_target_pct: Optional[float] = None,
        protection_route: Optional[str] = None,
        initial_sl_price: Optional[float] = None,
        initial_target_price: Optional[float] = None,
    ) -> str:
        chosen_sl, chosen_target = self._protection_for_segment(segment)
        if protection_sl_pct is not None:
            chosen_sl = float(protection_sl_pct)
        if protection_target_pct is not None:
            chosen_target = float(protection_target_pct)
        if not (
            math.isfinite(chosen_sl) and 0 < chosen_sl <= 50
            and math.isfinite(chosen_target) and 0 < chosen_target <= 100
        ):
            raise ValueError("Invalid per-order protection percentages")
        exp_str = ""
        if isinstance(expiry, date):
            exp_str = expiry.isoformat()
        elif isinstance(expiry, str):
            exp_str = expiry.strip()

        with self._lock:
            existing = self.pending.get(order_id) or self.terminal_orders.get(order_id)
            if existing is not None and preserve_existing:
                if correlation_id and existing.get("correlation_id") in ("", order_id):
                    existing["correlation_id"] = correlation_id
                if trading_symbol and not existing.get("trading_symbol"):
                    existing["trading_symbol"] = trading_symbol
                if is_super_order:
                    existing["is_super_order"] = True
                if protection_route:
                    existing["protection_route"] = str(protection_route).strip().upper()
                elif not existing.get("protection_route"):
                    existing["protection_route"] = infer_record_protection_route(existing)
                if tick_size and tick_size != TICK and existing.get("tick_size", TICK) == TICK:
                    existing["tick_size"] = float(tick_size)
                if lot_size and int(lot_size) > 1 and existing.get("lot_size", 1) == 1:
                    existing["lot_size"] = int(lot_size)
                if option_type and not existing.get("option_type"):
                    existing["option_type"] = str(option_type).strip().upper()
                if strike and float(strike) > 0 and not existing.get("strike"):
                    existing["strike"] = float(strike)
                if exp_str and not existing.get("expiry"):
                    existing["expiry"] = exp_str
                if original_market_price and float(original_market_price) > 0 and not existing.get("original_market_price"):
                    existing["original_market_price"] = float(original_market_price)
                if notification_meta and not existing.get("notification_meta"):
                    existing["notification_meta"] = dict(notification_meta)
                if is_amo:
                    existing["is_amo"] = True
                if entry_only_amo:
                    existing["entry_only_amo"] = True
                if order_id not in self.pending and order_id in self.terminal_orders:
                    pass
                else:
                    self.pending[order_id] = existing
                rec = existing
            else:
                is_child_exhausted = int(retry_count) >= int(max_retries) or bool(retry_reserved)
                rec = {
                    "order_id": order_id,
                    "root_order_id": root_order_id or order_id,
                    "correlation_id": correlation_id or order_id,
                    "symbol": symbol,
                    "trading_symbol": trading_symbol,
                    "security_id": str(security_id),
                    "segment": segment,
                    "product_type": product_type,
                    # Immutable protection policy snapshot for this parent order.
                    # Reloading WebUI settings cannot retarget an existing order.
                    "protection_sl_pct": chosen_sl,
                    "protection_target_pct": chosen_target,
                    "is_super_order": bool(is_super_order),
                    "is_amo": bool(is_amo),
                    "entry_only_amo": bool(entry_only_amo),
                    "amo_manual_risk_alerted": False,
                    "amo_activated_at": 0.0,
                    "protection_route": (
                        str(protection_route).strip().upper()
                        if protection_route
                        else ("SUPER_ORDER" if is_super_order else ("FOREVER_OCO" if str(product_type).upper() in ("CNC", "MTF") else "UNKNOWN"))
                    ),
                    "initial_protection_mode": "LIMIT_RELATIVE_INITIAL" if (is_super_order and initial_sl_price and initial_target_price) else "",
                    "initial_sl_price": float(initial_sl_price or 0.0),
                    "initial_target_price": float(initial_target_price or 0.0),
                    "position_state": PositionLifecycleState.ENTRY.value,
                    "exit_filled_qty": 0,
                    "exit_vwap": 0.0,
                    "realized_pnl": 0.0,
                    "confirmed_position_open_qty": 0,
                    "tick_size": tick_size if tick_size and tick_size > 0 else TICK,
                    "lot_size": int(lot_size) if lot_size and int(lot_size > 0) else 1,
                    "option_type": (option_type or "").strip().upper(),
                    "strike": float(strike or 0.0),
                    "expiry": exp_str,
                    "qty": int(qty),
                    "filled_qty": 0,
                    "protected_qty": 0,
                    "protected_value": 0.0,
                    "created_at": self.clock(),
                    "retry_at": 0.0,
                    "dry_price": dry_price,
                    "original_market_price": (
                        float(original_market_price)
                        if (original_market_price is not None and original_market_price > 0)
                        else (float(dry_price) if (dry_price is not None and dry_price > 0) else 0.0)
                    ),
                    "state": OrderLifecycleState.PENDING.value,
                    "entry_timeout_elapsed": False,
                    "cancel_requested": False,
                    "cancel_requested_at": None,
                    "cancel_acknowledged": False,
                    "cancel_uncertain": False,
                    "terminal_confirmed": False,
                    "cancel_origin": "",
                    "cancel_reason": "",
                    "retry_eligible": False if is_child_exhausted else None,
                    "cancel_attempts": 0,
                    "max_cancel_attempts": self.max_cancel_attempts,
                    "next_cancel_retry_at": 0.0,
                    "cancel_exhausted": False,
                    "cancel_exhausted_alerted": False,
                    "retry_count": int(retry_count),
                    "max_retries": int(max_retries),
                    "retry_reserved": bool(retry_reserved),
                    "pending_oco": None,
                    "notification_meta": dict(notification_meta) if notification_meta else None,
                }
                self.pending[order_id] = rec
        self._save()
        logger.info(f"[Protection] Tracking {symbol} order {order_id} ({qty} units, {segment}/{product_type})")
        return order_id

    def _sync_cancellation_to_db(self, rec: dict) -> None:
        if self.journal_db and hasattr(self.journal_db, "update_order_cancellation_metadata"):
            try:
                self.journal_db.update_order_cancellation_metadata(
                    broker_order_id=str(rec.get("order_id") or ""),
                    correlation_id=str(rec.get("correlation_id") or ""),
                    cancel_origin=str(rec.get("cancel_origin") or ""),
                    cancel_reason=str(rec.get("cancel_reason") or ""),
                    retry_eligible=bool(rec.get("retry_eligible", False)),
                    cancel_attempts=int(rec.get("cancel_attempts") or 0),
                    cancel_acknowledged=bool(rec.get("cancel_acknowledged", False)),
                    cancel_uncertain=bool(rec.get("cancel_uncertain", False)),
                    entry_timeout_elapsed=bool(rec.get("entry_timeout_elapsed", False)),
                    state=str(rec.get("state") or ""),
                    now=self.clock(),
                )
            except Exception as e:
                logger.warning(f"[Protection] Could not sync cancellation metadata to SQLite: {e}")

    def request_cancel(
        self,
        order_id: str,
        origin: Optional[str] = None,
        reason: Optional[str] = None,
        cancel_origin: Optional[str] = None,
        cancel_reason: Optional[str] = None,
        retry_eligible: Optional[bool] = None,
    ) -> Tuple[bool, str]:
        with self._lock:
            rec = self.pending.get(order_id)
            if not rec:
                return False, f"Order {order_id} not in tracking"

            if rec["state"] in {s.value for s in TERMINAL_STATES}:
                return False, f"Order {order_id} is already in terminal state: {rec['state']}"

            prev_state = rec["state"]
            req_ts = self.clock()

            explicit_orig = origin or cancel_origin
            if explicit_orig is not None and str(explicit_orig).strip() != "":
                resolved_origin = _normalize_cancel_origin(str(explicit_orig))
            elif rec.get("cancel_origin") and rec.get("cancel_origin") not in ("", "LEGACY_UNKNOWN"):
                resolved_origin = _normalize_cancel_origin(str(rec.get("cancel_origin")))
            else:
                resolved_origin = "MANUAL_OPERATOR"

            explicit_reas = reason or cancel_reason
            if explicit_reas is not None and str(explicit_reas).strip() != "":
                resolved_reason = str(explicit_reas).strip()
            elif rec.get("cancel_reason"):
                resolved_reason = str(rec.get("cancel_reason"))
            elif resolved_origin == "BOT_TIMEOUT":
                resolved_reason = "Entry remainder timeout elapsed"
            else:
                resolved_reason = f"Cancellation requested ({resolved_origin})"

            lineage_has_budget = (
                int(rec.get("retry_count") or 0) < int(rec.get("max_retries") or 1)
                and not bool(rec.get("retry_reserved", False))
            )
            if resolved_origin == "BOT_TIMEOUT" and lineage_has_budget and (retry_eligible is not False):
                resolved_eligible = True
            else:
                resolved_eligible = False

            rec["cancel_origin"] = resolved_origin
            rec["cancel_reason"] = resolved_reason
            rec["retry_eligible"] = bool(resolved_eligible)
            rec["cancel_requested"] = True
            rec["cancel_requested_at"] = req_ts
            rec["cancel_attempts"] = int(rec.get("cancel_attempts") or 0) + 1
            rec["state"] = OrderLifecycleState.CANCEL_REQUESTED.value

            # Persist explicit cancellation origin, reason, and retry eligibility BEFORE broker DELETE call (CV13-02)
            self._sync_cancellation_to_db(rec)
            self._save()

        if rec.get("is_super_order") and hasattr(self.broker, "cancel_super_order_leg"):
            raw_ret = self.broker.cancel_super_order_leg(order_id, "ENTRY_LEG")
        elif hasattr(self.broker, "cancel_order"):
            raw_ret = self.broker.cancel_order(order_id)
        else:
            raw_ret = (True, "Simulated cancel request dispatched")

        if isinstance(raw_ret, tuple) and len(raw_ret) == 2:
            ok, msg = bool(raw_ret[0]), str(raw_ret[1])
        else:
            ok, msg = bool(raw_ret), str(raw_ret)

        with self._lock:
            now_after = self.clock()
            attempts = int(rec.get("cancel_attempts") or 1)
            backoff = min(30.0, float(self.cancel_backoff_sec) * (2 ** max(0, attempts - 1)))
            if ok:
                rec["state"] = OrderLifecycleState.CANCEL_PENDING.value
                rec["cancel_acknowledged"] = True
                rec["cancel_uncertain"] = False
                rec["next_cancel_retry_at"] = 0.0
                if rec.get("entry_timeout_elapsed", False):
                    rec["timed_out_cancel"] = True
                logger.info(
                    f"[Protection] Cancellation request acknowledged for {order_id} "
                    f"(origin={rec['cancel_origin']}, retry_eligible={rec['retry_eligible']}); state set to CANCEL_PENDING."
                )
            else:
                rec["cancel_acknowledged"] = False
                rec["timed_out_cancel"] = False
                rec["next_cancel_retry_at"] = now_after + backoff
                if _is_ambiguous_message(msg):
                    rec["state"] = OrderLifecycleState.CANCEL_REQUESTED.value
                    rec["cancel_uncertain"] = True
                    rec["cancel_error"] = msg
                    logger.warning(
                        f"[Protection] Cancellation outcome uncertain for {order_id} due to network timeout/error: {msg}. "
                        f"Preserving as unresolved CANCEL_REQUESTED pending broker reconciliation (next check in {backoff:g}s)."
                    )
                else:
                    rec["state"] = prev_state
                    rec["cancel_uncertain"] = False
                    rec["cancel_error"] = msg
                    logger.warning(
                        f"[Protection] Cancel request rejected by broker for {order_id}: {msg}. "
                        f"Reverted to {prev_state} (retry in {backoff:g}s)."
                    )
            self._sync_cancellation_to_db(rec)
            self._save()
        return ok, msg

    def _resolve_protection_route(self, rec: dict) -> str:
        """P0-02: Resolves explicit protection_route without inferring from product_type == 'MARGIN'."""
        route = infer_record_protection_route(rec)
        rec["protection_route"] = route
        if route == ProtectionRoute.SUPER_ORDER.value:
            rec["is_super_order"] = True
        return route

    def _sync_position_lifecycle(self, rec: dict) -> bool:
        if not self.journal_db or not hasattr(self.journal_db, "upsert_position_lifecycle"):
            return True
        try:
            self.journal_db.upsert_position_lifecycle(
                parent_order_id=str(rec.get("order_id") or ""),
                symbol=str(rec.get("symbol") or ""),
                trading_symbol=str(rec.get("trading_symbol") or rec.get("symbol") or ""),
                security_id=str(rec.get("security_id") or ""),
                exchange_segment=str(rec.get("segment") or "NSE_EQ"),
                product_type=str(rec.get("product_type") or "CNC"),
                protection_route=str(rec.get("protection_route") or self._resolve_protection_route(rec)),
                position_state=str(rec.get("position_state") or PositionLifecycleState.ENTRY.value),
                entry_qty=int(rec.get("qty") or 0),
                buy_filled_qty=int(rec.get("filled_qty") or 0),
                buy_vwap=float(rec.get("buy_vwap") or rec.get("original_market_price") or 0.0),
                protected_qty=int(rec.get("protected_qty") or 0),
                sl_price=float(rec.get("confirmed_sl_price") or rec.get("initial_sl_price") or 0.0),
                target_price=float(rec.get("confirmed_target_price") or rec.get("initial_target_price") or 0.0),
                sell_filled_qty=int(rec.get("exit_filled_qty") or 0),
                sell_vwap=float(rec.get("exit_vwap") or 0.0),
                confirmed_open_qty=int(rec.get("confirmed_position_open_qty") or max(0, int(rec.get("filled_qty") or 0) - int(rec.get("exit_filled_qty") or 0))),
                realized_pnl=float(rec.get("realized_pnl") or 0.0),
                triggered_leg=str(rec.get("triggered_leg") or ""),
                manual_exit_detected=bool(rec.get("manual_exit_detected", False)),
                orphaned_legs_detected=bool(rec.get("orphaned_legs_detected", False)),
                now=self.clock(),
            )
            return True
        except Exception as e:
            logger.error(f"[Protection] 🚨 Could not sync position lifecycle to SQLite for {rec.get('order_id')}: {e}")
            return False

    def _find_unresolved_attempt(self, rec: dict, route_name: str) -> Optional[dict]:
        """CV13-01: Finds any existing unresolved protection attempt for `(parent_order_id, route_name)`."""
        pending_att = rec.get("pending_oco")
        if (
            isinstance(pending_att, dict)
            and str(pending_att.get("route") or "FOREVER_OCO").upper() == route_name
            and pending_att.get("state") in ("SUBMITTING", "UNKNOWN", "ACKED_UNVERIFIED")
        ):
            return pending_att

        if self.journal_db and hasattr(self.journal_db, "get_unresolved_protection_attempts"):
            try:
                rows = self.journal_db.get_unresolved_protection_attempts(rec["order_id"])
                if isinstance(rows, list):
                    for r in rows:
                        if isinstance(r, dict) and str(r.get("route") or "FOREVER_OCO").upper() == route_name:
                            hydrated = self._attempt_row_to_pending_dict(r, rec, rec["order_id"], route_name)
                            rec["pending_oco"] = hydrated
                            return hydrated
            except Exception:
                pass
        return None


    def reconcile_historical_order_fills(
        self,
        *,
        order_id: str,
        correlation_id: str,
        symbol: str,
        security_id: str,
        segment: str,
        product_type: str,
        requested_qty: int,
        filled_qty: int,
        avg_fill_price: float,
        verified_protected_qty: int = 0,
        verified_closed_qty: int = 0,
        confirmed_protection_ids: Optional[List[str]] = None,
        manual_risk_acknowledged: bool = False,
        is_amo: bool = False,
        protection_route: str = "",
        original_market_price: float = 0.0,
        now: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        H01, H07, H08, H11, H16: Updates watcher `record_json` and `is_terminal` atomically under lock
        from verified historical fills without placing any automatic OCO or assuming `TRADED` implies
        `POSITION_CLOSED` or `PROTECTED`.
        """
        ts = float(now if now is not None else self.clock())
        oid = str(order_id or "").strip()
        cid = str(correlation_id or oid).strip()
        req_q = int(requested_qty or 0)
        fill_q = int(filled_qty or 0)
        prot_q = max(0, int(verified_protected_qty or 0))
        closed_q = max(0, int(verified_closed_qty or 0))
        open_q = max(0, fill_q - closed_q)

        with self._lock:
            existing = self.pending.get(oid) or self.terminal_orders.get(oid)
            if isinstance(existing, dict):
                rec = dict(existing)
            else:
                sl_pct, tgt_pct = self._protection_for_segment(segment)
                rec = {
                    "order_id": oid,
                    "root_order_id": oid,
                    "parent_order_id": None,
                    "correlation_id": cid,
                    "symbol": str(symbol),
                    "trading_symbol": str(symbol),
                    "security_id": str(security_id),
                    "segment": str(segment).upper(),
                    "product_type": str(product_type).upper(),
                    "is_super_order": (str(protection_route).upper() == "SUPER_ORDER"),
                    "is_amo": bool(is_amo),
                    "entry_only_amo": (str(protection_route).upper() == "ENTRY_ONLY_AMO"),
                    "protection_route": str(protection_route or ("FOREVER_OCO" if str(product_type).upper() in ("CNC", "MTF") else "UNKNOWN")),
                    "qty": req_q,
                    "original_market_price": float(original_market_price or avg_fill_price or 0.0),
                    "sl_pct": sl_pct,
                    "target_pct": tgt_pct,
                    "tick_size": 0.05,
                    "lot_size": 1,
                    "created_at": ts,
                }
                self._hydrate_loaded_record_defaults(rec, is_term=(fill_q >= req_q))

            rec["order_id"] = oid
            rec["correlation_id"] = cid
            rec["symbol"] = str(symbol or rec.get("symbol") or "")
            rec["security_id"] = str(security_id or rec.get("security_id") or "")
            rec["segment"] = str(segment or rec.get("segment") or "NSE_EQ").upper()
            rec["product_type"] = str(product_type or rec.get("product_type") or "CNC").upper()
            rec["qty"] = req_q
            rec["filled_qty"] = fill_q
            rec["avg_fill_price"] = float(avg_fill_price or rec.get("avg_fill_price") or 0.0)
            rec["exit_filled_qty"] = closed_q
            rec["confirmed_position_open_qty"] = open_q
            # Never assume entry TRADED implies protected_qty > 0; require verified_protected_qty
            rec["protected_qty"] = prot_q
            if confirmed_protection_ids:
                rec["confirmed_protection_ids"] = sorted(set(list(rec.get("confirmed_protection_ids") or []) + [str(x) for x in confirmed_protection_ids if x]))

            if fill_q >= req_q and req_q > 0:
                rec["state"] = OrderLifecycleState.TRADED.value
                rec["terminal_confirmed"] = True
                rec["finalized_at"] = float(rec.get("finalized_at") or ts)
            else:
                rec["state"] = OrderLifecycleState.PART_FILLED.value if fill_q > 0 else OrderLifecycleState.PENDING.value
                rec["terminal_confirmed"] = False

            if open_q == 0 and fill_q > 0:
                rec["position_state"] = PositionLifecycleState.POSITION_CLOSED.value
            elif prot_q >= open_q and open_q > 0:
                rec["position_state"] = PositionLifecycleState.PROTECTED.value
            elif manual_risk_acknowledged and open_q > 0:
                rec["position_state"] = "UNPROTECTED_MANUAL_RISK"
                rec["manual_risk_acknowledged"] = True
            elif open_q > 0:
                rec["position_state"] = PositionLifecycleState.UNPROTECTED.value
            else:
                rec["position_state"] = PositionLifecycleState.ENTRY.value

            if rec["terminal_confirmed"] and not rec.get("pending_oco"):
                self.pending.pop(oid, None)
                self.terminal_orders[oid] = rec
            else:
                self.terminal_orders.pop(oid, None)
                self.pending[oid] = rec

            self._sync_position_lifecycle(rec)
            self._save()
            return dict(rec)

    def check_once(self) -> bool:
        with self._pass_lock:
            self._supervision_read_complete = False
            changed = False
            current_time = self.clock()

            gate = getattr(self.broker, "reconciliation_gate", None)
            if gate is not None and hasattr(gate, "reconcile_runtime_unknown_intents"):
                try:
                    gate.reconcile_runtime_unknown_intents()
                except Exception:
                    pass

            for order_id, rec in list(self.pending.items()):
                try:
                    st = self._get_order_status(rec)
                except Exception as e:
                    logger.warning(f"[Protection] Status poll failed for {rec['symbol']} {order_id}: {e}")
                    st = None

                if not st or not isinstance(st, dict) or not st.get("orderStatus"):
                    # CV13-03 Requirement 5: If state cannot be established after a failed/uncertain cancel or timeout,
                    # retain uncertainty, block replacement entry, and report the unresolved order.
                    if rec.get("cancel_uncertain") or rec.get("cancel_requested") or rec.get("entry_timeout_elapsed"):
                        rec["cancel_uncertain"] = True
                        unres_msg = f"Broker order state cannot be established for {rec['symbol']} ({order_id}) during cancellation recovery"
                        logger.error(f"[Protection] 🚨 {unres_msg}")
                        if gate is not None and hasattr(gate, "halt_new_entries"):
                            gate.halt_new_entries(unres_msg)
                        if self.journal_db and hasattr(self.journal_db, "record_system_event"):
                            try:
                                self.journal_db.record_system_event("UNRESOLVED_CANCELLATION_STATE", unres_msg)
                            except Exception:
                                pass
                        changed = True
                    continue

                prev_state = str(rec.get("state") or OrderLifecycleState.PENDING.value)
                broker_status = str(st.get("orderStatus", "")).upper()
                prev_filled = int(rec.get("filled_qty") or 0)
                req_qty = int(rec.get("qty") or 0)
                raw_filled = st.get("filledQty", 0)
                if raw_filled is None:
                    raw_filled = 0
                malformed_fill_qty = False
                parsed_filled = 0
                if isinstance(raw_filled, bool):
                    malformed_fill_qty = True
                elif isinstance(raw_filled, int):
                    parsed_filled = raw_filled
                elif isinstance(raw_filled, float):
                    if not math.isfinite(raw_filled) or not raw_filled.is_integer():
                        malformed_fill_qty = True
                    else:
                        parsed_filled = int(raw_filled)
                elif isinstance(raw_filled, str):
                    s_fill = raw_filled.strip()
                    if not s_fill or not s_fill.lstrip("-").isdigit():
                        malformed_fill_qty = True
                    else:
                        parsed_filled = int(s_fill)
                else:
                    malformed_fill_qty = True

                if not malformed_fill_qty:
                    if parsed_filled < 0 or parsed_filled < prev_filled or (req_qty > 0 and parsed_filled > req_qty):
                        malformed_fill_qty = True
                    elif rec.get("entry_only_amo") and broker_status in ("TRADED", "CLOSED") and parsed_filled != req_qty:
                        malformed_fill_qty = True

                if malformed_fill_qty:
                    rec["filled_qty"] = prev_filled
                    rec["unreadable_broker_response"] = True
                    if rec.get("entry_only_amo"):
                        rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                        rec["reconciliation_required"] = True
                    if gate is not None and hasattr(gate, "halt_new_entries"):
                        gate.halt_new_entries(
                            f"Malformed or inconsistent broker filledQty ({raw_filled!r}) for {rec.get('symbol')} ({order_id})"
                        )
                    if self.execution_reporter is not None and rec.get("notification_meta"):
                        try:
                            self.execution_reporter.process(rec, st, observed_at=current_time)
                        except Exception:
                            pass
                    changed = True
                    continue

                filled = parsed_filled
                rec["filled_qty"] = filled

                # Map broker status to lifecycle state and update separate CV13-03 tracking flags
                if broker_status == "PART_TRADED":
                    rec["state"] = OrderLifecycleState.PART_FILLED.value
                    rec["terminal_confirmed"] = False
                    rec["cancel_uncertain"] = False
                elif broker_status in ("TRADED", "CLOSED"):
                    rec["state"] = OrderLifecycleState.TRADED.value
                    rec["terminal_confirmed"] = True
                    rec["cancel_uncertain"] = False
                    rec["next_cancel_retry_at"] = 0.0
                elif broker_status == "CANCELLED":
                    rec["state"] = OrderLifecycleState.CANCELLED.value
                    rec["terminal_confirmed"] = True
                    rec["cancel_uncertain"] = False
                    rec["next_cancel_retry_at"] = 0.0
                    # CV13-02: If broker reports CANCELLED without a recorded BOT_TIMEOUT origin
                    # (and order was not placed into CANCEL_PENDING by a prior unit-test fixture),
                    # record as EXTERNAL_OR_UNKNOWN and prohibit automatic retry.
                    if not rec.get("cancel_origin"):
                        if prev_state != OrderLifecycleState.CANCEL_PENDING.value:
                            rec["cancel_origin"] = "EXTERNAL_OR_UNKNOWN"
                            rec["cancel_reason"] = "External or unknown cancellation observed on broker"
                            rec["retry_eligible"] = False
                            self._sync_cancellation_to_db(rec)
                    elif _normalize_cancel_origin(rec.get("cancel_origin")) != "BOT_TIMEOUT":
                        rec["retry_eligible"] = False
                        self._sync_cancellation_to_db(rec)
                elif broker_status == "EXPIRED":
                    rec["state"] = OrderLifecycleState.EXPIRED.value
                    rec["terminal_confirmed"] = True
                    rec["cancel_uncertain"] = False
                    rec["next_cancel_retry_at"] = 0.0
                elif broker_status == "REJECTED":
                    rec["state"] = OrderLifecycleState.REJECTED.value
                    rec["terminal_confirmed"] = True
                    rec["cancel_uncertain"] = False
                    rec["next_cancel_retry_at"] = 0.0
                elif broker_status in ("PENDING", "TRANSIT", "TRIGGERED"):
                    rec["terminal_confirmed"] = False
                    rec["cancel_uncertain"] = False
                    if rec["state"] != OrderLifecycleState.CANCEL_PENDING.value and not rec.get("cancel_acknowledged", False):
                        rec["state"] = OrderLifecycleState.PENDING.value

                # Advance parent order_intents and orders in SQLite when state or fill changes
                if self.journal_db and hasattr(self.journal_db, "update_order_lifecycle_by_broker_id"):
                    try:
                        self.journal_db.update_order_lifecycle_by_broker_id(
                            broker_order_id=order_id,
                            correlation_id=str(rec.get("correlation_id") or ""),
                            state=rec["state"],
                        )
                    except Exception:
                        pass

                if filled > prev_filled:
                    try:
                        GLOBAL_LATENCY_MONITOR.record_fill_confirmed(order_id)
                        if rec.get("correlation_id"):
                            GLOBAL_LATENCY_MONITOR.record_fill_confirmed(str(rec["correlation_id"]))
                    except Exception:
                        pass
                if filled > prev_filled:
                    rec["confirmed_position_open_qty"] = max(0, filled - int(rec.get("exit_filled_qty") or 0))
                    if rec.get("position_state") in (None, "", PositionLifecycleState.ENTRY.value):
                        rec["position_state"] = PositionLifecycleState.POSITION_OPEN.value
                fill_persist_failed = False
                if filled > prev_filled and self.journal_db and hasattr(self.journal_db, "record_fill"):
                    def record_entry_fill(**values):
                        nonlocal fill_persist_failed
                        try:
                            return self.journal_db.record_fill(**values)
                        except Exception:
                            fill_persist_failed = True
                            if rec.get("entry_only_amo"):
                                rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                                rec["reconciliation_required"] = True
                                rec["persistence_uncertain"] = True
                                rec["filled_qty"] = prev_filled
                                rec["confirmed_position_open_qty"] = max(0, prev_filled - int(rec.get("exit_filled_qty") or 0))
                                if gate is not None and hasattr(gate, "halt_new_entries"):
                                    gate.halt_new_entries(f"Entry-only AMO {order_id}: fill persistence failed")
                            raise

                    recorded_real_trades = False
                    if hasattr(self.broker, "get_trades_for_order"):
                        try:
                            t_res = self.broker.get_trades_for_order(order_id)
                            if isinstance(t_res, list) and len(t_res) > 0:
                                for tr in t_res:
                                    if isinstance(tr, dict) and tr.get("exchangeTradeId") and float(tr.get("tradedPrice") or 0) > 0:
                                        record_entry_fill(
                                            broker_order_id=order_id,
                                            exchange_trade_id=str(tr["exchangeTradeId"]),
                                            symbol=rec["symbol"],
                                            traded_price=float(tr["tradedPrice"]),
                                            traded_quantity=int(tr["tradedQuantity"]),
                                            traded_at=current_time,
                                            transaction_type=str(tr.get("transactionType") or "BUY").upper(),
                                            security_id=str(rec.get("security_id") or ""),
                                            exchange_segment=str(rec.get("segment") or ""),
                                            product_type=str(rec.get("product_type") or ""),
                                            parent_order_id=order_id,
                                            is_verified_trade=True,
                                        )
                                        recorded_real_trades = True
                        except Exception:
                            recorded_real_trades = False
                    if not recorded_real_trades and not fill_persist_failed:
                        try:
                            avg_p = float(st.get("averageTradedPrice") or 0.0)
                            record_entry_fill(
                                broker_order_id=order_id,
                                exchange_trade_id=f"{order_id}-FILL-{filled}",
                                symbol=rec["symbol"],
                                traded_price=avg_p,
                                traded_quantity=filled - prev_filled,
                                traded_at=current_time,
                                transaction_type="BUY",
                                security_id=str(rec.get("security_id") or ""),
                                exchange_segment=str(rec.get("segment") or ""),
                                product_type=str(rec.get("product_type") or ""),
                                parent_order_id=order_id,
                                is_verified_trade=False,
                            )
                        except Exception:
                            pass
                    if not fill_persist_failed and rec.get("entry_only_amo") and rec.get("persistence_uncertain"):
                        rec["persistence_uncertain"] = False
                        rec["reconciliation_required"] = False
                        if rec.get("position_state") == PositionLifecycleState.RECONCILIATION_REQUIRED.value:
                            rec["position_state"] = PositionLifecycleState.POSITION_OPEN.value

                # 1. Reconcile any existing unresolved protection attempt (FOREVER_OCO or SUPER_ORDER)
                #    OR protect newly executed units (P0-02: use explicit protection_route, never product_type == MARGIN).
                route_name = self._resolve_protection_route(rec)
                is_super = (route_name == ProtectionRoute.SUPER_ORDER.value)
                unresolved_att = self._find_unresolved_attempt(rec, route_name)
                has_unresolved_attempt = unresolved_att is not None
                new_qty = filled - int(rec.get("protected_qty") or 0)

                if rec.get("entry_only_amo") and filled > 0 and not rec.get("amo_manual_risk_alerted"):
                    rec["amo_manual_risk_alerted"] = True
                    logger.critical("F&O AMO FILL %s: %s units have NO AUTOMATIC SL/TARGET. Manual exit required.",
                                    order_id, filled)
                    changed = True
                # Explicitly do not attempt MARGIN Forever OCO or modify a
                # Super Order that does not exist for this entry-only AMO.
                should_call_protect = not rec.get("entry_only_amo") and (
                    has_unresolved_attempt
                    or (filled > prev_filled and new_qty > 0)
                    or (new_qty > 0 and current_time >= float(rec.get("retry_at") or 0.0))
                )
                if should_call_protect:
                    changed |= self._protect(rec, st, filled, max(0, new_qty))

                # Re-evaluate unresolved attempt status after _protect()
                unresolved_att_after = self._find_unresolved_attempt(rec, route_name)
                has_unresolved_after = unresolved_att_after is not None
                is_terminal = rec["state"] in {s.value for s in TERMINAL_STATES}

                # Observe broker lifecycle AFTER the existing protection verification.
                # Notification failures must never create another trade or bypass stops.
                notify_ready = True
                if self.execution_reporter is not None and rec.get("notification_meta"):
                    prev_notification_pending = rec.get("notification_protection_pending")
                    try:
                        notify_ready = bool(self.execution_reporter.process(rec, st, observed_at=current_time))
                    except Exception as notify_err:
                        notify_ready = False
                        logger.warning("[OrderNotification] Could not enqueue status: %s", notify_err)
                    if prev_notification_pending != rec.get("notification_protection_pending"):
                        changed = True

                # 2. CV13-03: Remainder timeout & bounded-backoff cancellation recovery
                if not str(order_id).startswith("DRY-") and not is_terminal and filled < int(rec.get("qty") or 0):
                    seg = str(rec.get("segment") or "NSE_EQ").upper()
                    if int(rec.get("retry_count") or 0) >= 1:
                        timeout_limit = self.retry_timeout_sec
                    else:
                        timeout_limit = self.fno_timeout_sec if seg in ("NSE_FNO", "BSE_FNO") else self.order_timeout_sec

                    # AMO may remain queued overnight; start its entry timeout only
                    # after the first verified regular-hours status check.
                    timeout_anchor = float(rec.get("created_at") or current_time)
                    if rec.get("is_amo"):
                        activated = float(rec.get("amo_activated_at") or 0.0)
                        if activated <= 0.0:
                            if is_market_open(now=datetime.fromtimestamp(current_time, tz=IST)):
                                activated = current_time
                                rec["amo_activated_at"] = activated
                                changed = True
                            else:
                                timeout_limit = 0.0
                        if activated > 0.0:
                            timeout_anchor = activated

                    if timeout_limit > 0 and (current_time - timeout_anchor) >= timeout_limit:
                        if not rec.get("entry_timeout_elapsed", False):
                            rec["entry_timeout_elapsed"] = True
                            if not rec.get("cancel_origin") or rec.get("cancel_origin") == "LEGACY_UNKNOWN":
                                rec["cancel_origin"] = "BOT_TIMEOUT"
                                rec["cancel_reason"] = f"Remainder timeout ({timeout_limit:g}s) elapsed"
                                rec["retry_eligible"] = (
                                    int(rec.get("retry_count") or 0) < int(rec.get("max_retries") or 1)
                                    and not bool(rec.get("retry_reserved", False))
                                )
                            changed = True

                    if (
                        (rec.get("entry_timeout_elapsed", False) or rec.get("cancel_requested", False))
                        and not rec.get("cancel_acknowledged", False)
                        and rec["state"] in (
                            OrderLifecycleState.PENDING.value,
                            OrderLifecycleState.PART_FILLED.value,
                            OrderLifecycleState.CANCEL_REQUESTED.value,
                        )
                    ):
                        max_c_att = int(rec.get("max_cancel_attempts") or self.max_cancel_attempts)
                        cur_c_att = int(rec.get("cancel_attempts") or 0)
                        if cur_c_att < max_c_att:
                            if current_time >= float(rec.get("next_cancel_retry_at") or 0.0):
                                c_orig = rec.get("cancel_origin") if rec.get("cancel_origin") not in ("", "LEGACY_UNKNOWN") else "BOT_TIMEOUT"
                                c_reas = rec.get("cancel_reason") or f"Remainder timeout ({timeout_limit:g}s) elapsed"
                                logger.info(
                                    f"[Protection] Requesting cancellation for {seg} order {order_id} "
                                    f"(attempt {cur_c_att + 1}/{max_c_att}, origin={c_orig})."
                                )
                                self.request_cancel(order_id, origin=c_orig, reason=c_reas)
                                changed = True
                        else:
                            # CV13-03 Requirement 6: Automatic cancellation attempts exhausted ->
                            # continue monitoring, do NOT mark cancelled or closed, and issue actionable alert.
                            rec["cancel_exhausted"] = True
                            exhaust_msg = (
                                f"Automatic cancellation attempts exhausted ({cur_c_att}/{max_c_att}) for {rec['symbol']} "
                                f"order {order_id} (state={rec['state']}, filled={filled}/{rec['qty']}). "
                                f"Continuing monitoring; manual intervention required."
                            )
                            if gate is not None and hasattr(gate, "halt_new_entries"):
                                gate.halt_new_entries(exhaust_msg)
                            if not rec.get("cancel_exhausted_alerted", False):
                                rec["cancel_exhausted_alerted"] = True
                                logger.critical(f"[Protection] 🚨 {exhaust_msg}")
                                if self.journal_db:
                                    if hasattr(self.journal_db, "record_system_event"):
                                        try:
                                            self.journal_db.record_system_event("CANCEL_RECOVERY_EXHAUSTED", exhaust_msg)
                                        except Exception:
                                            pass
                                    if hasattr(self.journal_db, "enqueue_outbox"):
                                        try:
                                            self.journal_db.enqueue_outbox(
                                                "CRITICAL_CANCEL_EXHAUSTED_ALERT",
                                                {
                                                    "text": f"🚨 [CANCEL_EXHAUSTED] {exhaust_msg}",
                                                    "priority": "HIGH",
                                                    "order_id": order_id,
                                                    "symbol": rec["symbol"],
                                                },
                                            )
                                        except Exception:
                                            pass
                                changed = True

                # 3. CV13-02 & Section 6: Production Automatic Retry after broker-confirmed terminal CANCELLED
                all_fills_protected = (int(rec.get("protected_qty") or 0) >= filled) and not has_unresolved_after

                if (
                    self.auto_retry_enabled
                    and not str(order_id).startswith("DRY-")
                    and rec["state"] == OrderLifecycleState.CANCELLED.value
                    and bool(rec.get("terminal_confirmed", False))
                    and not rec.get("cancel_uncertain", False)
                    and rec.get("cancel_origin") == "BOT_TIMEOUT"
                    and rec.get("retry_eligible") is True
                    and all_fills_protected
                    and (int(rec["qty"]) - filled) > 0
                    and int(rec.get("retry_count") or 0) < int(rec.get("max_retries") or 1)
                    and not rec.get("retry_reserved", False)
                    and not rec.get("auto_retry_attempted", False)
                    and self.journal_db is not None
                ):
                    t_blocked, t_reason = self._is_transition_gate_blocking_new_entries()
                    if t_blocked:
                        rec["retry_eligible"] = False
                        rec["auto_retry_attempted"] = True
                        rec["retry_final_status"] = "BLOCKED_BY_TRANSITION_GATE"
                        rec["retry_error"] = f"Retry blocked during pending transition: {t_reason}"
                        rec["auto_retry_result"] = {"ok": False, "child_order_id": None, "reason": rec["retry_error"]}
                        changed = True
                    else:
                        rec["auto_retry_attempted"] = True
                        max_q_age = float(getattr(getattr(self.broker, "cfg", None), "max_quote_age_sec", 2.0))
                        retry_ok, child_id, retry_msg = self.execute_retry(
                            order_id=order_id,
                            now_utc=current_time,
                            max_quote_age_sec=max_q_age,
                        )
                        rec["auto_retry_result"] = {"ok": retry_ok, "child_order_id": child_id, "reason": retry_msg}
                        changed = True

                # 4. Check terminal finalization of entry phase (open positions remain supervised in terminal_orders)
                entry_only_complete = (route_name == "ENTRY_ONLY_AMO"
                                       and not has_unresolved_after
                                       and not fill_persist_failed
                                       and 0 <= filled <= int(rec["qty"])
                                       and (broker_status != "TRADED" or filled == int(rec["qty"]))
                                       and broker_status in {"TRADED", "CANCELLED", "CANCELED", "REJECTED", "EXPIRED"})
                if is_terminal and (all_fills_protected or entry_only_complete) and notify_ready:
                    if filled == 0:
                        rec["position_state"] = PositionLifecycleState.POSITION_CLOSED.value
                        rec["confirmed_position_open_qty"] = 0
                        logger.info(f"[Protection] {rec['symbol']} order {order_id} terminal ({rec['state']}) with 0 fills; closed.")
                    else:
                        if rec.get("position_state") in (
                            None,
                            "",
                            PositionLifecycleState.ENTRY.value,
                            PositionLifecycleState.POSITION_OPEN.value,
                            PositionLifecycleState.RECONCILIATION_REQUIRED.value,
                        ):
                            rec["position_state"] = (PositionLifecycleState.UNPROTECTED.value if entry_only_complete
                                                     else PositionLifecycleState.PROTECTED.value)
                        rec["confirmed_position_open_qty"] = max(0, filled - int(rec.get("exit_filled_qty") or 0))
                        logger.info(f"[Protection] {rec['symbol']} order {order_id} terminal ({rec['state']}); filled={filled}, protected={rec['protected_qty']}, route={route_name}.")
                    lifecycle_saved = self._sync_position_lifecycle(rec)
                    if entry_only_complete and not lifecycle_saved:
                        rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                        rec["reconciliation_required"] = True
                        rec["persistence_uncertain"] = True
                        if gate is not None and hasattr(gate, "halt_new_entries"):
                            gate.halt_new_entries(f"Entry-only AMO {order_id}: lifecycle persistence failed")
                        changed = True
                        continue
                    if entry_only_complete and lifecycle_saved:
                        rec["persistence_uncertain"] = False
                        rec["reconciliation_required"] = False

                    with self._lock:
                        self.pending.pop(order_id, None)
                        rec["finalized_at"] = current_time
                        self.terminal_orders[order_id] = rec
                    changed = True

            # 5. P0-03, P0-05 & P1-10: Continuous post-entry supervision for open positions
            try:
                changed |= self.supervise_open_positions(current_time=current_time)
            except Exception as sup_err:
                logger.warning(f"[Protection] Open-position supervision error: {sup_err}")

            if changed:
                saved = self._save()
                recovered_ids = set(getattr(self, "_recovered_manual_risk_ids", set()))
                self._recovered_manual_risk_ids = set()
                if recovered_ids and not saved:
                    # Avoid a green in-memory record when JSON or SQLite failed
                    # to persist the same verified position lifecycle.
                    for oid in recovered_ids:
                        rec = self.terminal_orders.get(oid)
                        if not isinstance(rec, dict):
                            continue
                        rec["reconciliation_required"] = True
                        rec["persistence_uncertain"] = True
                        rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                        self._sync_position_lifecycle(rec)
                    self._save()
                    if gate is not None and hasattr(gate, "halt_new_entries"):
                        gate.halt_new_entries("Manual-risk recovery watcher persistence failed")
                elif recovered_ids and saved and gate is not None:
                    # Exactly one bounded *independent* full gate recheck is
                    # queued only after lifecycle AND watcher state persisted.
                    # The existing gate worker serializes probes, enforces
                    # emergency STOP and governor admission, and will not
                    # reopen entries unless every separate invariant passes.
                    schedule = getattr(gate, "_schedule_historical_background_recheck", None)
                    if callable(schedule):
                        try:
                            schedule()
                        except Exception as exc:
                            logger.warning("[Protection] Deferred reconciliation recheck unavailable: %s", type(exc).__name__)

            # B07: Trading watcher NEVER restarts its own systemd service!
            # When all pending orders in watcher have resolved, record transition readiness only;
            # the WebUI / control coordinator process executes the actual deferred apply/restart or stop.
            has_unprotected_or_entry_only_open = any(
                isinstance(r, dict)
                and max(0, int(r.get("filled_qty") or 0) - int(r.get("exit_filled_qty") or 0)) > 0
                and str(r.get("position_state") or "").upper() != PositionLifecycleState.POSITION_CLOSED.value
                and (
                    bool(r.get("entry_only_amo"))
                    or str(r.get("protection_route") or "").upper() == "ENTRY_ONLY_AMO"
                    or bool(r.get("reconciliation_required"))
                    or bool(r.get("persistence_uncertain"))
                    or str(r.get("position_state") or "").upper() in (
                        PositionLifecycleState.UNPROTECTED.value,
                        PositionLifecycleState.RECONCILIATION_REQUIRED.value,
                        PositionLifecycleState.PERSISTENCE_UNCERTAIN.value,
                    )
                )
                for r in self.terminal_orders.values()
            )
            if not self.pending and not has_unprotected_or_entry_only_open:
                try:
                    data_dir = os.path.dirname(os.path.abspath(self.path)) if self.path else "data"
                    from src.engine.config_manager import ConfigChangeTracker
                    tracker = ConfigChangeTracker(data_dir=data_dir)
                    tracker.record_watcher_obligations_resolved(
                        db_path=getattr(self.journal_db, "db_path", None),
                    )
                except Exception as resume_err:
                    logger.warning(f"[Protection] Deferred config readiness record error: {resume_err}")

            return changed

    def _record_unprotected_and_halt(
        self,
        rec: dict,
        new_qty: int,
        sl_trigger: float,
        sl_limit: float,
        target_price: float,
        status_label: str,
        reason: str,
        forever_id: Optional[str] = None,
    ) -> None:
        logger.critical(f"[Protection] ⚠️ {status_label}: {rec['symbol']} ({rec['order_id']}) {new_qty} units — {reason}")
        rec["protection_status"] = status_label
        rec["retry_at"] = self.clock() + RETRY_AFTER_SEC

        if self.journal_db:
            try:
                f_id = forever_id or f"NONE-{rec['order_id']}"
                with self.journal_db._get_conn() as conn:
                    conn.execute(
                        """
                        INSERT OR REPLACE INTO protection_orders (
                            parent_order_id, forever_order_id, symbol, sl_trigger, sl_limit, target_price, quantity, status, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            rec["order_id"],
                            str(f_id),
                            rec["symbol"],
                            float(sl_trigger),
                            float(sl_limit),
                            float(target_price),
                            int(new_qty),
                            status_label,
                            self.clock(),
                        ),
                    )
            except Exception as e:
                logger.warning(f"[Protection] Could not record {status_label} order to journal: {e}")

            if hasattr(self.journal_db, "enqueue_outbox"):
                try:
                    self.journal_db.enqueue_outbox(
                        "CRITICAL_PROTECTION_ALERT",
                        {
                            "text": f"🚨 [{status_label}] {rec['symbol']} order {rec['order_id']} ({new_qty} units): {reason}",
                            "priority": "HIGH",
                            "order_id": rec["order_id"],
                            "symbol": rec["symbol"],
                        },
                    )
                except Exception:
                    pass

        if hasattr(self.broker, "reconciliation_gate") and self.broker.reconciliation_gate:
            self.broker.reconciliation_gate.halt_new_entries(f"{status_label} for {rec['symbol']}: {reason}")

    def _compute_chunk_and_vwap_prices(self, rec: dict, st: dict, filled: int, new_qty: int) -> Tuple[float, float]:
        if self.dry_run and str(rec["order_id"]).startswith("DRY-"):
            raw_dry = rec.get("dry_price")
            if raw_dry is not None and isinstance(raw_dry, (int, float)) and math.isfinite(float(raw_dry)) and float(raw_dry) > 0:
                p = float(raw_dry)
                return p, p
            return 0.0, 0.0

        cum_avg = 0.0
        if hasattr(self.broker, "trades_avg_price"):
            vwap = self.broker.trades_avg_price(rec["order_id"])
            if isinstance(vwap, (int, float)) and not isinstance(vwap, bool) and math.isfinite(float(vwap)) and float(vwap) > 0:
                cum_avg = float(vwap)

        if cum_avg <= 0.0:
            raw_avg = st.get("averageTradedPrice")
            avg_p = float(raw_avg) if (raw_avg is not None and isinstance(raw_avg, (int, float)) and not isinstance(raw_avg, bool)) else 0.0
            if math.isfinite(avg_p) and avg_p > 0.0:
                cum_avg = avg_p

        if not math.isfinite(cum_avg) or cum_avg <= 0.0 or filled <= 0:
            return 0.0, 0.0

        total_val = cum_avg * filled
        prev_val = float(rec.get("protected_value") or 0.0)
        chunk_val = total_val - prev_val
        if new_qty > 0 and chunk_val > 0.0:
            marginal_chunk = round(chunk_val / new_qty, 4)
        else:
            marginal_chunk = cum_avg
        return marginal_chunk, cum_avg

    def _invoke_place_forever_oco_once(
        self,
        corr_id: str,
        security_id: str,
        segment: str,
        prod_type: str,
        levels: ProtectionLevels,
        max_prot_qty: Optional[int],
        inst_tick: float,
    ) -> Tuple[bool, Optional[str], str]:
        """
        Section 7: Invokes `self.broker.place_forever_oco` AT MOST ONCE without catching a
        mutation-call `TypeError` and retrying a second signature.
        """
        fn = self.broker.place_forever_oco
        try:
            sig = inspect.signature(fn)
            params = list(sig.parameters.values())
            has_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params)
            param_names = {p.name for p in params}
        except (ValueError, TypeError):
            has_var_kw = True
            param_names = set()

        if has_var_kw or "tick_size" in param_names:
            return fn(
                correlation_id=corr_id,
                security_id=security_id,
                exchange_segment=segment,
                product_type=prod_type,
                levels=levels,
                max_protectable_qty=max_prot_qty,
                tick_size=inst_tick,
            )
        if "max_protectable_qty" in param_names:
            return fn(
                correlation_id=corr_id,
                security_id=security_id,
                exchange_segment=segment,
                product_type=prod_type,
                levels=levels,
                max_protectable_qty=max_prot_qty,
            )
        if "correlation_id" in param_names:
            return fn(
                correlation_id=corr_id,
                security_id=security_id,
                exchange_segment=segment,
                product_type=prod_type,
                levels=levels,
            )
        return fn(corr_id, security_id, segment, prod_type, levels)

    def _verify_forever_oco_on_broker(
        self,
        oco_id: str,
        rec: dict,
        expected_qty: int,
        levels: ProtectionLevels,
        inst_tick: float,
    ) -> Tuple[bool, str, bool]:
        """
        Safety Correction A & B: Verifies a Forever OCO against the attempt's own `expected_qty`
        and `levels` (`sl_trigger`, `target_price`, `inst_tick`).
        Returns `(is_verified, message, is_terminal_rejected)`.
        """
        forever_book = None
        if hasattr(self.broker, "get_forever_orders"):
            try:
                fb = self.broker.get_forever_orders()
                if isinstance(fb, list):
                    forever_book = fb
            except Exception:
                forever_book = None

        verify_fn = getattr(self.broker, "verify_forever_leg_active", None)
        if callable(verify_fn):
            try:
                sig = inspect.signature(verify_fn)
                pnames = set(sig.parameters.keys())
                has_varkw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
            except (ValueError, TypeError):
                pnames = set()
                has_varkw = True

            if has_varkw or "tick_size" in pnames:
                v_ret = verify_fn(
                    str(oco_id),
                    expected_security_id=str(rec["security_id"]),
                    expected_qty=int(expected_qty),
                    expected_sl_trigger=levels.sl_trigger,
                    expected_target_price=levels.target_price,
                    tick_size=inst_tick,
                )
            elif "expected_security_id" in pnames:
                v_ret = verify_fn(
                    str(oco_id),
                    expected_security_id=str(rec["security_id"]),
                    expected_qty=int(expected_qty),
                    expected_sl_trigger=levels.sl_trigger,
                    expected_target_price=levels.target_price,
                )
            else:
                v_ret = verify_fn(str(oco_id))

            if isinstance(v_ret, tuple) and len(v_ret) == 2 and isinstance(v_ret[0], bool):
                v_ok, v_msg = v_ret
                is_term_rej = any(s in str(v_msg).upper() for s in ("REJECTED", "CANCELLED", "EXPIRED", "TERMINAL"))
                return v_ok, str(v_msg), is_term_rej

        if hasattr(self.broker, "evaluate_forever_oco_protection") and callable(self.broker.evaluate_forever_oco_protection):
            try:
                eval_res = self.broker.evaluate_forever_oco_protection(
                    forever_order_id=str(oco_id),
                    expected_security_id=str(rec["security_id"]),
                    expected_qty=int(expected_qty),
                    expected_sl_trigger=levels.sl_trigger,
                    expected_target_price=levels.target_price,
                    tick_size=inst_tick,
                    expected_segment=str(rec.get("segment") or "NSE_EQ"),
                    expected_product_type=str(rec.get("product_type") or "CNC"),
                    forever_orders_snapshot=forever_book,
                )
                if isinstance(eval_res, ProtectionVerificationResult):
                    return bool(eval_res.is_verified), str(eval_res.reason), bool(eval_res.is_terminal_or_invalid)
            except Exception:
                pass

        if isinstance(forever_book, list) and forever_book:
            matching_rows = [
                r for r in forever_book
                if isinstance(r, dict) and str(r.get("orderId", "")) == str(oco_id)
            ]
            grp = verify_forever_oco_group(
                matching_rows=matching_rows,
                forever_order_id=str(oco_id),
                expected_security_id=str(rec["security_id"]),
                expected_qty=int(expected_qty),
                expected_sl_trigger=levels.sl_trigger,
                expected_target_price=levels.target_price,
                tick_size=inst_tick,
                expected_segment=str(rec.get("segment") or "NSE_EQ"),
                expected_product_type=str(rec.get("product_type") or "CNC"),
            )
            return grp.is_verified, grp.reason, grp.is_terminal_or_invalid

        if not self.require_broker_leg_confirmation and not forever_book:
            return True, "Confirmed by OCO placement ACK", False

        return False, "Broker Forever leg verification unconfirmed", False

    def _verify_super_order_on_broker(
        self,
        order_id: str,
        rec: dict,
        expected_qty: int,
        levels: ProtectionLevels,
        inst_tick: float,
    ) -> Tuple[bool, str, bool]:
        """
        Safety Correction B: Single authoritative Super Order protection verifier.
        Never falls back to accepting two TRADED legs or top-level `stopLossPrice`/`targetPrice` alone.
        """
        verify_super_fn = getattr(self.broker, "verify_super_order_legs_active", None)
        if callable(verify_super_fn):
            try:
                v_ret = verify_super_fn(
                    order_id=str(order_id),
                    expected_security_id=str(rec["security_id"]),
                    expected_qty=int(expected_qty),
                    expected_sl_price=levels.sl_trigger,
                    expected_target_price=levels.target_price,
                    tick_size=inst_tick,
                )
                if isinstance(v_ret, tuple) and len(v_ret) == 2 and isinstance(v_ret[0], bool):
                    v_ok, v_msg = v_ret
                    is_term = any(s in str(v_msg).upper() for s in ("REJECTED", "CANCELLED", "EXPIRED", "TRADED", "CLOSED", "MISMATCH"))
                    return v_ok, str(v_msg), is_term
            except Exception as e:
                return False, f"Super order leg verification exception: {e}", False

        if hasattr(self.broker, "evaluate_super_order_protection") and callable(self.broker.evaluate_super_order_protection):
            try:
                eval_res = self.broker.evaluate_super_order_protection(
                    order_id=str(order_id),
                    expected_security_id=str(rec["security_id"]),
                    expected_qty=int(expected_qty),
                    expected_sl_price=levels.sl_trigger,
                    expected_target_price=levels.target_price,
                    tick_size=inst_tick,
                    expected_segment=str(rec.get("segment") or "NSE_FNO"),
                    expected_product_type=str(rec.get("product_type") or "MARGIN"),
                )
                if isinstance(eval_res, ProtectionVerificationResult):
                    return bool(eval_res.is_verified), str(eval_res.reason), bool(eval_res.is_terminal_or_invalid)
            except Exception:
                pass

        candidate = None
        if hasattr(self.broker, "get_super_orders"):
            try:
                sb = self.broker.get_super_orders()
                if isinstance(sb, list):
                    for row in sb:
                        if isinstance(row, dict) and str(row.get("orderId", "")) == str(order_id):
                            candidate = row
                            break
            except Exception:
                candidate = None

        if candidate is None and hasattr(self.broker, "order_status"):
            try:
                st_after = self.broker.order_status(order_id)
                if isinstance(st_after, dict):
                    candidate = st_after
            except Exception:
                candidate = None

        ver = verify_super_order_record(
            candidate=candidate,
            order_id=str(order_id),
            expected_security_id=str(rec["security_id"]),
            expected_qty=int(expected_qty),
            expected_sl_price=levels.sl_trigger,
            expected_target_price=levels.target_price,
            tick_size=inst_tick,
            expected_segment=str(rec.get("segment") or "NSE_FNO"),
            expected_product_type=str(rec.get("product_type") or "MARGIN"),
        )
        return ver.is_verified, ver.reason, ver.is_terminal_or_invalid

    def _record_confirmed_protection(
        self,
        rec: dict,
        forever_or_super_id: str,
        confirmed_qty: int,
        executed_chunk_price: float,
        cum_vwap: float,
        filled: int,
        levels: ProtectionLevels,
        leg_status_label: str,
        is_super: bool,
        attempt_id: Optional[str] = None,
    ) -> None:
        if is_super:
            rec["protected_qty"] = int(confirmed_qty)
            rec["protected_value"] = cum_vwap * int(confirmed_qty)
        else:
            rec["protected_qty"] = int(rec.get("protected_qty") or 0) + int(confirmed_qty)
            rec["protected_value"] = float(rec.get("protected_value") or 0.0) + (float(executed_chunk_price) * int(confirmed_qty))

        rec["protection_status"] = leg_status_label
        rec["confirmed_sl_price"] = float(levels.sl_trigger)
        rec["confirmed_target_price"] = float(levels.target_price)
        rec["buy_vwap"] = float(cum_vwap if cum_vwap > 0 else executed_chunk_price)
        rec["confirmed_position_open_qty"] = max(0, int(rec["protected_qty"]) - int(rec.get("exit_filled_qty") or 0))
        rec["position_state"] = PositionLifecycleState.PROTECTED.value
        rec["retry_at"] = 0.0
        confirmed_ids = rec.get("confirmed_protection_ids")
        if not isinstance(confirmed_ids, list):
            confirmed_ids = []
        if str(forever_or_super_id) not in confirmed_ids:
            confirmed_ids.append(str(forever_or_super_id))
        rec["confirmed_protection_ids"] = confirmed_ids
        try:
            GLOBAL_LATENCY_MONITOR.record_protection_verified(rec["order_id"])
            if rec.get("correlation_id"):
                GLOBAL_LATENCY_MONITOR.record_protection_verified(str(rec["correlation_id"]))
        except Exception:
            pass

        if self.journal_db:
            if attempt_id and hasattr(self.journal_db, "update_protection_attempt"):
                try:
                    self.journal_db.update_protection_attempt(
                        attempt_id,
                        state="CONFIRMED",
                        broker_order_id=str(forever_or_super_id),
                        now=self.clock(),
                    )
                except Exception as e:
                    logger.warning(f"[Protection] Could not update protection_attempt {attempt_id} to CONFIRMED: {e}")

            try:
                if rec["protected_qty"] >= filled and hasattr(self.journal_db, "resolve_unprotected_orders"):
                    self.journal_db.resolve_unprotected_orders(rec["order_id"])
                with self.journal_db._get_conn() as conn:
                    conn.execute(
                        """
                        INSERT OR REPLACE INTO protection_orders (
                            parent_order_id, forever_order_id, symbol, sl_trigger, sl_limit, target_price, quantity, status, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            rec["order_id"],
                            str(forever_or_super_id),
                            rec["symbol"],
                            levels.sl_trigger,
                            levels.sl_limit,
                            levels.target_price,
                            int(confirmed_qty),
                            leg_status_label,
                            self.clock(),
                        ),
                    )
            except Exception as e:
                logger.warning(f"[Protection] Could not record protection order to journal: {e}")

        self._sync_position_lifecycle(rec)
        logger.info(
            f"[Protection] ✅ {rec['symbol']}: {confirmed_qty} units protected @ {executed_chunk_price} → "
            f"SL {levels.sl_trigger} / Target {levels.target_price} ({leg_status_label}, ID: {forever_or_super_id})."
        )

    def _reconcile_existing_forever_attempt(
        self,
        rec: dict,
        pending_oco: dict,
        st: dict,
        filled: int,
    ) -> Tuple[bool, bool]:
        attempt_id = str(pending_oco.get("attempt_id") or pending_oco.get("correlation_id") or "")
        existing_corr = str(pending_oco.get("correlation_id") or "")
        existing_oco_id = pending_oco.get("oco_id")
        attempt_qty = int(pending_oco.get("qty") or 0)
        attempt_exec_price = float(pending_oco.get("executed_price") or 0.0)
        attempt_tick = float(pending_oco.get("tick_size") or rec.get("tick_size") or TICK)

        if attempt_exec_price <= 0.0:
            marginal_p, _ = self._compute_chunk_and_vwap_prices(rec, st, filled, max(1, attempt_qty))
            attempt_exec_price = marginal_p

        attempt_levels = ProtectionLevels(
            executed_price=attempt_exec_price if attempt_exec_price > 0 else 1.0,
            sl_trigger=float(pending_oco.get("sl_trigger") or 0.0),
            sl_limit=float(pending_oco.get("sl_limit") or 0.0),
            target_price=float(pending_oco.get("target_price") or 0.0),
            quantity=attempt_qty,
            target_trigger=float(pending_oco.get("target_price") or 0.0),
        )

        # 1. If broker order ID is missing (e.g., crash during SUBMITTING or timeout UNKNOWN), look up by correlationId
        if not existing_oco_id and existing_corr:
            if hasattr(self.broker, "get_forever_orders"):
                try:
                    fb = self.broker.get_forever_orders()
                    if isinstance(fb, list):
                        for fb_row in fb:
                            if isinstance(fb_row, dict) and str(fb_row.get("correlationId") or "") == existing_corr:
                                found_id = str(fb_row.get("orderId") or "").strip()
                                if found_id:
                                    existing_oco_id = found_id
                                    pending_oco["oco_id"] = existing_oco_id
                                    break
                except Exception:
                    pass

            if not existing_oco_id and hasattr(self.broker, "get_order_by_correlation_id"):
                try:
                    corr_row = self.broker.get_order_by_correlation_id(existing_corr)
                    if isinstance(corr_row, dict) and corr_row.get("orderId"):
                        existing_oco_id = str(corr_row["orderId"]).strip()
                        pending_oco["oco_id"] = existing_oco_id
                except Exception:
                    pass

            if existing_oco_id and self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                try:
                    self.journal_db.update_protection_attempt(
                        attempt_id or existing_corr,
                        state="ACKED_UNVERIFIED",
                        broker_order_id=existing_oco_id,
                        now=self.clock(),
                    )
                except Exception:
                    pass

        # 2. If we have a broker order ID, verify it against the attempt's stored quantity and levels
        if existing_oco_id:
            v_ok, v_msg, is_term_rej = self._verify_forever_oco_on_broker(
                str(existing_oco_id),
                rec,
                attempt_qty,
                attempt_levels,
                attempt_tick,
            )
            if v_ok:
                leg_label = "ACTIVE" if v_msg == "Confirmed by OCO placement ACK" else "ACTIVE_CONFIRMED"
                _, cum_vwap = self._compute_chunk_and_vwap_prices(rec, st, filled, attempt_qty)
                rec["pending_oco"] = None
                self._record_confirmed_protection(
                    rec=rec,
                    forever_or_super_id=str(existing_oco_id),
                    confirmed_qty=attempt_qty,
                    executed_chunk_price=attempt_exec_price,
                    cum_vwap=cum_vwap,
                    filled=filled,
                    levels=attempt_levels,
                    leg_status_label=leg_label,
                    is_super=False,
                    attempt_id=attempt_id or existing_corr,
                )
                self._save()
                return True, True

            if is_term_rej:
                if self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                    try:
                        self.journal_db.update_protection_attempt(
                            attempt_id or existing_corr,
                            state="REJECTED",
                            broker_order_id=str(existing_oco_id),
                            error_msg=v_msg,
                            now=self.clock(),
                        )
                    except Exception:
                        pass
                rec["pending_oco"] = None
                self._record_unprotected_and_halt(
                    rec=rec,
                    new_qty=attempt_qty,
                    sl_trigger=attempt_levels.sl_trigger,
                    sl_limit=attempt_levels.sl_limit,
                    target_price=attempt_levels.target_price,
                    status_label="UNPROTECTED",
                    reason=f"Forever OCO {existing_oco_id} terminally rejected/cancelled on broker: {v_msg}",
                    forever_id=str(existing_oco_id),
                )
                self._save()
                return True, False

            logger.error(
                f"[Protection] 🚨 Forever OCO {existing_oco_id} still awaiting broker leg verification: {v_msg} (skipping duplicate POST)"
            )
            self._record_unprotected_and_halt(
                rec=rec,
                new_qty=attempt_qty,
                sl_trigger=attempt_levels.sl_trigger,
                sl_limit=attempt_levels.sl_limit,
                target_price=attempt_levels.target_price,
                status_label="UNPROTECTED",
                reason=f"Broker protection unconfirmed or delayed for {attempt_qty} units @ {attempt_exec_price}: {v_msg}",
                forever_id=str(existing_oco_id),
            )
            self._save()
            return False, False

        # 3. No broker order ID found yet for a restored SUBMITTING or UNKNOWN attempt:
        state_label = str(pending_oco.get("state") or "SUBMITTING")
        self._record_unprotected_and_halt(
            rec=rec,
            new_qty=attempt_qty,
            sl_trigger=attempt_levels.sl_trigger,
            sl_limit=attempt_levels.sl_limit,
            target_price=attempt_levels.target_price,
            status_label="UNPROTECTED",
            reason=(
                f"Prior protection attempt ({existing_corr}, state={state_label}) has unresolved broker outcome; "
                f"treating as potentially accepted and blocking duplicate submission"
            ),
            forever_id=f"UNVERIFIED-{existing_corr}",
        )
        self._save()
        return False, False

    def _reconcile_existing_super_attempt(
        self,
        rec: dict,
        pending_super: dict,
        st: dict,
        filled: int,
    ) -> Tuple[bool, bool]:
        """
        CV13-01: Reconciles an existing unresolved SUPER_ORDER protection attempt against its own
        stored expected quantity, prices, and broker identity before creating any new attempt.
        - If readback confirms the expected protection, marks the attempt CONFIRMED and updates
          watcher coverage (`protected_qty`, `protected_value`) consistently.
        - If evidence is unavailable or outcome remains uncertain, retains the unresolved attempt,
          keeps fresh entries blocked, and does NOT repeat the modification.
        """
        attempt_id = str(pending_super.get("attempt_id") or pending_super.get("correlation_id") or "")
        existing_corr = str(pending_super.get("correlation_id") or "")
        super_oid = str(pending_super.get("oco_id") or pending_super.get("broker_order_id") or rec["order_id"])
        attempt_qty = int(pending_super.get("qty") or pending_super.get("quantity") or 0)
        attempt_exec_price = float(pending_super.get("executed_price") or 0.0)
        attempt_tick = float(pending_super.get("tick_size") or rec.get("tick_size") or TICK)

        if attempt_exec_price <= 0.0:
            _, cum_v = self._compute_chunk_and_vwap_prices(rec, st, max(filled, attempt_qty), max(1, attempt_qty))
            attempt_exec_price = cum_v

        attempt_levels = ProtectionLevels(
            executed_price=attempt_exec_price if attempt_exec_price > 0 else 1.0,
            sl_trigger=float(pending_super.get("sl_trigger") or 0.0),
            sl_limit=float(pending_super.get("sl_limit") or 0.0),
            target_price=float(pending_super.get("target_price") or 0.0),
            quantity=attempt_qty,
            target_trigger=float(pending_super.get("target_price") or 0.0),
        )

        sv_ok, sv_msg, _ = self._verify_super_order_on_broker(
            order_id=super_oid,
            rec=rec,
            expected_qty=attempt_qty,
            levels=attempt_levels,
            inst_tick=attempt_tick,
        )
        if sv_ok:
            rec["pending_oco"] = None
            rec["reanchor_status"] = "CONFIRMED"
            self._record_confirmed_protection(
                rec=rec,
                forever_or_super_id=f"SUPER-{super_oid}-{attempt_qty}",
                confirmed_qty=attempt_qty,
                executed_chunk_price=attempt_exec_price,
                cum_vwap=attempt_exec_price,
                filled=filled,
                levels=attempt_levels,
                leg_status_label="ACTIVE_CONFIRMED",
                is_super=True,
                attempt_id=attempt_id or existing_corr,
            )
            self._save()
            return True, True

        # Retain the unresolved attempt, keep fresh entries blocked, and do NOT repeat modification
        rec["reanchor_status"] = "UNVERIFIED"
        self._record_unprotected_and_halt(
            rec=rec,
            new_qty=attempt_qty,
            sl_trigger=attempt_levels.sl_trigger,
            sl_limit=attempt_levels.sl_limit,
            target_price=attempt_levels.target_price,
            status_label="UNPROTECTED",
            reason=f"Super Order {super_oid} attempt {attempt_id} awaiting active-leg verification: {sv_msg}",
            forever_id=f"UNVERIFIED-SUPER-{super_oid}",
        )
        self._save()
        return False, False

    def _protect(self, rec: dict, st: dict, filled: int, new_qty: int) -> bool:
        with self._lock:
            # Defense in depth: an entry-only AMO is deliberately unmanaged;
            # do not convert it to an unsupported MARGIN Forever OCO.
            if rec.get("entry_only_amo"):
                return False
            route_name = self._resolve_protection_route(rec)
            if route_name == ProtectionRoute.UNKNOWN.value:
                self._record_unprotected_and_halt(
                    rec=rec,
                    new_qty=max(1, new_qty),
                    sl_trigger=0.0,
                    sl_limit=0.0,
                    target_price=0.0,
                    status_label="UNPROTECTED",
                    reason=f"Ambiguous or UNKNOWN protection_route for {rec.get('symbol')} ({rec.get('order_id')}); refusing to guess protection route",
                )
                return True
            is_super = (route_name == ProtectionRoute.SUPER_ORDER.value)

            # Step 1: Before creating an attempt, find and reconcile any existing unresolved attempt for the same parent and route (CV13-01)
            existing_unresolved = self._find_unresolved_attempt(rec, route_name)
            if existing_unresolved is not None:
                if is_super:
                    resolved_cleared, confirmed_ok = self._reconcile_existing_super_attempt(rec, existing_unresolved, st, filled)
                else:
                    resolved_cleared, confirmed_ok = self._reconcile_existing_forever_attempt(rec, existing_unresolved, st, filled)
                if not resolved_cleared or not confirmed_ok:
                    return True
                # Handle any additional fills separately after reconciling the earlier attempt
                new_qty = filled - int(rec.get("protected_qty") or 0)
                if new_qty <= 0:
                    return True

            if new_qty <= 0:
                return False

            marginal_chunk, cum_vwap = self._compute_chunk_and_vwap_prices(rec, st, filled, new_qty)
            executed_chunk = cum_vwap if is_super else marginal_chunk

            if not math.isfinite(executed_chunk) or executed_chunk <= 0.0:
                self._record_unprotected_and_halt(
                    rec=rec,
                    new_qty=new_qty,
                    sl_trigger=0.0,
                    sl_limit=0.0,
                    target_price=0.0,
                    status_label="UNPROTECTED",
                    reason="Missing broker-confirmed executed fill price (refusing to fabricate fallback execution price)",
                )
                return True

            inst_tick = float(rec.get("tick_size") or TICK)
            target_qty = filled if is_super else new_qty
            # Legacy records from before this upgrade retain their original
            # shared protection defaults; new orders use the persisted snapshot.
            sl_pct = float(rec.get("protection_sl_pct", self.sl_pct))
            target_pct = float(rec.get("protection_target_pct", self.target_pct))
            levels = calculate_protection_levels(
                executed_price=executed_chunk,
                quantity=target_qty,
                sl_pct=sl_pct,
                target_pct=target_pct,
                sl_limit_buffer_pct=self.sl_limit_buffer_pct,
                tick_size=inst_tick,
            )

            segment = rec["segment"]
            prod_type = rec.get("product_type", "CNC")

            if self.dry_run and str(rec["order_id"]).startswith("DRY-"):
                logger.info(
                    f"[DRY RUN] Protected {new_qty}x {rec['symbol']} @ {executed_chunk}: "
                    f"Target {levels.target_price} (+{target_pct:g}%), "
                    f"SL Trigger {levels.sl_trigger} (-{sl_pct:g}%, Limit {levels.sl_limit})"
                )
                self._record_confirmed_protection(
                    rec=rec,
                    forever_or_super_id="DRY-OCO-SUCCESS",
                    confirmed_qty=target_qty,
                    executed_chunk_price=executed_chunk,
                    cum_vwap=cum_vwap,
                    filled=filled,
                    levels=levels,
                    leg_status_label="ACTIVE",
                    is_super=is_super,
                )
                return True

            # Step 2: Create unique durable protection attempt and commit strictly BEFORE broker mutation
            uncovered_from = int(rec.get("protected_qty") or 0)
            corr_prefix = "SUPP" if is_super else "OCO"
            corr_id = generate_correlation_id(corr_prefix, rec["symbol"], self.clock())
            attempt_id = generate_correlation_id("PATM", rec["symbol"], self.clock())
            acct_id = str(getattr(getattr(self.broker, "cfg", None), "dhan_client_id", "") or getattr(self.journal_db, "account_id", "") or "")

            attempt_record = {
                "attempt_id": attempt_id,
                "parent_order_id": rec["order_id"],
                "root_order_id": rec.get("root_order_id") or rec["order_id"],
                "account_id": acct_id,
                "symbol": rec["symbol"],
                "trading_symbol": rec.get("trading_symbol") or rec["symbol"],
                "security_id": str(rec["security_id"]),
                "exchange_segment": segment,
                "product_type": prod_type,
                "route": route_name,
                "uncovered_from_qty": uncovered_from,
                "qty": target_qty,
                "executed_price": executed_chunk,
                "sl_trigger": levels.sl_trigger,
                "sl_limit": levels.sl_limit,
                "target_price": levels.target_price,
                "tick_size": inst_tick,
                "correlation_id": corr_id,
                "oco_id": rec["order_id"] if is_super else None,
                "state": "SUBMITTING",
            }
            rec["pending_oco"] = attempt_record

            try:
                if self.journal_db and hasattr(self.journal_db, "create_protection_attempt"):
                    self.journal_db.create_protection_attempt(
                        attempt_id=attempt_id,
                        parent_order_id=rec["order_id"],
                        root_order_id=rec.get("root_order_id") or rec["order_id"],
                        account_id=acct_id,
                        symbol=rec["symbol"],
                        trading_symbol=rec.get("trading_symbol") or rec["symbol"],
                        security_id=str(rec["security_id"]),
                        exchange_segment=segment,
                        product_type=prod_type,
                        route=route_name,
                        uncovered_from_qty=uncovered_from,
                        quantity=target_qty,
                        executed_price=executed_chunk,
                        sl_trigger=levels.sl_trigger,
                        sl_limit=levels.sl_limit,
                        target_price=levels.target_price,
                        tick_size=inst_tick,
                        correlation_id=corr_id,
                        broker_order_id=rec["order_id"] if is_super else None,
                        state="SUBMITTING",
                        now=self.clock(),
                    )
                self._save_strict()
            except Exception as persist_err:
                rec["pending_oco"] = None
                logger.critical(
                    f"[Protection] Pre-POST persistence failed for {rec['symbol']} ({rec['order_id']}): {persist_err}. "
                    f"Aborting protective-order submission fail-closed."
                )
                if hasattr(self.broker, "reconciliation_gate") and self.broker.reconciliation_gate:
                    self.broker.reconciliation_gate.halt_new_entries(
                        f"Protection persistence failure for {rec['symbol']}: {persist_err}"
                    )
                return False

            # Step 3A: Super Order protection re-anchoring with per-leg persistence and authoritative verification (P0-04)
            if is_super and hasattr(self.broker, "modify_super_order_protection"):
                try:
                    ok_mod, mod_msg = self.broker.modify_super_order_protection(
                        order_id=rec["order_id"],
                        stop_loss_price=levels.sl_trigger,
                        target_price=levels.target_price,
                    )
                except Exception as mod_exc:
                    ok_mod, mod_msg = False, f"HTTP exception modifying super order: {mod_exc}"

                leg_mod_map = {}
                raw_leg_map = getattr(self.broker, "last_super_leg_mod_results", None)
                if isinstance(raw_leg_map, dict):
                    leg_mod_map = raw_leg_map.get(str(rec["order_id"]), {}) or {}
                t_leg_st = str((leg_mod_map.get("TARGET_LEG") or {}).get("state") or ("ACKED" if ok_mod else "FAILED"))
                sl_leg_st = str((leg_mod_map.get("STOP_LOSS_LEG") or {}).get("state") or ("ACKED" if ok_mod else "FAILED"))
                rec["target_leg_mod_state"] = t_leg_st
                rec["sl_leg_mod_state"] = sl_leg_st
                if isinstance(rec.get("pending_oco"), dict):
                    rec["pending_oco"]["target_leg_state"] = t_leg_st
                    rec["pending_oco"]["sl_leg_state"] = sl_leg_st

                if ok_mod:
                    sv_ok, sv_msg, _ = self._verify_super_order_on_broker(
                        order_id=rec["order_id"],
                        rec=rec,
                        expected_qty=filled,
                        levels=levels,
                        inst_tick=inst_tick,
                    )
                    if sv_ok:
                        rec["pending_oco"] = None
                        rec["reanchor_status"] = "CONFIRMED"
                        rec["target_leg_mod_state"] = "CONFIRMED"
                        rec["sl_leg_mod_state"] = "CONFIRMED"
                        if self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                            try:
                                self.journal_db.update_protection_attempt(
                                    attempt_id,
                                    state="CONFIRMED",
                                    broker_order_id=rec["order_id"],
                                    target_leg_state="CONFIRMED",
                                    sl_leg_state="CONFIRMED",
                                    now=self.clock(),
                                )
                            except Exception:
                                pass
                        self._record_confirmed_protection(
                            rec=rec,
                            forever_or_super_id=f"SUPER-{rec['order_id']}-{filled}",
                            confirmed_qty=filled,
                            executed_chunk_price=executed_chunk,
                            cum_vwap=cum_vwap,
                            filled=filled,
                            levels=levels,
                            leg_status_label="ACTIVE_CONFIRMED",
                            is_super=True,
                            attempt_id=attempt_id,
                        )
                        return True
                    else:
                        rec["reanchor_status"] = "UNVERIFIED"
                        rec["pending_oco"]["state"] = "ACKED_UNVERIFIED"
                        rec["pending_oco"]["oco_id"] = rec["order_id"]
                        if self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                            try:
                                self.journal_db.update_protection_attempt(
                                    attempt_id,
                                    state="ACKED_UNVERIFIED",
                                    broker_order_id=rec["order_id"],
                                    error_msg=sv_msg,
                                    target_leg_state=t_leg_st,
                                    sl_leg_state=sl_leg_st,
                                    now=self.clock(),
                                )
                            except Exception:
                                pass
                        self._record_unprotected_and_halt(
                            rec=rec,
                            new_qty=new_qty,
                            sl_trigger=levels.sl_trigger,
                            sl_limit=levels.sl_limit,
                            target_price=levels.target_price,
                            status_label="UNPROTECTED",
                            reason=f"Super Order {rec['order_id']} reanchoring lacks authoritative active-leg verification: {sv_msg}",
                            forever_id=f"UNVERIFIED-SUPER-{rec['order_id']}",
                        )
                        self._save()
                        return True
                else:
                    rec["reanchor_status"] = "FAILED"
                    ambig = _is_ambiguous_message(mod_msg) or (t_leg_st == "ACKED" and sl_leg_st != "ACKED")
                    if ambig:
                        rec["pending_oco"]["state"] = "UNKNOWN"
                        rec["pending_oco"]["oco_id"] = rec["order_id"]
                    else:
                        rec["pending_oco"] = None
                    if self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                        try:
                            self.journal_db.update_protection_attempt(
                                attempt_id,
                                state="UNKNOWN" if ambig else "REJECTED",
                                broker_order_id=rec["order_id"],
                                error_msg=mod_msg,
                                target_leg_state=t_leg_st,
                                sl_leg_state=sl_leg_st,
                                now=self.clock(),
                            )
                        except Exception:
                            pass
                    self._record_unprotected_and_halt(
                        rec=rec,
                        new_qty=new_qty,
                        sl_trigger=levels.sl_trigger,
                        sl_limit=levels.sl_limit,
                        target_price=levels.target_price,
                        status_label="UNPROTECTED",
                        reason=f"Super Order {rec['order_id']} leg reanchoring failed: {mod_msg}",
                        forever_id=f"FAILED-SUPER-{rec['order_id']}",
                    )
                    self._save()
                    return True

            # Step 3B: Forever OCO for Cash Delivery (CNC/MTF)
            if hasattr(self.broker, "place_forever_oco"):
                max_prot_qty: Optional[int] = filled - int(rec.get("protected_qty") or 0)
                if hasattr(self.broker, "get_positions"):
                    try:
                        pos_list = self.broker.get_positions()
                        if isinstance(pos_list, list) and pos_list:
                            for p in pos_list:
                                if isinstance(p, dict) and str(p.get("securityId") or "") == str(rec["security_id"]):
                                    raw_nq = p.get("netQty")
                                    if raw_nq is not None and not isinstance(raw_nq, bool):
                                        net_q = int(raw_nq)
                                        if net_q > 0:
                                            max_prot_qty = min(max_prot_qty, net_q)
                    except Exception:
                        pass

                try:
                    oco_ret = self._invoke_place_forever_oco_once(
                        corr_id=corr_id,
                        security_id=rec["security_id"],
                        segment=segment,
                        prod_type=prod_type,
                        levels=levels,
                        max_prot_qty=max_prot_qty,
                        inst_tick=inst_tick,
                    )
                except Exception as post_exc:
                    logger.critical(
                        f"[Protection] Exception during place_forever_oco for {rec['symbol']} ({corr_id}): {post_exc}. "
                        f"Preserving durable attempt for broker reconciliation."
                    )
                    self._record_unprotected_and_halt(
                        rec=rec,
                        new_qty=new_qty,
                        sl_trigger=levels.sl_trigger,
                        sl_limit=levels.sl_limit,
                        target_price=levels.target_price,
                        status_label="UNPROTECTED",
                        reason=f"Exception during Forever OCO submission ({corr_id}): {post_exc}",
                        forever_id=f"SUBMITTING-{corr_id}",
                    )
                    self._save()
                    return True

                success, oco_id, msg = oco_ret

                if success and oco_id:
                    str_oco_id = str(oco_id)
                    rec["pending_oco"]["oco_id"] = str_oco_id
                    rec["pending_oco"]["state"] = "ACKED_UNVERIFIED"
                    if self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                        try:
                            self.journal_db.update_protection_attempt(
                                attempt_id,
                                state="ACKED_UNVERIFIED",
                                broker_order_id=str_oco_id,
                                response_payload={"orderId": str_oco_id, "message": msg},
                                now=self.clock(),
                            )
                        except Exception:
                            pass
                    self._save()

                    v_ok, v_msg, is_term_rej = self._verify_forever_oco_on_broker(
                        str_oco_id,
                        rec,
                        new_qty,
                        levels,
                        inst_tick,
                    )
                    if v_ok:
                        leg_status_label = "ACTIVE" if v_msg == "Confirmed by OCO placement ACK" else "ACTIVE_CONFIRMED"
                        rec["pending_oco"] = None
                        self._record_confirmed_protection(
                            rec=rec,
                            forever_or_super_id=str_oco_id,
                            confirmed_qty=new_qty,
                            executed_chunk_price=executed_chunk,
                            cum_vwap=cum_vwap,
                            filled=filled,
                            levels=levels,
                            leg_status_label=leg_status_label,
                            is_super=False,
                            attempt_id=attempt_id,
                        )
                        return True
                    else:
                        if is_term_rej:
                            rec["pending_oco"] = None
                            if self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                                try:
                                    self.journal_db.update_protection_attempt(
                                        attempt_id,
                                        state="REJECTED",
                                        broker_order_id=str_oco_id,
                                        error_msg=v_msg,
                                        now=self.clock(),
                                    )
                                except Exception:
                                    pass
                        logger.error(
                            f"[Protection] 🚨 Forever OCO {str_oco_id} ACK received but failed broker leg verification: {v_msg}"
                        )
                        self._record_unprotected_and_halt(
                            rec=rec,
                            new_qty=new_qty,
                            sl_trigger=levels.sl_trigger,
                            sl_limit=levels.sl_limit,
                            target_price=levels.target_price,
                            status_label="UNPROTECTED",
                            reason=f"Broker protection unconfirmed or rejected for {new_qty} units @ {executed_chunk}: {v_msg}",
                            forever_id=str_oco_id,
                        )
                        return True
                else:
                    if _is_ambiguous_message(msg) or (success and not oco_id):
                        rec["pending_oco"]["state"] = "UNKNOWN"
                        if self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                            try:
                                self.journal_db.update_protection_attempt(
                                    attempt_id,
                                    state="UNKNOWN",
                                    error_msg=str(msg),
                                    now=self.clock(),
                                )
                            except Exception:
                                pass
                    else:
                        rec["pending_oco"] = None
                        if self.journal_db and hasattr(self.journal_db, "update_protection_attempt"):
                            try:
                                self.journal_db.update_protection_attempt(
                                    attempt_id,
                                    state="REJECTED",
                                    error_msg=str(msg),
                                    now=self.clock(),
                                )
                            except Exception:
                                pass
                    logger.error(f"[Protection] 🚨 Broker protection rejected/ambiguous for {rec['symbol']}: {msg}")
                    self._record_unprotected_and_halt(
                        rec=rec,
                        new_qty=new_qty,
                        sl_trigger=levels.sl_trigger,
                        sl_limit=levels.sl_limit,
                        target_price=levels.target_price,
                        status_label="UNPROTECTED",
                        reason=f"Broker protection unconfirmed or rejected for {new_qty} units @ {executed_chunk}: {msg}",
                        forever_id=f"UNVERIFIED-{corr_id}" if rec.get("pending_oco") else None,
                    )
                    return True

            rec["pending_oco"] = None
            self._record_unprotected_and_halt(
                rec=rec,
                new_qty=new_qty,
                sl_trigger=levels.sl_trigger,
                sl_limit=levels.sl_limit,
                target_price=levels.target_price,
                status_label="UNPROTECTED",
                reason=f"No supported protection route available for {rec['symbol']}",
            )
            return True

    def _is_transition_gate_blocking_new_entries(self) -> Tuple[bool, str]:
        """B05: Checks whether a pending LIVE -> TEST transition or Owner Stop blocks new replacement retry entries."""
        try:
            data_dir = os.path.dirname(os.path.abspath(self.path)) if self.path else "data"
            cfg_dir = getattr(getattr(self.broker, "cfg", None), "data_dir", None)
            if cfg_dir and os.path.exists(str(cfg_dir)):
                data_dir = str(cfg_dir)
            from src.engine.config_manager import ConfigChangeTracker
            return ConfigChangeTracker(data_dir=data_dir).is_live_entry_blocked_by_transition()
        except Exception as e:
            return True, f"Could not verify transition gate for retry (failing closed): {e}"

    def _evaluate_retry_locked(
        self,
        order_id: str,
        current_market_price: float,
        quote_timestamp: Optional[float] = None,
        max_quote_age_sec: float = 2.0,
        now_utc: Optional[float] = None,
        reserve_slot: bool = True,
        require_quote_timestamp: bool = False,
    ) -> Tuple[bool, int, str]:
        rec = self.pending.get(order_id) or self.terminal_orders.get(order_id)
        if not rec:
            return False, 0, f"Order {order_id} not in tracking"
        if rec.get("entry_only_amo"):
            rec["retry_eligible"] = False
            return False, 0, "F&O entry-only AMO automatic retry is disabled"

        t_blocked, t_reason = self._is_transition_gate_blocking_new_entries()
        if t_blocked:
            rec["retry_eligible"] = False
            rec["retry_final_status"] = "BLOCKED_BY_TRANSITION_GATE"
            rec["retry_error"] = f"Retry blocked by active transition gate: {t_reason}"
            return False, 0, f"Retry prohibited during pending transition: {t_reason}"

        if rec.get("cancel_uncertain", False):
            return False, 0, f"Cancellation for order {order_id} is uncertain; cannot retry until confirmed terminal"

        root_id = str(rec.get("root_order_id") or order_id)
        if self.journal_db and hasattr(self.journal_db, "has_retry_reservation"):
            try:
                r1 = self.journal_db.has_retry_reservation(root_id)
                r2 = self.journal_db.has_retry_reservation(order_id)
                if (r1 is True) or (r2 is True):
                    return False, 0, f"Retry limit reached (durable reservation already exists for {root_id})"
            except Exception:
                pass

        if rec["retry_count"] >= rec["max_retries"] or rec.get("retry_reserved", False):
            return False, 0, f"Retry limit reached ({rec['retry_count']}/{rec['max_retries']})"

        c_orig = str(rec.get("cancel_origin") or "").strip().upper()
        if rec.get("retry_eligible") is False or (c_orig and c_orig in PROHIBITED_CANCEL_ORIGINS):
            return (
                False,
                0,
                f"Retry prohibited: cancellation origin '{c_orig or 'NON_ELIGIBLE'}' is not eligible for replacement BUY",
            )

        if rec["state"] not in (OrderLifecycleState.CANCELLED.value, OrderLifecycleState.EXPIRED.value):
            return False, 0, f"Order is in non-terminal state ({rec['state']}); cannot retry until cancelled"

        if (
            current_market_price is None
            or isinstance(current_market_price, bool)
            or not isinstance(current_market_price, (int, float))
            or not math.isfinite(float(current_market_price))
            or float(current_market_price) <= 0.0
        ):
            return False, 0, "Retry rejected: missing or invalid current market quote"

        if require_quote_timestamp and quote_timestamp is None:
            return False, 0, "Retry rejected: missing source quote timestamp for current_market_price"

        if quote_timestamp is not None:
            if isinstance(quote_timestamp, bool) or not isinstance(quote_timestamp, (int, float)) or not math.isfinite(float(quote_timestamp)) or float(quote_timestamp) <= 0.0:
                return False, 0, f"Retry rejected: invalid quote timestamp ({quote_timestamp!r})"
            eval_now = float(now_utc) if now_utc is not None else self.clock()
            q_age = round(eval_now - float(quote_timestamp), 6)
            if q_age < 0.0:
                return False, 0, f"Retry rejected: future quote timestamp (age={q_age:.2f}s < 0.0s)"
            if q_age > max_quote_age_sec:
                return False, 0, f"Retry rejected: stale quote timestamp (age={q_age:.2f}s, max={max_quote_age_sec:.2f}s)"

        orig_price = float(rec.get("original_market_price") or 0.0)
        if not math.isfinite(orig_price) or orig_price <= 0.0:
            return False, 0, "Retry rejected: missing original market reference price"

        filled = int(rec.get("filled_qty") or 0)
        if filled == 0 and int(rec.get("protected_qty") or 0) > 0:
            filled = int(rec["protected_qty"])
        remaining_qty = int(rec["qty"]) - filled
        if remaining_qty <= 0:
            return False, 0, "No remaining unfulfilled quantity to retry"

        price_move_pct = round((abs(float(current_market_price) - orig_price) / orig_price) * 100.0, 6)
        if price_move_pct >= 1.0:
            return (
                False,
                0,
                f"Price move {price_move_pct:.2f}% is >= 1.00% threshold ceiling; retry rejected",
            )

        if reserve_slot:
            rec["retry_count"] += 1
            rec["retry_reserved"] = True
        return True, remaining_qty, f"Retry approved for {remaining_qty} units (market move {price_move_pct:.2f}% < 1.00% ceiling)"

    def evaluate_retry(
        self,
        order_id: str,
        current_market_price: float,
        quote_timestamp: Optional[float] = None,
        max_quote_age_sec: float = 2.0,
        now_utc: Optional[float] = None,
    ) -> Tuple[bool, int, str]:
        with self._lock:
            return self._evaluate_retry_locked(
                order_id=order_id,
                current_market_price=current_market_price,
                quote_timestamp=quote_timestamp,
                max_quote_age_sec=max_quote_age_sec,
                now_utc=now_utc,
                reserve_slot=True,
            )

    def reconcile_terminal_order(self, order_id: str, st: Optional[dict] = None) -> bool:
        with self._lock:
            rec = self.terminal_orders.get(order_id)
            if not rec:
                return False

        if st is None:
            st = self._get_order_status(rec)
        if not st:
            return False

        filled = int(st.get("filledQty") or 0)
        rec["filled_qty"] = filled
        new_qty = filled - rec["protected_qty"]

        if new_qty > 0:
            if rec.get("entry_only_amo"):
                logger.critical("F&O AMO LATE FILL %s (%s): %s units without SL/target; manual exit required",
                                order_id, rec['symbol'], filled)
                rec["amo_manual_risk_alerted"] = True
            else:
                logger.warning(
                    f"[Protection] LATE FILL DETECTED for terminal order {order_id} ({rec['symbol']}): "
                    f"{new_qty} additional shares filled (total filled: {filled}). Placing protection."
                )
                self._protect(rec, st, filled, new_qty)
            self._save()
            return True
        return False

    def execute_retry(
        self,
        order_id: str,
        current_market_price: Optional[float] = None,
        revised_limit_price: Optional[float] = None,
        markup_pct: Optional[float] = None,
        quote_timestamp: Optional[float] = None,
        max_quote_age_sec: float = 2.0,
        now_utc: Optional[float] = None,
        reference_date: Optional[date] = None,
    ) -> Tuple[bool, Optional[str], str]:
        if self.journal_db is None:
            logger.critical(f"[Protection] Retry blocked for {order_id}: active durable SQLite journal is required")
            return False, None, "Retry blocked: active durable SQLite journal is required (zero broker orders placed)"

        if hasattr(self.broker, "stop_manager") and self.broker.stop_manager:
            if self.broker.stop_manager.is_stopped():
                return False, None, "Retry rejected: EMERGENCY STOP is active"

        gate = getattr(self.broker, "reconciliation_gate", None)
        if gate is not None and hasattr(gate, "is_accepting_entries") and not gate.is_accepting_entries:
            return False, None, "Retry rejected: reconciliation gate is CLOSED"

        t0_clock = float(self.clock())
        eval_clock = float(now_utc) if now_utc is not None else t0_clock
        source_quote_ts: Optional[float] = float(quote_timestamp) if (quote_timestamp is not None and not isinstance(quote_timestamp, bool)) else None
        local_retrieval_ts: float = eval_clock
        quote_ts_type: str = "SOURCE_TIMESTAMP" if source_quote_ts is not None else "LOCAL_RETRIEVAL"

        with self._lock:
            rec = self.pending.get(order_id) or self.terminal_orders.get(order_id)
            if not rec:
                return False, None, f"Order {order_id} not in tracking"

            if current_market_price is None:
                if hasattr(self.broker, "get_yahoo_quote_details") and rec.get("segment") in ("NSE_EQ", "BSE_EQ"):
                    q = self.broker.get_yahoo_quote_details(
                        stock_symbol=rec["symbol"],
                        exchange_segment=rec["segment"],
                        security_id=rec["security_id"],
                        now_utc=eval_clock,
                        max_quote_age_sec=max_quote_age_sec,
                        allow_cached=False,
                        cmp_policy="STRICT_TIMESTAMP",
                    )
                    if isinstance(q, QuoteResult):
                        if not q.is_valid:
                            return False, None, f"Retry rejected: fresh quote check failed ({q.failure_reason})"
                        current_market_price = q.price
                        if source_quote_ts is None and q.quote_timestamp is not None and q.quote_timestamp > 0:
                            source_quote_ts = float(q.quote_timestamp)
                            quote_ts_type = "SOURCE_TIMESTAMP"
                        t_after_q = float(self.clock())
                        local_retrieval_ts = (float(now_utc) + max(0.0, t_after_q - t0_clock)) if now_utc is not None else t_after_q
                elif hasattr(self.broker, "get_ltp") and rec.get("segment") in ("NSE_FNO", "BSE_FNO"):
                    try:
                        ltp_ret = self.broker.get_ltp(
                            rec["segment"],
                            rec["security_id"],
                            symbol=rec["symbol"],
                            now_utc=eval_clock,
                            max_quote_age_sec=max_quote_age_sec,
                        )
                        if isinstance(ltp_ret, tuple) and len(ltp_ret) == 3 and ltp_ret[0] and float(ltp_ret[1]) > 0:
                            current_market_price = float(ltp_ret[1])
                            t_after_ltp = float(self.clock())
                            local_retrieval_ts = (float(now_utc) + max(0.0, t_after_ltp - t0_clock)) if now_utc is not None else t_after_ltp
                            # CV13-04: Distinguish F&O local retrieval timestamp from broker/exchange source timestamp.
                            # Never fabricate a source timestamp from local clock.
                            ltp_meta = getattr(self.broker, "last_ltp_meta", None)
                            if isinstance(ltp_meta, dict) and ltp_meta.get("source_quote_timestamp") is not None:
                                source_quote_ts = float(ltp_meta["source_quote_timestamp"])
                                quote_ts_type = "SOURCE_TIMESTAMP"
                            elif source_quote_ts is None:
                                quote_ts_type = "LOCAL_RETRIEVAL"
                    except Exception:
                        pass

            rec["retry_quote_timestamp_type"] = quote_ts_type
            rec["retry_source_quote_timestamp"] = source_quote_ts
            rec["retry_local_retrieval_timestamp"] = local_retrieval_ts

            segment = str(rec.get("segment") or "").strip().upper()
            if segment not in ("NSE_EQ", "BSE_EQ", "NSE_FNO", "BSE_FNO"):
                return False, None, f"Retry rejected: unsupported exchange segment '{segment}'"

            sec_id = str(rec.get("security_id") or "").strip()
            if not sec_id or not sec_id.isdigit():
                return False, None, f"Retry rejected: invalid or missing security_id '{sec_id}'"

            raw_sym = str(rec.get("symbol") or "").strip().upper()
            underlying = raw_sym.replace("-EQ", "").split("-")[0].strip()
            if not underlying or underlying in INDEX_SYMBOLS:
                return False, None, f"Retry rejected: invalid or index instrument '{raw_sym}'"

            prod_type_str = str(rec.get("product_type") or "").strip().upper()
            try:
                prod_type = ProductType(prod_type_str)
            except Exception:
                return False, None, f"Retry rejected: unknown or unsupported product_type '{prod_type_str}' (defaulting to CNC is prohibited)"

            if segment in ("NSE_EQ", "BSE_EQ") and prod_type not in (ProductType.CNC, ProductType.MTF, ProductType.INTRADAY):
                return False, None, f"Retry rejected: product_type '{prod_type.value}' incompatible with equity segment '{segment}'"
            if segment in ("NSE_FNO", "BSE_FNO") and prod_type != ProductType.MARGIN:
                return False, None, f"Retry rejected: F&O segment '{segment}' requires product_type 'MARGIN', got '{prod_type.value}'"

            can_retry, retry_qty, eval_reason = self._evaluate_retry_locked(
                order_id=order_id,
                current_market_price=current_market_price if current_market_price is not None else 0.0,
                quote_timestamp=source_quote_ts if source_quote_ts is not None else local_retrieval_ts,
                max_quote_age_sec=max_quote_age_sec,
                now_utc=eval_clock,
                reserve_slot=False,
            )
            if not can_retry:
                return False, None, eval_reason

            lot_size = int(rec.get("lot_size") or 1)
            inst_tick = float(rec.get("tick_size") or TICK)
            if inst_tick <= 0:
                return False, None, f"Retry rejected: invalid tick_size {inst_tick}"

            if segment in ("NSE_FNO", "BSE_FNO"):
                opt_type = str(rec.get("option_type") or "").strip().upper()
                strike = float(rec.get("strike") or 0.0)
                exp_str = str(rec.get("expiry") or "").strip()
                if opt_type not in ("CE", "PE"):
                    return False, None, f"Retry rejected: F&O contract missing valid CE/PE option_type ('{opt_type}')"
                if strike <= 0.0:
                    return False, None, f"Retry rejected: F&O contract missing valid strike ({strike})"
                if not exp_str:
                    return False, None, "Retry rejected: F&O contract missing expiry date"
                try:
                    exp_date = date.fromisoformat(exp_str[:10])
                except ValueError:
                    return False, None, f"Retry rejected: invalid F&O expiry format '{exp_str}'"
                today_ref = reference_date or date.today()
                if exp_date < today_ref:
                    return False, None, f"Retry rejected: F&O option contract expired on {exp_date.isoformat()}"
                if lot_size <= 0 or (retry_qty % lot_size) != 0:
                    return False, None, f"Retry rejected: retry quantity {retry_qty} is not a multiple of lot_size {lot_size}"
                order_symbol = str(rec.get("trading_symbol") or f"{underlying}-{strike:g}{opt_type}").strip()
                if order_symbol.endswith("-EQ"):
                    return False, None, f"Retry rejected: corrupted F&O trading symbol '{order_symbol}' ending with -EQ"
            else:
                if lot_size <= 0 or (retry_qty % lot_size) != 0:
                    return False, None, f"Retry rejected: invalid equity quantity {retry_qty} for lot_size {lot_size}"
                order_symbol = str(rec.get("trading_symbol") or (f"{underlying}-EQ" if not raw_sym.endswith("-EQ") else raw_sym)).strip()

            if markup_pct is not None:
                cfg_markup = float(markup_pct)
            else:
                raw_cfg_m = getattr(getattr(self.broker, "cfg", None), "equity_price_markup_pct", 0.5)
                cfg_markup = float(raw_cfg_m) if isinstance(raw_cfg_m, (int, float)) else 0.5
            effective_markup = min(max(0.0, cfg_markup), 1.0)
            max_ceiling_price = round_to_tick(
                float(current_market_price) * (1.0 + effective_markup / 100.0),
                inst_tick,
                mode="nearest",
            )
            hard_1pct_ceiling = round_to_tick(
                float(current_market_price) * 1.01,
                inst_tick,
                mode="nearest",
            )

            if revised_limit_price is not None:
                price = round_to_tick(float(revised_limit_price), inst_tick, mode="nearest")
                if price > hard_1pct_ceiling + 1e-6:
                    return (
                        False,
                        None,
                        f"Retry rejected: revised_limit_price ({price}) exceeds 1.00% markup ceiling ({hard_1pct_ceiling}) above market price ({current_market_price})",
                    )
            else:
                price = max_ceiling_price

            if price <= 0.0 or not math.isfinite(price):
                return False, None, f"Invalid retry limit price {price} <= 0"

            retry_cost = float(price) * int(retry_qty)
            avail_funds = 1000000.0
            funds_fn = getattr(self.broker, "get_fund_limits", None)
            should_check_funds = (
                (self.risk_manager is not None)
                or hasattr(funds_fn, "mock_calls")
                or hasattr(getattr(getattr(self.broker, "session", None), "get", None), "mock_calls")
            )
            if should_check_funds and callable(funds_fn):
                try:
                    f_ret = funds_fn()
                    if isinstance(f_ret, tuple) and len(f_ret) == 3:
                        f_ok, f_avail, f_msg = f_ret
                        if not f_ok:
                            return False, None, f"Retry rejected: broker funds verification failed ({f_msg})"
                        avail_funds = float(f_avail)
                        if avail_funds < retry_cost:
                            return False, None, f"Retry rejected: insufficient available funds ({avail_funds:.2f} < {retry_cost:.2f})"
                except Exception as e:
                    return False, None, f"Retry rejected: broker funds exception ({e})"

            if self.risk_manager is not None and hasattr(self.risk_manager, "validate_order_risk"):
                if hasattr(self.risk_manager, "sync_from_journal_and_broker"):
                    self.risk_manager.sync_from_journal_and_broker(
                        journal_db=self.journal_db,
                        broker=self.broker if not self.dry_run else None,
                        watcher=self,
                    )
                r_ok, r_reason = self.risk_manager.validate_order_risk(retry_cost, avail_funds)
                if not r_ok:
                    return False, None, f"Retry rejected by risk manager: {r_reason}"

            root_oid = str(rec.get("root_order_id") or order_id)
            corr_id = generate_correlation_id("RTRY", underlying, self.clock())
            parent_corr = rec.get("correlation_id") or order_id
            resolved_parent_route = self._resolve_protection_route(rec)
            use_super_route = (resolved_parent_route == ProtectionRoute.SUPER_ORDER.value) or bool(rec.get("is_super_order", False)) or (segment in ("NSE_FNO", "BSE_FNO") and prod_type == ProductType.MARGIN)

            rec["retry_count"] += 1
            rec["retry_reserved"] = True
            rec["retry_eligible"] = False

        order_req = OrderRequest(
            correlation_id=corr_id,
            symbol=order_symbol,
            security_id=sec_id,
            exchange_segment=segment,
            transaction_type=TransactionType.BUY,
            product_type=prod_type,
            order_type=OrderType.LIMIT,
            price=price,
            quantity=retry_qty,
            trading_mode=getattr(getattr(self.broker, "cfg", None), "trading_mode", TradingMode.TEST),
        )

        try:
            sig_ri = inspect.signature(self.journal_db.record_order_intent)
            if "is_super_order" in sig_ri.parameters or any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig_ri.parameters.values()):
                self.journal_db.record_order_intent(
                    correlation_id=corr_id,
                    parent_correlation_id=parent_corr,
                    symbol=order_req.symbol,
                    trading_symbol=order_symbol,
                    security_id=order_req.security_id,
                    exchange_segment=order_req.exchange_segment,
                    product_type=order_req.product_type.value,
                    order_type=order_req.order_type.value,
                    price=order_req.price,
                    quantity=order_req.quantity,
                    is_super_order=use_super_route,
                    original_market_price=float(current_market_price),
                    tick_size=inst_tick,
                    lot_size=lot_size,
                    option_type=rec.get("option_type", ""),
                    strike=float(rec.get("strike") or 0.0),
                    expiry=rec.get("expiry", ""),
                )
            else:
                self.journal_db.record_order_intent(
                    correlation_id=corr_id,
                    parent_correlation_id=parent_corr,
                    symbol=order_req.symbol,
                    security_id=order_req.security_id,
                    exchange_segment=order_req.exchange_segment,
                    product_type=order_req.product_type.value,
                    order_type=order_req.order_type.value,
                    price=order_req.price,
                    quantity=order_req.quantity,
                )
            if hasattr(self.journal_db, "reserve_retry_slot"):
                reserved_ok = self.journal_db.reserve_retry_slot(root_oid, order_id, corr_id)
                if not reserved_ok:
                    self.journal_db.update_order_intent(
                        corr_id,
                        state="NOT_SUBMITTED",
                        error_msg=f"Durable retry slot already consumed for root order {root_oid}",
                    )
                    return False, None, f"Retry rejected: durable retry slot already consumed for root order {root_oid}"
            self.journal_db.update_order_intent(corr_id, state="SUBMITTING")
            self._save_strict()
        except Exception as e:
            logger.critical(f"[Protection] Journal write failed before retry POST for {order_id} ({e}). Aborting with zero broker orders.")
            return False, None, f"Retry aborted: journal write failed ({e}) — zero broker orders placed"

        # =====================================================================
        # CV13-04: Revalidate retry eligibility immediately before submission
        # =====================================================================
        t_pre_submit = float(self.clock())
        clock_delta = max(0.0, t_pre_submit - t0_clock)
        final_clock = (float(now_utc) + clock_delta) if now_utc is not None else t_pre_submit

        final_fail_reason: Optional[str] = None

        # 1. Recheck emergency stop, reconciliation gate, and transition gate right before broker submission (B05)
        t_blocked_sub, t_reason_sub = self._is_transition_gate_blocking_new_entries()
        if hasattr(self.broker, "stop_manager") and self.broker.stop_manager and self.broker.stop_manager.is_stopped():
            final_fail_reason = "Retry rejected before submission: EMERGENCY STOP became active"
        elif gate is not None and hasattr(gate, "is_accepting_entries") and not gate.is_accepting_entries:
            final_fail_reason = "Retry rejected before submission: reconciliation gate is CLOSED"
        elif t_blocked_sub:
            final_fail_reason = f"Retry rejected before submission: {t_reason_sub}"

        # 2. Recalculate quote age using the current clock and available validated quote / retrieval timestamps
        if final_fail_reason is None:
            if source_quote_ts is not None:
                if not math.isfinite(source_quote_ts) or source_quote_ts <= 0.0:
                    final_fail_reason = f"Retry rejected before submission: invalid source quote timestamp ({source_quote_ts})"
                else:
                    final_src_age = round(final_clock - source_quote_ts, 6)
                    if final_src_age < 0.0:
                        final_fail_reason = f"Retry rejected before submission: future quote timestamp (age={final_src_age:.2f}s < 0.0s)"
                    elif final_src_age > max_quote_age_sec:
                        final_fail_reason = (
                            f"Retry rejected before submission: stale quote after pre-submit checks "
                            f"(age={final_src_age:.2f}s > max={max_quote_age_sec:.2f}s)"
                        )

            if final_fail_reason is None:
                retrieval_age = round(final_clock - local_retrieval_ts, 6)
                if retrieval_age < 0.0:
                    final_fail_reason = f"Retry rejected before submission: negative retrieval age ({retrieval_age:.2f}s)"
                elif retrieval_age > max_quote_age_sec:
                    final_fail_reason = (
                        f"Retry rejected before submission: quote became stale during funds/persistence checks "
                        f"(elapsed={retrieval_age:.2f}s > max={max_quote_age_sec:.2f}s)"
                    )

        if final_fail_reason is not None:
            # Record NOT_SUBMITTED distinctly from UNKNOWN while preserving the root's one-retry guarantee
            try:
                self.journal_db.update_order_intent(
                    corr_id,
                    state="NOT_SUBMITTED",
                    error_msg=final_fail_reason,
                )
            except Exception:
                pass
            with self._lock:
                rec["retry_final_status"] = "NOT_SUBMITTED"
                rec["retry_error"] = final_fail_reason
            self._save()
            logger.warning(f"[Protection] {final_fail_reason} for parent {order_id} ({corr_id}); recorded as NOT_SUBMITTED.")
            return False, None, final_fail_reason

        actual_super_used = False
        if use_super_route and hasattr(self.broker, "place_super_order"):
            init_levels = calculate_protection_levels(
                executed_price=price,
                quantity=retry_qty,
                sl_pct=float(rec.get("protection_sl_pct", self.sl_pct)),
                target_pct=float(rec.get("protection_target_pct", self.target_pct)),
                sl_limit_buffer_pct=self.sl_limit_buffer_pct,
                tick_size=inst_tick,
            )
            sup_ret = self.broker.place_super_order(
                order_req,
                stop_loss_price=init_levels.sl_trigger,
                target_price=init_levels.target_price,
            )
            if isinstance(sup_ret, tuple) and len(sup_ret) == 3:
                ok, broker_id, place_msg = sup_ret
                actual_super_used = True
            else:
                ok, broker_id, place_msg = False, None, "place_super_order returned invalid response"
        else:
            ok, broker_id, place_msg = self.broker.place_order(order_req)

        if not ok or not broker_id:
            is_timeout = _is_ambiguous_message(place_msg)
            try:
                self.journal_db.update_order_intent(
                    corr_id,
                    state="UNKNOWN" if is_timeout else "REJECTED",
                    error_msg=place_msg,
                )
            except Exception:
                pass
            if is_timeout and gate is not None and hasattr(gate, "halt_new_entries"):
                gate.halt_new_entries(f"Retry order {corr_id} outcome is UNKNOWN: {place_msg}")
            logger.error(f"[Protection] Broker rejected/failed retry order for parent {order_id}: {place_msg}")
            return False, None, f"Retry placement failed: {place_msg}"

        new_order_id = str(broker_id)
        try:
            self.journal_db.update_order_intent(corr_id, state="ACKED", broker_order_id=new_order_id)
            if hasattr(self.journal_db, "record_order"):
                self.journal_db.record_order(
                    correlation_id=corr_id,
                    broker_order_id=new_order_id,
                    trading_mode=order_req.trading_mode.value,
                    product_type=prod_type.value,
                    exchange_segment=segment,
                    symbol=underlying,
                    security_id=sec_id,
                    order_type=OrderType.LIMIT.value,
                    price=price,
                    quantity=retry_qty,
                    status="PENDING",
                )
        except Exception:
            pass

        self.track(
            order_id=new_order_id,
            root_order_id=root_oid,
            correlation_id=corr_id,
            symbol=underlying,
            trading_symbol=order_symbol,
            security_id=sec_id,
            segment=segment,
            qty=retry_qty,
            product_type=prod_type.value,
            dry_price=price if new_order_id.startswith("DRY-") else None,
            original_market_price=float(current_market_price),
            is_super_order=actual_super_used,
            tick_size=inst_tick,
            lot_size=lot_size,
            option_type=rec.get("option_type", ""),
            strike=float(rec.get("strike") or 0.0),
            expiry=rec.get("expiry", ""),
            preserve_existing=False,
            retry_count=1,
            max_retries=1,
            retry_reserved=True,
            notification_meta=dict(rec.get("notification_meta") or {}) or None,
            protection_sl_pct=float(rec.get("protection_sl_pct", self.sl_pct)),
            protection_target_pct=float(rec.get("protection_target_pct", self.target_pct)),
        )

        with self._lock:
            rec["retry_order_id"] = new_order_id
            rec["retry_correlation_id"] = corr_id
            rec["retry_executed_at"] = self.clock()
        self._save()

        logger.info(
            f"[Protection] Single retry executed for parent {order_id} -> new order {new_order_id} "
            f"({retry_qty} units of {order_symbol} @ {price:.2f}, super={actual_super_used})"
        )
        return True, new_order_id, f"Retry executed successfully: {new_order_id}"

    def _get_order_status(self, rec: dict) -> Optional[dict]:
        oid = rec["order_id"]
        if str(oid).startswith("DRY-"):
            if rec.get("dry_price") is None:
                return {"orderStatus": "PENDING", "filledQty": 0}
            return {
                "orderStatus": "TRADED",
                "filledQty": rec["qty"],
                "averageTradedPrice": rec["dry_price"],
            }

        if hasattr(self.broker, "order_status"):
            return self.broker.order_status(oid)
        return None

    def has_open_monitored_positions(self) -> bool:
        """P0-03 & P1-10: Returns True if any filled position in terminal_orders is still open and awaiting exit."""
        with self._lock:
            for rec in list(self.terminal_orders.values()) + [r for r in self.pending.values() if isinstance(r, dict) and r.get("entry_only_amo")]:
                if not isinstance(rec, dict):
                    continue
                if str(rec.get("order_id") or "").startswith("DRY-"):
                    continue
                if int(rec.get("filled_qty") or 0) > 0 and str(rec.get("position_state") or "PROTECTED") != PositionLifecycleState.POSITION_CLOSED.value:
                    return True
        return False

    def supervise_open_positions(self, current_time: Optional[float] = None) -> bool:
        """
        P0-03, P0-05, P0-09 & P1-10:
        Continuously supervises open protected positions after entry fill:
        - Checks Super Order / Forever OCO leg states (`TARGET_LEG`, `STOP_LOSS_LEG`).
        - Distinguishes leg `TRIGGERED` / Super Order `CLOSED` (trigger event) from actual SELL tradebook fill.
        - Confirms exit fills strictly from SELL tradebook rows (`GET /v2/trades` / `GET /v2/trades/{order-id}`),
          updates `fills` with real `exchangeTradeId` (`transaction_type='SELL'`), and calculates gross realized P&L.
        - Detects manual exits / partial manual sales via `get_positions()` / `get_holdings()` when bot-owned
          protective legs remain resting, halts new risk-increasing entries, alerts the owner, and cancels
          verified orphaned bot-owned exit legs when position is flat.
        """
        now_ts = float(current_time if current_time is not None else self.clock())
        with self._lock:
            open_recs = [
                rec for rec in list(self.terminal_orders.values()) + [r for r in self.pending.values() if isinstance(r, dict) and r.get("entry_only_amo")]
                if isinstance(rec, dict)
                and not str(rec.get("order_id") or "").startswith("DRY-")
                and int(rec.get("filled_qty") or 0) > 0
                and str(rec.get("position_state") or "PROTECTED") != PositionLifecycleState.POSITION_CLOSED.value
            ]
        if not open_recs:
            return False

        # Read broker snapshots once per pass if available (avoiding calls on unconfigured mocks)
        is_real_dhan_unmocked_session = (
            type(self.broker).__name__ == "DhanClient"
            and not hasattr(getattr(getattr(self.broker, "session", None), "get", None), "mock_calls")
            and "unittest.mock" not in str(type(getattr(getattr(self.broker, "session", None), "get", None)))
            and (os.environ.get("AUDITBOT_TEST_ISOLATION") == "1" or "unittest" in os.sys.modules)
        )

        unreadable_books = set()

        def _safe_list_call(attr_name: str) -> Optional[List[Dict[str, Any]]]:
            fn = getattr(self.broker, attr_name, None)
            if not callable(fn):
                return None
            if is_real_dhan_unmocked_session and not hasattr(fn, "mock_calls") and "unittest.mock" not in str(type(fn)):
                return None
            try:
                res = fn()
                if res is None or "Mock" in type(res).__name__:
                    return None
                if type(res).__name__ == "BrokerReadFailure":
                    unreadable_books.add(attr_name)
                    return None
                if isinstance(res, list):
                    if all(isinstance(x, dict) for x in res):
                        return list(res)
                    unreadable_books.add(attr_name)
                    return None
                unreadable_books.add(attr_name)
            except Exception:
                unreadable_books.add(attr_name)
            return None

        native_amo_only = all(self._resolve_protection_route(rec) == "ENTRY_ONLY_AMO" for rec in open_recs)
        super_book = [] if native_amo_only else _safe_list_call("get_super_orders")
        forever_book = [] if native_amo_only else _safe_list_call("get_forever_orders")
        trade_book = _safe_list_call("get_trade_book")
        positions_book = _safe_list_call("get_positions")
        needs_holdings = any(
            str(r.get("product_type") or "").upper() in ("CNC", "MTF") for r in open_recs
        )
        # A filled entry-only AMO may have settled into Demat. Never treat a
        # zero intraday position as proof of zero settled delivery holdings.
        holdings_book = _safe_list_call("get_holdings") if needs_holdings else []
        snapshot_complete = not unreadable_books and all(
            book is not None for book in (
                super_book, forever_book, trade_book, positions_book, holdings_book
            )
        )

        changed = False
        gate = getattr(self.broker, "reconciliation_gate", None)

        if unreadable_books:
            unreadable_msg = f"Unreadable broker response during position supervision ({sorted(unreadable_books)})"
            logger.error(f"[Protection] 🚨 {unreadable_msg}")
            if gate is not None and hasattr(gate, "halt_new_entries"):
                gate.halt_new_entries(unreadable_msg)
            for rec in open_recs:
                rec["unreadable_broker_response"] = True
                changed = True

        if (
            super_book is None
            and forever_book is None
            and trade_book is None
            and positions_book is None
            and holdings_book is None
        ):
            return changed

        active_states = {"PENDING", "TRANSIT", "OPEN", "ACTIVE", "CONFIRM", "CONFIRMED"}
        terminal_leg_states = {"CANCELLED", "CANCELED", "REJECTED", "EXPIRED", "CLOSED", "TRADED"}
        dead_leg_states = {"CANCELLED", "CANCELED", "REJECTED", "EXPIRED"}

        # Precompute all verified leg order IDs across all tracked bot orders to detect cross-order collisions
        all_bot_leg_owners: Dict[str, str] = {}
        with self._lock:
            all_known_recs = list(self.pending.values()) + list(self.terminal_orders.values())
        for k_rec in all_known_recs:
            if not isinstance(k_rec, dict):
                continue
            k_oid = str(k_rec.get("order_id") or "").strip()
            if not k_oid:
                continue
            all_bot_leg_owners[k_oid] = k_oid
            for v_id in (k_rec.get("verified_leg_order_ids") or []):
                vs = str(v_id or "").strip()
                if vs and not vs.startswith("SUPER-"):
                    all_bot_leg_owners[vs] = k_oid
            for cid_k in (k_rec.get("confirmed_protection_ids") or []):
                cs = str(cid_k or "").strip()
                if cs and not cs.startswith("SUPER-"):
                    all_bot_leg_owners[cs] = k_oid

        for rec in open_recs:
            oid = str(rec.get("order_id") or "").strip()
            sec_id = str(rec.get("security_id") or "").strip()
            seg = str(rec.get("segment") or "NSE_EQ").strip().upper()
            prod = str(rec.get("product_type") or "CNC").strip().upper()
            route = self._resolve_protection_route(rec)
            buy_filled = int(rec.get("filled_qty") or 0)
            if buy_filled <= 0 or not oid:
                continue

            expected_client_id = str(
                rec.get("account_id")
                or getattr(getattr(self.broker, "cfg", None), "dhan_client_id", "")
                or getattr(self.journal_db, "account_id", "")
                or ""
            ).strip()

            prev_pos_state = str(rec.get("position_state") or PositionLifecycleState.PROTECTED.value)
            prev_sell_qty = int(rec.get("exit_filled_qty") or 0)
            prev_trig_leg = str(rec.get("triggered_leg") or "")

            # P0-A: Build strictly verified parent-linked exit leg order IDs (no string-prefix splitting or same-instrument guessing)
            leg_id_to_name: Dict[str, str] = {}
            saved_leg_map = rec.get("verified_leg_map")
            if isinstance(saved_leg_map, dict):
                for k_id, v_leg in saved_leg_map.items():
                    ks = str(k_id or "").strip()
                    vs = str(v_leg or "").strip().upper()
                    if ks and vs in ("TARGET_LEG", "STOP_LOSS_LEG"):
                        leg_id_to_name[ks] = vs

            leg_order_ids = {oid}
            for saved_id in (rec.get("verified_leg_order_ids") or []):
                s_id = str(saved_id or "").strip()
                if s_id and not s_id.startswith("SUPER-"):
                    leg_order_ids.add(s_id)
            for explicit_key in ("sl_order_id", "tp_order_id", "exit_order_id"):
                ex_id = str(rec.get(explicit_key) or "").strip()
                if ex_id and not ex_id.startswith("SUPER-"):
                    leg_order_ids.add(ex_id)
                    if explicit_key == "sl_order_id":
                        leg_id_to_name.setdefault(ex_id, "STOP_LOSS_LEG")
                    elif explicit_key == "tp_order_id":
                        leg_id_to_name.setdefault(ex_id, "TARGET_LEG")
            for cid_p in (rec.get("confirmed_protection_ids") or []):
                s_cid = str(cid_p or "").strip()
                if s_cid and not s_cid.startswith("SUPER-"):
                    leg_order_ids.add(s_cid)

            leg_cancel_states: Dict[str, str] = {}
            if isinstance(rec.get("orphaned_leg_cancel_states"), dict):
                for k_c, v_c in rec["orphaned_leg_cancel_states"].items():
                    leg_cancel_states[str(k_c)] = str(v_c)

            leg_cancel_details: Dict[str, Dict[str, Any]] = {}
            if isinstance(rec.get("orphaned_leg_cancel_details"), dict):
                for k_d, v_d in rec["orphaned_leg_cancel_details"].items():
                    if isinstance(v_d, dict):
                        leg_cancel_details[str(k_d)] = dict(v_d)

            def _ensure_leg_detail(leg_key: str, leg_oid_val: str, leg_type_val: str, cur_st: str) -> Dict[str, Any]:
                det = leg_cancel_details.get(leg_key)
                if not isinstance(det, dict):
                    det = {
                        "leg_key": leg_key,
                        "leg_order_id": str(leg_oid_val or ""),
                        "leg_type": str(leg_type_val or leg_key),
                        "state": str(leg_cancel_states.get(leg_key) or "ACTIVE"),
                        "last_broker_status": str(cur_st or "UNKNOWN"),
                        "first_requested_at": 0.0,
                        "last_requested_at": 0.0,
                        "last_readback_at": now_ts,
                        "attempt_count": 0,
                        "max_attempts": int(self.orphan_cancel_max_attempts),
                        "next_retry_at": 0.0,
                        "deadline_at": 0.0,
                        "last_error": "",
                        "escalated": False,
                        "escalated_at": None,
                    }
                    leg_cancel_details[leg_key] = det
                else:
                    if leg_oid_val:
                        det["leg_order_id"] = str(leg_oid_val)
                    if cur_st:
                        det["last_broker_status"] = str(cur_st)
                    det["last_readback_at"] = now_ts
                    det.setdefault("max_attempts", int(self.orphan_cancel_max_attempts))
                    det.setdefault("attempt_count", 0)
                    det.setdefault("first_requested_at", 0.0)
                    det.setdefault("last_requested_at", 0.0)
                    det.setdefault("next_retry_at", 0.0)
                    det.setdefault("deadline_at", 0.0)
                    det.setdefault("last_error", "")
                    det.setdefault("escalated", False)
                    det.setdefault("escalated_at", None)
                return det

            resting_protective_qty = 0
            triggered_leg = prev_trig_leg
            both_legs_dead = False
            ambiguous_super_closed = False
            so_match: Optional[Dict[str, Any]] = None
            t_leg: Optional[Dict[str, Any]] = None
            sl_leg: Optional[Dict[str, Any]] = None
            t_st = ""
            sl_st = ""
            parent_st = ""
            fo_matches: List[Dict[str, Any]] = []

            # 1. Inspect Super Order or Forever OCO leg states (P0-B, P0-C & P1-02)
            if route == ProtectionRoute.SUPER_ORDER.value and isinstance(super_book, list):
                cand_so = next((r for r in super_book if isinstance(r, dict) and str(r.get("orderId") or "").strip() == oid), None)
                if isinstance(cand_so, dict):
                    so_client = str(cand_so.get("dhanClientId") or "").strip()
                    so_sec = str(cand_so.get("securityId") or "").strip()
                    so_seg = str(cand_so.get("exchangeSegment") or "").strip().upper()
                    so_prod = str(cand_so.get("productType") or "").strip().upper()
                    ownership_ok = (
                        (not so_client or not expected_client_id or so_client == expected_client_id)
                        and (not so_sec or not sec_id or so_sec == sec_id)
                        and (not so_seg or not seg or so_seg == seg)
                        and (not so_prod or not prod or so_prod == prod)
                    )
                    if ownership_ok:
                        so_match = cand_so
                        parent_st = str(so_match.get("orderStatus") or "").strip().upper()
                        legs = so_match.get("legDetails") if isinstance(so_match.get("legDetails"), list) else []
                        t_leg = next((l for l in legs if isinstance(l, dict) and str(l.get("legName") or "").upper() == "TARGET_LEG"), None)
                        sl_leg = next((l for l in legs if isinstance(l, dict) and str(l.get("legName") or "").upper() == "STOP_LOSS_LEG"), None)
                        for lg, lg_name in ((t_leg, "TARGET_LEG"), (sl_leg, "STOP_LOSS_LEG")):
                            if isinstance(lg, dict) and lg.get("orderId"):
                                lg_oid = str(lg["orderId"]).strip()
                                if lg_oid:
                                    leg_order_ids.add(lg_oid)
                                    leg_id_to_name[lg_oid] = lg_name
                                    all_bot_leg_owners[lg_oid] = oid

                        rec["verified_leg_order_ids"] = sorted(leg_order_ids - {oid})
                        rec["verified_leg_map"] = dict(leg_id_to_name)

                        t_st = str((t_leg or {}).get("orderStatus") or "").strip().upper()
                        sl_st = str((sl_leg or {}).get("orderStatus") or "").strip().upper()
                        t_trig_q = int((t_leg or {}).get("triggeredQuantity") or 0)
                        sl_trig_q = int((sl_leg or {}).get("triggeredQuantity") or 0)

                        if t_st in terminal_leg_states:
                            leg_cancel_states["TARGET_LEG"] = "CONFIRMED_TERMINAL"
                            t_det = _ensure_leg_detail("TARGET_LEG", str((t_leg or {}).get("orderId") or ""), "TARGET_LEG", t_st)
                            t_det["state"] = "CONFIRMED_TERMINAL"
                            t_det["next_retry_at"] = 0.0
                        if sl_st in terminal_leg_states:
                            leg_cancel_states["STOP_LOSS_LEG"] = "CONFIRMED_TERMINAL"
                            sl_det = _ensure_leg_detail("STOP_LOSS_LEG", str((sl_leg or {}).get("orderId") or ""), "STOP_LOSS_LEG", sl_st)
                            sl_det["state"] = "CONFIRMED_TERMINAL"
                            sl_det["next_retry_at"] = 0.0

                        t_triggered = (t_st in ("TRIGGERED", "PART_TRADED", "TRADED") or t_trig_q > 0)
                        sl_triggered = (sl_st in ("TRIGGERED", "PART_TRADED", "TRADED") or sl_trig_q > 0)

                        # P0-C: Require unambiguous leg trigger evidence; never infer TARGET_LEG from parent CLOSED
                        if t_triggered and sl_triggered:
                            triggered_leg = ""
                            ambiguous_super_closed = True
                            rec["ambiguous_super_closed"] = True
                            rec["exit_evidence_status"] = "CONTRADICTORY_LEG_STATES"
                        elif t_triggered:
                            triggered_leg = "TARGET_LEG"
                            rec["ambiguous_super_closed"] = False
                            rec["exit_evidence_status"] = "LEG_CONFIRMED"
                        elif sl_triggered:
                            triggered_leg = "STOP_LOSS_LEG"
                            rec["ambiguous_super_closed"] = False
                            rec["exit_evidence_status"] = "LEG_CONFIRMED"
                        elif parent_st == "CLOSED" and not triggered_leg:
                            triggered_leg = ""
                            ambiguous_super_closed = True
                            rec["ambiguous_super_closed"] = True
                            rec["exit_evidence_status"] = "AWAITING_LEG_OR_FILL_EVIDENCE"

                        if t_st in active_states or sl_st in active_states:
                            t_rem = int((t_leg or {}).get("remainingQuantity") or (t_leg or {}).get("quantity") or buy_filled)
                            sl_rem = int((sl_leg or {}).get("remainingQuantity") or (sl_leg or {}).get("quantity") or buy_filled)
                            resting_protective_qty = max(t_rem if t_st in active_states else 0, sl_rem if sl_st in active_states else 0)
                        elif t_st in dead_leg_states and sl_st in dead_leg_states:
                            both_legs_dead = True

            elif route == ProtectionRoute.FOREVER_OCO.value and isinstance(forever_book, list):
                rec_corr = str(rec.get("correlation_id") or "").strip()
                fo_matches = [
                    r for r in forever_book
                    if isinstance(r, dict)
                    and (
                        str(r.get("orderId") or "").strip() in leg_order_ids
                        or (rec_corr and str(r.get("correlationId") or "").strip() == rec_corr)
                    )
                    and (not sec_id or str(r.get("securityId") or "").strip() == sec_id)
                    and (not prod or str(r.get("productType") or "").strip().upper() == prod)
                    and (not expected_client_id or not r.get("dhanClientId") or str(r.get("dhanClientId")).strip() == expected_client_id)
                ]
                if fo_matches:
                    any_active = False
                    all_dead = True
                    fo_trig_legs = set()
                    for fr in fo_matches:
                        f_oid = str(fr.get("orderId") or "").strip()
                        f_leg = str(fr.get("legName") or "").strip().upper()
                        if f_oid:
                            leg_order_ids.add(f_oid)
                            all_bot_leg_owners[f_oid] = oid
                            if f_leg in ("TARGET_LEG", "STOP_LOSS_LEG"):
                                leg_id_to_name[f_oid] = f_leg
                        f_st = str(fr.get("orderStatus") or "").strip().upper()
                        if f_oid and f_st in terminal_leg_states:
                            leg_cancel_states[f_oid] = "CONFIRMED_TERMINAL"
                            f_det = _ensure_leg_detail(f_oid, f_oid, f_leg or "FOREVER_OCO", f_st)
                            f_det["state"] = "CONFIRMED_TERMINAL"
                            f_det["next_retry_at"] = 0.0
                        if f_st in ("TRIGGERED", "PART_TRADED", "TRADED"):
                            if f_leg in ("TARGET_LEG", "STOP_LOSS_LEG"):
                                fo_trig_legs.add(f_leg)
                            all_dead = False
                        elif f_st in active_states:
                            any_active = True
                            all_dead = False
                            resting_protective_qty = max(resting_protective_qty, int(fr.get("quantity") or 0))
                    rec["verified_leg_order_ids"] = sorted(leg_order_ids - {oid})
                    rec["verified_leg_map"] = dict(leg_id_to_name)
                    if len(fo_trig_legs) == 1:
                        triggered_leg = next(iter(fo_trig_legs))
                    elif len(fo_trig_legs) > 1:
                        triggered_leg = ""
                        ambiguous_super_closed = True
                        rec["ambiguous_super_closed"] = True
                    if all_dead and not any_active and not triggered_leg:
                        both_legs_dead = True

            # 2. Collect strictly parent-linked, verified SELL tradebook executions (P0-A, P0-01, P0-03 & P0-09)
            sell_trades: List[Dict[str, Any]] = []
            seen_trade_ids = set()
            per_order_trade_read_unverified = False

            def _verify_parent_sell_trade(tr: Any, expected_oid: Optional[str] = None) -> Tuple[bool, str]:
                if not isinstance(tr, dict):
                    return False, "NON_DICT_TRADE"
                t_side = str(tr.get("transactionType") or "").strip().upper()
                if t_side != "SELL":
                    return False, "NOT_SELL"
                t_oid = str(tr.get("orderId") or "").strip()
                if not t_oid:
                    return False, "MISSING_ORDER_ID"
                if expected_oid is not None and t_oid != expected_oid:
                    return False, "ORDER_ID_MISMATCH_FOR_QUERY"
                if t_oid not in leg_order_ids:
                    return False, "UNLINKED_ORDER_ID"
                owner_oid = all_bot_leg_owners.get(t_oid)
                if owner_oid and owner_oid != oid:
                    return False, "OWNED_BY_OTHER_BOT_ORDER"
                p_link = str(tr.get("parentOrderId") or tr.get("superOrderId") or "").strip()
                if p_link and p_link != oid and p_link not in leg_order_ids:
                    return False, "PARENT_ORDER_ID_MISMATCH"

                t_sec = str(tr.get("securityId") or "").strip()
                t_seg = str(tr.get("exchangeSegment") or "").strip().upper()
                t_prod = str(tr.get("productType") or "").strip().upper()
                if sec_id and t_sec != sec_id:
                    return False, "CONTRACT_SECURITY_MISMATCH"
                if seg and t_seg != seg:
                    return False, "CONTRACT_SEGMENT_MISMATCH"
                if prod and t_prod != prod:
                    return False, "CONTRACT_PRODUCT_MISMATCH"

                t_client = str(tr.get("dhanClientId") or tr.get("clientId") or "").strip()
                if t_client and expected_client_id and t_client != expected_client_id:
                    return False, "BROKER_ACCOUNT_MISMATCH"

                etid = str(tr.get("exchangeTradeId") or "").strip()
                if not etid or etid.upper() in ("0", "NONE", "NULL"):
                    return False, "MISSING_EXCHANGE_TRADE_ID"

                raw_q = tr.get("tradedQuantity")
                raw_p = tr.get("tradedPrice")
                if isinstance(raw_q, bool) or isinstance(raw_p, bool):
                    return False, "BOOLEAN_QTY_OR_PRICE"
                try:
                    qty_t = int(raw_q)
                    prc_t = float(raw_p)
                except (ValueError, TypeError):
                    return False, "NON_NUMERIC_QTY_OR_PRICE"
                if qty_t <= 0 or prc_t <= 0.0 or not math.isfinite(prc_t):
                    return False, "NON_POSITIVE_OR_NON_FINITE_QTY_PRICE"

                if self.journal_db and hasattr(self.journal_db, "get_fill_by_exchange_trade_id"):
                    try:
                        ex_fill = self.journal_db.get_fill_by_exchange_trade_id(etid)
                        if isinstance(ex_fill, dict):
                            ex_parent = str(ex_fill.get("parent_order_id") or "").strip()
                            ex_boid = str(ex_fill.get("broker_order_id") or "").strip()
                            if (ex_parent and ex_parent != oid and ex_parent not in leg_order_ids) or (ex_boid and ex_boid not in leg_order_ids):
                                return False, "EXCHANGE_TRADE_ID_CLAIMED_BY_OTHER_ORDER"
                    except Exception:
                        pass
                return True, "OK"

            # Replay any previously staged uncommitted broker SELL fills before scanning fresh tradebook
            for staged_tr in (rec.get("uncommitted_broker_sell_trades") or []):
                if isinstance(staged_tr, dict):
                    is_ok, _ = _verify_parent_sell_trade(staged_tr)
                    if is_ok:
                        etid_s = str(staged_tr.get("exchangeTradeId") or "").strip()
                        if etid_s and etid_s not in seen_trade_ids:
                            seen_trade_ids.add(etid_s)
                            sell_trades.append(staged_tr)

            if isinstance(trade_book, list):
                for tr in trade_book:
                    if not isinstance(tr, dict):
                        continue
                    if str(tr.get("transactionType") or "").strip().upper() != "SELL":
                        continue
                    t_oid = str(tr.get("orderId") or "").strip()
                    is_ok, v_reason = _verify_parent_sell_trade(tr)
                    if is_ok:
                        etid = str(tr.get("exchangeTradeId") or "").strip()
                        if etid not in seen_trade_ids:
                            seen_trade_ids.add(etid)
                            sell_trades.append(tr)
                    elif t_oid in leg_order_ids:
                        rec["unverified_trade_detected"] = True
                        rec["unverified_trade_reason"] = v_reason
                        unv_msg = f"Unverified/malformed broker SELL trade row on order {t_oid} (parent {oid}): {v_reason}"
                        logger.error(f"[Protection] 🚨 {unv_msg}")
                        if gate is not None and hasattr(gate, "halt_new_entries"):
                            gate.halt_new_entries(unv_msg)
                        changed = True
                    elif (
                        str(tr.get("securityId") or "").strip() == sec_id
                        and str(tr.get("exchangeSegment") or "").strip().upper() == seg
                        and str(tr.get("productType") or "").strip().upper() == prod
                        and t_oid not in all_bot_leg_owners
                    ):
                        rec["external_unlinked_sell_observed"] = True

            if hasattr(self.broker, "get_trades_for_order"):
                for l_oid in sorted(leg_order_ids):
                    if l_oid.startswith("SUPER-"):
                        continue
                    try:
                        if is_real_dhan_unmocked_session and not hasattr(self.broker.get_trades_for_order, "mock_calls") and "unittest.mock" not in str(type(self.broker.get_trades_for_order)):
                            continue
                        t_ord_res = self.broker.get_trades_for_order(l_oid)
                        if t_ord_res is None or "Mock" in type(t_ord_res).__name__:
                            continue
                        if type(t_ord_res).__name__ == "BrokerReadFailure":
                            per_order_trade_read_unverified = True
                            rec["unreadable_broker_response"] = True
                            if gate is not None and hasattr(gate, "halt_new_entries"):
                                gate.halt_new_entries(f"Broker get_trades_for_order({l_oid}) failed during exit reconciliation")
                            changed = True
                            continue
                        if isinstance(t_ord_res, list):
                            for tr in t_ord_res:
                                if not isinstance(tr, dict):
                                    continue
                                if str(tr.get("transactionType") or "").strip().upper() != "SELL":
                                    continue
                                is_ok, v_reason = _verify_parent_sell_trade(tr, expected_oid=l_oid)
                                if is_ok:
                                    etid = str(tr.get("exchangeTradeId") or "").strip()
                                    if etid not in seen_trade_ids:
                                        seen_trade_ids.add(etid)
                                        sell_trades.append(tr)
                                else:
                                    rec["unverified_trade_detected"] = True
                                    rec["unverified_trade_reason"] = v_reason
                                    if gate is not None and hasattr(gate, "halt_new_entries"):
                                        gate.halt_new_entries(f"Rejected unverified SELL trade from get_trades_for_order({l_oid}): {v_reason}")
                                    changed = True
                    except Exception:
                        pass

            # P0-01: Preserve external broker truth separately from durable acknowledged SQLite accounting.
            broker_observed_sell_qty = sum(int(t["tradedQuantity"]) for t in sell_trades)
            broker_observed_sell_val = sum(int(t["tradedQuantity"]) * float(t["tradedPrice"]) for t in sell_trades)
            broker_observed_sell_vwap = (
                round(broker_observed_sell_val / broker_observed_sell_qty, 4)
                if broker_observed_sell_qty > 0
                else 0.0
            )
            rec["broker_observed_exit_filled_qty"] = broker_observed_sell_qty
            rec["broker_observed_exit_vwap"] = broker_observed_sell_vwap

            journal_persistence_failed = False
            journal_failure_reasons: List[str] = []
            uncommitted_sell_trades: List[Dict[str, Any]] = []

            for st_row in sell_trades:
                etid_cur = str(st_row["exchangeTradeId"]).strip()
                b_oid_cur = str(st_row.get("orderId") or oid).strip()
                if self.journal_db and hasattr(self.journal_db, "record_fill"):
                    try:
                        self.journal_db.record_fill(
                            broker_order_id=b_oid_cur,
                            exchange_trade_id=etid_cur,
                            symbol=rec["symbol"],
                            traded_price=float(st_row["tradedPrice"]),
                            traded_quantity=int(st_row["tradedQuantity"]),
                            traded_at=now_ts,
                            transaction_type="SELL",
                            security_id=sec_id,
                            exchange_segment=seg,
                            product_type=prod,
                            parent_order_id=oid,
                            is_verified_trade=True,
                        )
                        if hasattr(self.journal_db, "get_fill_by_exchange_trade_id"):
                            persisted_row = self.journal_db.get_fill_by_exchange_trade_id(etid_cur)
                            if not isinstance(persisted_row, dict) or str(persisted_row.get("parent_order_id") or "").strip() != oid:
                                journal_persistence_failed = True
                                journal_failure_reasons.append(f"Fill {etid_cur} not present in SQLite after record_fill")
                                uncommitted_sell_trades.append(dict(st_row))
                    except Exception as db_err:
                        journal_persistence_failed = True
                        journal_failure_reasons.append(f"{type(db_err).__name__}: {db_err}")
                        uncommitted_sell_trades.append(dict(st_row))

            rec["uncommitted_broker_sell_trades"] = uncommitted_sell_trades

            # Recompute canonical position accounting strictly from durable SQLite fills when journal_db is active
            if self.journal_db and hasattr(self.journal_db, "get_position_accounting"):
                try:
                    acct_summary = self.journal_db.get_position_accounting(oid)
                    sell_qty = int(acct_summary.get("sell_filled_qty") or 0)
                    sell_vwap = float(acct_summary.get("sell_vwap") or 0.0) if sell_qty > 0 else float(rec.get("exit_vwap") or 0.0)
                    if float(acct_summary.get("buy_vwap") or 0.0) > 0:
                        rec["buy_vwap"] = float(acct_summary["buy_vwap"])
                except Exception as acct_err:
                    journal_persistence_failed = True
                    journal_failure_reasons.append(f"get_position_accounting failed: {acct_err}")
                    sell_qty = prev_sell_qty
                    sell_vwap = float(rec.get("exit_vwap") or 0.0)
            else:
                sell_qty = broker_observed_sell_qty
                sell_vwap = broker_observed_sell_vwap if broker_observed_sell_qty > 0 else float(rec.get("exit_vwap") or 0.0)

            # P0-C: If triggered_leg was not identified from leg status, check if verified SELL fills map unambiguously to a known leg ID
            if not triggered_leg:
                fill_leg_candidates = set()
                for st_row in sell_trades:
                    s_oid = str(st_row.get("orderId") or "").strip()
                    if s_oid in leg_id_to_name:
                        fill_leg_candidates.add(leg_id_to_name[s_oid])
                if not fill_leg_candidates and self.journal_db and hasattr(self.journal_db, "get_sell_fills_for_parent"):
                    try:
                        for db_f in self.journal_db.get_sell_fills_for_parent(oid):
                            b_oid = str(db_f.get("broker_order_id") or "").strip()
                            if b_oid in leg_id_to_name:
                                fill_leg_candidates.add(leg_id_to_name[b_oid])
                    except Exception:
                        pass
                if len(fill_leg_candidates) == 1:
                    triggered_leg = next(iter(fill_leg_candidates))
                    ambiguous_super_closed = False
                    rec["ambiguous_super_closed"] = False
                    rec["exit_evidence_status"] = "FILL_CONFIRMED"

            confirmed_open_qty = max(0, buy_filled - sell_qty)

            # 3. Account-bound holdings evidence, shared with startup verification.
            from src.engine.holding_quantity import observed_open_quantity
            broker_net_qty, quantity_evidence = observed_open_quantity(
                positions_book, holdings_book,
                security_id=sec_id, segment=seg, product=prod,
                account_id=expected_client_id,
            )
            if quantity_evidence not in ("VERIFIED_POSITIONS", "VERIFIED_SETTLED_HOLDINGS"):
                broker_net_qty = None
                rec["broker_quantity_unverified"] = True
                rec["broker_quantity_evidence"] = quantity_evidence
                if gate is not None and hasattr(gate, "halt_new_entries"):
                    gate.halt_new_entries(
                        f"Open holding {oid}: broker quantity unverified ({quantity_evidence})"
                    )
                changed = True

            # Compute aggregate open bot quantity across all open parent orders sharing (sec_id, seg, prod)
            # Use max(sell_qty, broker_observed_sell_qty) when checking manual exit so a broker-filled exit with a local DB error
            # is recognized as a persistence error rather than a manual external sale.
            effective_parent_open_qty = max(0, buy_filled - max(sell_qty, broker_observed_sell_qty))
            aggregate_contract_open_qty = 0
            for o_rec in open_recs:
                if (
                    str(o_rec.get("security_id") or "").strip() == sec_id
                    and str(o_rec.get("segment") or "NSE_EQ").strip().upper() == seg
                    and str(o_rec.get("product_type") or "CNC").strip().upper() == prod
                ):
                    if str(o_rec.get("order_id") or "").strip() == oid:
                        aggregate_contract_open_qty += effective_parent_open_qty
                    else:
                        o_buy = int(o_rec.get("filled_qty") or 0)
                        o_sell = max(int(o_rec.get("exit_filled_qty") or 0), int(o_rec.get("broker_observed_exit_filled_qty") or 0))
                        aggregate_contract_open_qty += max(0, o_buy - o_sell)

            manual_risk_candidate = (
                prev_pos_state == "UNPROTECTED_MANUAL_RISK"
                or (prev_pos_state == "RECONCILIATION_REQUIRED"
                    and bool(rec.get("manual_risk_acknowledged")))
            )
            entry_only_unlinked_reduction = (
                (route == "ENTRY_ONLY_AMO" or manual_risk_candidate)
                and snapshot_complete and broker_net_qty is not None
                and broker_net_qty < aggregate_contract_open_qty and sell_qty < buy_filled
            )
            manual_risk_quantity_unverified = (
                manual_risk_candidate and (broker_net_qty is None or not snapshot_complete)
            )
            if entry_only_unlinked_reduction or manual_risk_quantity_unverified:
                rec["reconciliation_required"] = True
                rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                if entry_only_unlinked_reduction:
                    rec["manual_exit_detected"] = True
                    rec["manual_exit_evidence_verified"] = True
                    rec["manual_exit_evidence_reason"] = "VERIFIED_AGGREGATE_QUANTITY_REDUCTION"
                else:
                    # Inaccessible/Dhan-429 broker books are UNKNOWN, not SELL.
                    rec["broker_quantity_unverified"] = True
                    rec["unreadable_broker_response"] = True
                if gate is not None and hasattr(gate, "halt_new_entries"):
                    gate.halt_new_entries(
                        f"Open holding {oid}: " + (
                            "verified aggregate holding reduction with unlinked SELL"
                            if entry_only_unlinked_reduction else "quantity not verified"
                        )
                    )
                changed = True

            owner_ack_verified = False
            if (
                manual_risk_candidate
                and self.journal_db is not None
                and hasattr(self.journal_db, "is_manual_risk_acknowledged")
            ):
                try:
                    owner_ack_verified = self.journal_db.is_manual_risk_acknowledged(
                        oid, str(rec.get("correlation_id") or ""),
                        expected_account_id=expected_client_id,
                        expected_security_id=sec_id,
                        required_qty=effective_parent_open_qty,
                    ) is True
                except Exception:
                    owner_ack_verified = False
            manual_risk_ack_unverified = manual_risk_candidate and not owner_ack_verified
            if manual_risk_ack_unverified:
                # A stored text label or stale watcher boolean is not an
                # account-bound, quantity-qualified durable owner ACK.
                rec["manual_risk_ack_unverified"] = True
                rec["reconciliation_required"] = True
                rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                if gate is not None and hasattr(gate, "halt_new_entries"):
                    gate.halt_new_entries(
                        f"Open holding {oid}: owner manual-risk ACK not independently verified"
                    )
                changed = True
            no_protection_conflicts = not any(rec.get(key) for key in (
                "sl_order_id", "tp_order_id", "exit_order_id",
                "confirmed_protection_ids", "verified_leg_order_ids",
                "verified_leg_map", "pending_oco", "orphaned_legs_detected",
                "orphaned_legs_manual_intervention_required",
                "uncommitted_broker_sell_trades", "broker_exit_already_executed",
                "external_unlinked_sell_observed", "unverified_trade_detected",
                "persistence_uncertain", "cancel_uncertain", "cancel_requested",
            ))
            # This can repair older falsely labelled records, but never
            # override a newer VERIFIED reduction or a failed broker/journal
            # check. It only repairs the record, not the entry gate.
            recovery_candidate = bool(
                prev_pos_state == "RECONCILIATION_REQUIRED"
                and rec.get("unreadable_broker_response")
                and not rec.get("manual_exit_evidence_verified")
                and not rec.get("manual_exit_evidence_reason")
                and not journal_persistence_failed
                and owner_ack_verified and no_protection_conflicts
                and not per_order_trade_read_unverified
                and sell_qty == 0 and broker_observed_sell_qty == 0
                and not triggered_leg and not ambiguous_super_closed
                and not both_legs_dead and resting_protective_qty == 0
                and not entry_only_unlinked_reduction
                and not manual_risk_quantity_unverified
                # Exact aggregate ownership evidence is necessary for
                # repairing legacy false MANUAL_EXIT flags. Extra shares from
                # a manual BUY could conceal an unlinked historical SELL.
                # Neither extra nor missing holdings prove both parents open.
                and broker_net_qty == aggregate_contract_open_qty
                # Historical settled positions cannot be 'recovered' merely
                # from fresh current-day CNC BUYs when Demat quantity is zero.
                and quantity_evidence == "VERIFIED_SETTLED_HOLDINGS"
                and snapshot_complete
            )

            has_orphan_condition = (
                snapshot_complete and broker_net_qty is not None
                and (
                    (broker_net_qty < effective_parent_open_qty and resting_protective_qty > broker_net_qty)
                    or (broker_net_qty < aggregate_contract_open_qty and resting_protective_qty > 0)
                    or (rec.get("orphaned_legs_detected", False) and not rec.get("orphaned_legs_cancelled", False))
                )
            )
            if has_orphan_condition:
                rec["manual_exit_detected"] = True
                rec["orphaned_legs_detected"] = True
                orphan_msg = (
                    f"Manual exit / position reduction detected for {rec['symbol']} ({oid}): "
                    f"broker netQty={broker_net_qty} < bot openQty={effective_parent_open_qty} (contract aggregate={aggregate_contract_open_qty}) "
                    f"while protective legs remain resting for {resting_protective_qty} units."
                )
                logger.critical(f"[Protection] 🚨 {orphan_msg}")
                if gate is not None and hasattr(gate, "halt_new_entries"):
                    gate.halt_new_entries(orphan_msg)
                if not rec.get("orphaned_legs_alerted", False):
                    rec["orphaned_legs_alerted"] = True
                    if self.journal_db:
                        if hasattr(self.journal_db, "record_system_event"):
                            try:
                                self.journal_db.record_system_event("MANUAL_EXIT_ORPHANED_LEGS", orphan_msg)
                            except Exception:
                                pass
                        if hasattr(self.journal_db, "enqueue_outbox"):
                            try:
                                self.journal_db.enqueue_outbox(
                                    "CRITICAL_ORPHANED_LEGS_ALERT",
                                    {
                                        "text": f"🚨 [ORPHANED_PROTECTION_LEGS] {orphan_msg}",
                                        "priority": "HIGH",
                                        "order_id": oid,
                                        "symbol": rec["symbol"],
                                    },
                                )
                            except Exception:
                                pass

                # P0-B & P1-02: Durable, bounded per-leg cancellation state machine when position is flat (broker_net_qty == 0)
                if broker_net_qty == 0 and not rec.get("orphaned_legs_cancelled", False):
                    def _step_leg_cancellation(
                        lg_key: str,
                        lg_oid_val: str,
                        lg_type_val: str,
                        lg_obj_val: Optional[Dict[str, Any]],
                        lg_st_val: str,
                        cancel_callable: Optional[Callable[[], Any]],
                        book_available: bool,
                    ) -> str:
                        det = _ensure_leg_detail(lg_key, lg_oid_val, lg_type_val, lg_st_val if book_available else "READBACK_UNAVAILABLE")
                        max_att = int(det.get("max_attempts") or self.orphan_cancel_max_attempts)
                        cur_att = int(det.get("attempt_count") or 0)
                        first_req = float(det.get("first_requested_at") or 0.0)
                        deadline = float(det.get("deadline_at") or 0.0)
                        next_retry = float(det.get("next_retry_at") or 0.0)

                        # 1. Terminal confirmation from authoritative broker readback always resolves the leg
                        if book_available and lg_st_val in terminal_leg_states:
                            det["state"] = "CONFIRMED_TERMINAL"
                            det["last_broker_status"] = lg_st_val
                            det["next_retry_at"] = 0.0
                            leg_cancel_states[lg_key] = "CONFIRMED_TERMINAL"
                            return "CONFIRMED_TERMINAL"

                        # 2. If broker readback failed or leg is missing from book, never issue blind cancel mutations
                        if not book_available or lg_obj_val is None:
                            det["last_broker_status"] = "READBACK_UNAVAILABLE" if not book_available else "MISSING_IN_BOOK"
                            if first_req > 0.0 and deadline > 0.0 and now_ts >= deadline:
                                det["state"] = "MANUAL_INTERVENTION_REQUIRED"
                                det["escalated"] = True
                                det["escalated_at"] = det.get("escalated_at") or now_ts
                                leg_cancel_states[lg_key] = "MANUAL_INTERVENTION_REQUIRED"
                                return "MANUAL_INTERVENTION_REQUIRED"
                            cur_s = str(leg_cancel_states.get(lg_key) or det.get("state") or "UNKNOWN")
                            if cur_s == "ACTIVE":
                                cur_s = "UNKNOWN"
                            det["state"] = cur_s
                            leg_cancel_states[lg_key] = cur_s
                            return cur_s

                        # 3. Leg is confirmed active in broker book (PENDING / TRANSIT / OPEN / ACTIVE / CONFIRM)
                        if lg_st_val in active_states:
                            if first_req > 0.0 and deadline > 0.0 and now_ts >= deadline:
                                det["state"] = "MANUAL_INTERVENTION_REQUIRED"
                                det["escalated"] = True
                                det["escalated_at"] = det.get("escalated_at") or now_ts
                                det["last_error"] = det.get("last_error") or f"Cancellation ACK remained {lg_st_val} past {self.orphan_cancel_deadline_sec:g}s deadline"
                                leg_cancel_states[lg_key] = "MANUAL_INTERVENTION_REQUIRED"
                                return "MANUAL_INTERVENTION_REQUIRED"

                            if cur_att > 0 and now_ts < next_retry:
                                # Still within bounded readback / backoff window; do not issue duplicate cancel mutation
                                cur_s = str(leg_cancel_states.get(lg_key) or det.get("state") or "ACK_UNKNOWN")
                                det["state"] = cur_s
                                leg_cancel_states[lg_key] = cur_s
                                return cur_s

                            if cur_att >= max_att:
                                det["state"] = "MANUAL_INTERVENTION_REQUIRED"
                                det["escalated"] = True
                                det["escalated_at"] = det.get("escalated_at") or now_ts
                                det["last_error"] = det.get("last_error") or f"Exhausted {cur_att}/{max_att} safe cancel attempts while broker reports {lg_st_val}"
                                leg_cancel_states[lg_key] = "MANUAL_INTERVENTION_REQUIRED"
                                return "MANUAL_INTERVENTION_REQUIRED"

                            if cancel_callable is None:
                                det["state"] = "UNKNOWN"
                                leg_cancel_states[lg_key] = "UNKNOWN"
                                return "UNKNOWN"

                            # Issue bounded cancel request / retry
                            if first_req <= 0.0:
                                first_req = now_ts
                                det["first_requested_at"] = first_req
                                det["deadline_at"] = first_req + self.orphan_cancel_deadline_sec
                            cur_att += 1
                            det["attempt_count"] = cur_att
                            det["last_requested_at"] = now_ts
                            det["state"] = "REQUESTED"
                            leg_cancel_states[lg_key] = "REQUESTED"
                            try:
                                c_res = cancel_callable()
                                if isinstance(c_res, tuple) and len(c_res) >= 2:
                                    c_ok, c_msg = bool(c_res[0]), str(c_res[1])
                                else:
                                    c_ok, c_msg = bool(c_res), str(c_res)
                            except Exception as c_exc:
                                c_ok, c_msg = False, f"{type(c_exc).__name__}: {c_exc}"

                            backoff_sec = self.orphan_cancel_retry_backoff_sec * (2 ** max(0, cur_att - 1))
                            if c_ok:
                                wait_sec = max(self.orphan_cancel_ack_timeout_sec, backoff_sec)
                                det["state"] = "ACK_UNKNOWN"
                                det["last_error"] = c_msg
                                det["next_retry_at"] = now_ts + wait_sec
                                leg_cancel_states[lg_key] = "ACK_UNKNOWN"
                                return "ACK_UNKNOWN"
                            else:
                                det["state"] = "REJECTED"
                                det["last_error"] = c_msg or "Cancel rejected by broker"
                                det["next_retry_at"] = now_ts + backoff_sec
                                leg_cancel_states[lg_key] = "REJECTED"
                                return "REJECTED"

                        # Unrecognized broker leg status
                        det["state"] = "UNKNOWN"
                        leg_cancel_states[lg_key] = "UNKNOWN"
                        return "UNKNOWN"

                    if route == ProtectionRoute.SUPER_ORDER.value:
                        has_cancel_fn = hasattr(self.broker, "cancel_super_order_leg")
                        book_ok = so_match is not None and isinstance(super_book, list)
                        for lg_name, lg_obj, lg_st in (
                            ("TARGET_LEG", t_leg, t_st),
                            ("STOP_LOSS_LEG", sl_leg, sl_st),
                        ):
                            lg_oid_s = str((lg_obj or {}).get("orderId") or "")
                            _step_leg_cancellation(
                                lg_key=lg_name,
                                lg_oid_val=lg_oid_s,
                                lg_type_val=lg_name,
                                lg_obj_val=lg_obj,
                                lg_st_val=lg_st,
                                cancel_callable=(lambda l_n=lg_name: self.broker.cancel_super_order_leg(oid, l_n)) if has_cancel_fn else None,
                                book_available=book_ok,
                            )
                        rec["orphaned_leg_cancel_states"] = dict(leg_cancel_states)
                        rec["orphaned_leg_cancel_details"] = dict(leg_cancel_details)
                        rec["orphaned_legs_cancelled"] = (
                            leg_cancel_states.get("TARGET_LEG") == "CONFIRMED_TERMINAL"
                            and leg_cancel_states.get("STOP_LOSS_LEG") == "CONFIRMED_TERMINAL"
                        )
                    elif route == ProtectionRoute.FOREVER_OCO.value:
                        owned_f_ids = [
                            str(x).strip()
                            for x in (rec.get("confirmed_protection_ids") or [])
                            if str(x).strip() and not str(x).strip().startswith("SUPER-")
                        ]
                        fo_by_id = {str(fr.get("orderId") or "").strip(): fr for fr in fo_matches if str(fr.get("orderId") or "").strip()}
                        has_fo_cancel = hasattr(self.broker, "cancel_forever_order")
                        book_ok = isinstance(forever_book, list) and bool(fo_by_id)
                        for f_id in owned_f_ids:
                            fr_row = fo_by_id.get(f_id)
                            f_st = str((fr_row or {}).get("orderStatus") or "").strip().upper()
                            f_leg_t = str((fr_row or {}).get("legName") or "FOREVER_OCO").strip().upper()
                            _step_leg_cancellation(
                                lg_key=f_id,
                                lg_oid_val=f_id,
                                lg_type_val=f_leg_t,
                                lg_obj_val=fr_row,
                                lg_st_val=f_st,
                                cancel_callable=(lambda fid=f_id: self.broker.cancel_forever_order(fid)) if has_fo_cancel else None,
                                book_available=book_ok,
                            )
                        rec["orphaned_leg_cancel_states"] = dict(leg_cancel_states)
                        rec["orphaned_leg_cancel_details"] = dict(leg_cancel_details)
                        rec["orphaned_legs_cancelled"] = bool(owned_f_ids) and all(
                            leg_cancel_states.get(fid) == "CONFIRMED_TERMINAL" for fid in owned_f_ids
                        )

                    # Check if any leg escalated to MANUAL_INTERVENTION_REQUIRED
                    escalated_legs = [
                        k for k, v in leg_cancel_states.items() if v == "MANUAL_INTERVENTION_REQUIRED"
                    ]
                    if escalated_legs and not rec.get("orphaned_legs_cancelled", False):
                        rec["orphaned_legs_manual_intervention_required"] = True
                        esc_details_str = ", ".join(
                            f"{k}(state={leg_cancel_details.get(k, {}).get('state')}, "
                            f"broker={leg_cancel_details.get(k, {}).get('last_broker_status')}, "
                            f"attempts={leg_cancel_details.get(k, {}).get('attempt_count')})"
                            for k in escalated_legs
                        )
                        esc_msg = (
                            f"Orphaned protective leg cancellation requires manual intervention for {rec['symbol']} ({oid}): "
                            f"{esc_details_str}. New entries remain halted."
                        )
                        logger.critical(f"[Protection] 🚨 {esc_msg}")
                        if gate is not None and hasattr(gate, "halt_new_entries"):
                            gate.halt_new_entries(esc_msg)
                        if not rec.get("orphaned_legs_escalation_alerted", False):
                            rec["orphaned_legs_escalation_alerted"] = True
                            if self.journal_db:
                                if hasattr(self.journal_db, "record_system_event"):
                                    try:
                                        self.journal_db.record_system_event("ORPHANED_LEG_CANCEL_ESCALATED", esc_msg)
                                    except Exception:
                                        pass
                                if hasattr(self.journal_db, "enqueue_outbox"):
                                    try:
                                        self.journal_db.enqueue_outbox(
                                            "CRITICAL_ORPHANED_LEG_ESCALATION",
                                            {
                                                "text": f"🚨 [MANUAL_INTERVENTION_REQUIRED] {esc_msg}",
                                                "priority": "HIGH",
                                                "order_id": oid,
                                                "symbol": rec["symbol"],
                                            },
                                        )
                                    except Exception:
                                        pass
                    elif rec.get("orphaned_legs_cancelled", False):
                        rec["orphaned_legs_manual_intervention_required"] = False
                changed = True

            # 4. Update position lifecycle state and emit notifications (P0-01, P0-C, P0-03 & P0-07)
            buy_vwap = float(rec.get("buy_vwap") or rec.get("original_market_price") or 0.0)
            rec["triggered_leg"] = triggered_leg if triggered_leg else ""
            if leg_cancel_states:
                rec["orphaned_leg_cancel_states"] = dict(leg_cancel_states)
            if leg_cancel_details:
                rec["orphaned_leg_cancel_details"] = dict(leg_cancel_details)

            if journal_persistence_failed:
                # P0-01: Database write/read failed while recording or reading exit fills.
                # NEVER transition to POSITION_CLOSED or emit a closed confirmation card!
                rec["reconciliation_required"] = True
                rec["persistence_uncertain"] = True
                rec["last_persistence_error"] = "; ".join(journal_failure_reasons)
                rec["exit_filled_qty"] = sell_qty
                rec["exit_vwap"] = sell_vwap
                rec["confirmed_position_open_qty"] = confirmed_open_qty
                rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                if broker_observed_sell_qty >= buy_filled > 0:
                    rec["broker_exit_already_executed"] = True
                persist_msg = (
                    f"Journal persistence failure during exit reconciliation for {rec['symbol']} ({oid}): "
                    f"broker_observed_sell={broker_observed_sell_qty}, durable_sell={sell_qty}, "
                    f"errors={rec['last_persistence_error']}"
                )
                logger.critical(f"[Protection] 🚨 {persist_msg}")
                if gate is not None and hasattr(gate, "halt_new_entries"):
                    gate.halt_new_entries(persist_msg)
                if not rec.get("persistence_failure_alerted", False):
                    rec["persistence_failure_alerted"] = True
                    if self.execution_reporter and hasattr(self.execution_reporter, "process_exit_event"):
                        try:
                            self.execution_reporter.process_exit_event(
                                rec,
                                "RECONCILIATION_REQUIRED",
                                observed_at=now_ts,
                                triggered_leg=triggered_leg,
                                sell_qty=sell_qty,
                                buy_vwap=buy_vwap,
                                sell_vwap=sell_vwap,
                            )
                        except Exception:
                            pass
                changed = True
            elif entry_only_unlinked_reduction or manual_risk_quantity_unverified or manual_risk_ack_unverified:
                # Never fabricate a SELL or flatten a parent on incomplete proof.
                rec["confirmed_position_open_qty"] = confirmed_open_qty
                rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                changed = True
            elif recovery_candidate:
                previous = dict(rec)
                rec["position_state"] = "UNPROTECTED_MANUAL_RISK"
                rec["confirmed_position_open_qty"] = effective_parent_open_qty
                rec["manual_exit_detected"] = False
                rec["reconciliation_required"] = False
                rec["unreadable_broker_response"] = False
                rec["broker_quantity_unverified"] = False
                rec["broker_quantity_evidence"] = "VERIFIED_SETTLED_HOLDINGS"
                if not self._sync_position_lifecycle(rec):
                    rec.clear()
                    rec.update(previous)
                    rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                    rec["reconciliation_required"] = True
                    rec["persistence_uncertain"] = True
                    if gate is not None and hasattr(gate, "halt_new_entries"):
                        gate.halt_new_entries(f"Manual-risk recovery persistence failed: {oid}")
                else:
                    logger.warning(
                        "[Protection] Manual-risk recovery verified for order=%s; "
                        "independent entry-gate recheck still required", oid
                    )
                    self._recovered_manual_risk_ids = getattr(
                        self, "_recovered_manual_risk_ids", set()
                    ) | {oid}
                changed = True
            elif ambiguous_super_closed and not triggered_leg and sell_qty == 0:
                # P0-C: Parent CLOSED with both legs PENDING, missing, stale, or contradictory ->
                # retain active monitoring, never fabricate TARGET_LEG or Position Closed, and halt new entries.
                amb_msg = (
                    f"Ambiguous Super Order state for {rec['symbol']} ({oid}): parent={parent_st}, "
                    f"target_leg={t_st or 'MISSING'}, sl_leg={sl_st or 'MISSING'}, verified_sell_qty=0."
                )
                logger.warning(f"[Protection] ⚠️ {amb_msg}")
                if gate is not None and hasattr(gate, "halt_new_entries"):
                    gate.halt_new_entries(amb_msg)
                rec["confirmed_position_open_qty"] = confirmed_open_qty
                changed = True
            elif sell_qty >= buy_filled > 0 and (broker_net_qty is None or broker_net_qty == 0 or broker_net_qty <= aggregate_contract_open_qty):
                realized_pnl = round((sell_vwap - buy_vwap) * buy_filled, 2) if (buy_vwap > 0 and sell_vwap > 0) else 0.0
                rec["exit_filled_qty"] = sell_qty
                rec["exit_vwap"] = sell_vwap
                rec["realized_pnl"] = realized_pnl
                rec["confirmed_position_open_qty"] = 0
                rec["reconciliation_required"] = False
                rec["persistence_uncertain"] = False
                rec["last_persistence_error"] = ""
                rec["position_state"] = PositionLifecycleState.POSITION_CLOSED.value
                # Commit position lifecycle to SQLite BEFORE confirming closure or emitting POSITION_CLOSED notification
                if not self._sync_position_lifecycle(rec):
                    rec["reconciliation_required"] = True
                    rec["persistence_uncertain"] = True
                    rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                    if gate is not None and hasattr(gate, "halt_new_entries"):
                        gate.halt_new_entries(f"Failed to persist POSITION_CLOSED lifecycle row for {rec['symbol']} ({oid})")
                else:
                    if self.execution_reporter and hasattr(self.execution_reporter, "process_exit_event"):
                        self.execution_reporter.process_exit_event(
                            rec,
                            "POSITION_CLOSED",
                            observed_at=now_ts,
                            triggered_leg=triggered_leg,
                            sell_qty=sell_qty,
                            buy_vwap=buy_vwap,
                            sell_vwap=sell_vwap,
                            realized_pnl=realized_pnl,
                        )
                changed = True
            elif 0 < sell_qty < buy_filled:
                part_pnl = round((sell_vwap - buy_vwap) * sell_qty, 2) if (buy_vwap > 0 and sell_vwap > 0) else 0.0
                rec["exit_filled_qty"] = sell_qty
                rec["exit_vwap"] = sell_vwap
                rec["realized_pnl"] = part_pnl
                rec["confirmed_position_open_qty"] = confirmed_open_qty
                rec["reconciliation_required"] = False
                rec["persistence_uncertain"] = False
                rec["position_state"] = PositionLifecycleState.EXIT_PART_FILLED.value
                if not self._sync_position_lifecycle(rec):
                    rec["reconciliation_required"] = True
                    rec["persistence_uncertain"] = True
                    rec["position_state"] = PositionLifecycleState.RECONCILIATION_REQUIRED.value
                    if gate is not None and hasattr(gate, "halt_new_entries"):
                        gate.halt_new_entries(f"Failed to persist EXIT_PART_FILLED lifecycle row for {rec['symbol']} ({oid})")
                elif sell_qty != prev_sell_qty and self.execution_reporter and hasattr(self.execution_reporter, "process_exit_event"):
                    self.execution_reporter.process_exit_event(
                        rec,
                        "EXIT_PARTIAL_FILLED",
                        observed_at=now_ts,
                        triggered_leg=triggered_leg,
                        sell_qty=sell_qty,
                        buy_vwap=buy_vwap,
                        sell_vwap=sell_vwap,
                        realized_pnl=part_pnl,
                    )
                changed = True
            elif triggered_leg and sell_qty == 0:
                # P0-03 & P0-C: Verified triggered leg without SELL tradebook fill is EXIT_TRIGGERED, NOT closed!
                rec["position_state"] = PositionLifecycleState.EXIT_TRIGGERED.value
                rec["confirmed_position_open_qty"] = confirmed_open_qty
                if (prev_pos_state != PositionLifecycleState.EXIT_TRIGGERED.value or triggered_leg != prev_trig_leg):
                    ev_key = "SL_TRIGGERED" if "STOP" in triggered_leg.upper() else "TARGET_TRIGGERED"
                    if self.execution_reporter and hasattr(self.execution_reporter, "process_exit_event"):
                        self.execution_reporter.process_exit_event(
                            rec,
                            ev_key,
                            observed_at=now_ts,
                            triggered_leg=triggered_leg,
                            sell_qty=0,
                            buy_vwap=buy_vwap,
                        )
                    changed = True
            elif both_legs_dead and confirmed_open_qty > 0 and (broker_net_qty is None or broker_net_qty > 0):
                rec["position_state"] = PositionLifecycleState.UNPROTECTED.value
                self._record_unprotected_and_halt(
                    rec=rec,
                    new_qty=confirmed_open_qty,
                    sl_trigger=float(rec.get("confirmed_sl_price") or 0.0),
                    sl_limit=float(rec.get("confirmed_sl_price") or 0.0),
                    target_price=float(rec.get("confirmed_target_price") or 0.0),
                    status_label="UNPROTECTED",
                    reason=f"Protective exit legs for {rec['symbol']} ({oid}) became terminal (cancelled/rejected/expired) while {confirmed_open_qty} units remain open",
                )
                changed = True

            if (changed or rec.get("position_state") != prev_pos_state) and rec.get("position_state") not in (
                PositionLifecycleState.POSITION_CLOSED.value,
                PositionLifecycleState.EXIT_PART_FILLED.value,
            ):
                self._sync_position_lifecycle(rec)

        # A changed-state return value is not evidence of a successful read.
        # Only a completed pass with all required books readable consumes the
        # one-shot closed-session allowance.
        self._supervision_read_complete = not unreadable_books and all(
            book is not None for book in (
                super_book, forever_book, trade_book, positions_book, holdings_book
            )
        )
        return changed

    def should_poll(self, is_market_open_fn: Optional[Callable[[], bool]] = None) -> bool:
        if bool(self.pending) or self.has_open_monitored_positions():
            return True
        if is_lifecycle_open():
            return True
        if is_market_open_fn is not None:
            try:
                return bool(is_market_open_fn())
            except Exception:
                return False
        return False

    def request_supervision_check(self):
        """Wake the scheduled watcher after an operator/broker event.

        Local-only notification; it never bypasses the read governor. External
        manual trades cannot be detected without a broker read or an event.
        """
        with self._lock:
            self._supervision_request = getattr(self, "_supervision_request", 0) + 1

    def _poll_snapshot(self):
        with self._lock:
            pending = copy.deepcopy(self.pending)
            terminal = copy.deepcopy(self.terminal_orders)
            request = getattr(self, "_supervision_request", 0)
        records = list(terminal.values()) + [
            r for r in pending.values()
            if isinstance(r, dict) and r.get("entry_only_amo")
        ]
        account = str(getattr(getattr(self.broker, "cfg", None), "dhan_client_id", "") or "")
        for rec in records:
            if not isinstance(rec, dict):
                continue
            rec["_schedule_ack_verified"] = False
            if account and self.journal_db and (
                rec.get("position_state") == "UNPROTECTED_MANUAL_RISK"
                or (rec.get("position_state") == "RECONCILIATION_REQUIRED"
                    and rec.get("manual_risk_acknowledged") is True)
            ):
                try:
                    security = str(rec.get("security_id") or "")
                    rec["_schedule_ack_verified"] = bool(security) and (
                        self.journal_db.is_manual_risk_acknowledged(
                            str(rec.get("order_id") or ""),
                            str(rec.get("correlation_id") or ""),
                            expected_account_id=account,
                            expected_security_id=security,
                            required_qty=max(0, int(rec.get("filled_qty") or 0)
                                             - int(rec.get("exit_filled_qty") or 0)),
                        ) is True
                    )
                except Exception:
                    # Missing/corrupt ack evidence must retain periodic supervision.
                    rec["_schedule_ack_verified"] = False
        keys = (
            "state", "filled_qty", "exit_filled_qty", "position_state", "pending_oco",
            "cancel_uncertain", "cancel_requested", "entry_timeout_elapsed", "retry_reserved",
            "persistence_uncertain", "reconciliation_required", "sl_order_id", "tp_order_id",
            "exit_order_id", "confirmed_protection_ids", "verified_leg_order_ids",
            "verified_leg_map", "orphaned_leg_cancel_states", "_schedule_ack_verified",
        )
        signature = (request, tuple(sorted(
            (str(oid), json.dumps({key: rec.get(key) for key in keys}, sort_keys=True, default=str))
            for oid, rec in list(pending.items()) + list(terminal.items())
            if isinstance(rec, dict)
        )))
        return pending, records, signature

    async def run(self, is_market_open_fn: Optional[Callable[[], bool]] = None):
        """Adapt scheduled checks to open risk and remaining Dhan GET capacity.

        The 2-second heartbeat is local only. A new order/changed local state
        wakes the watcher at the next heartbeat; steady state does NOT run
        five broker GETs every two seconds. Governor deferrals never count
        as broker proof and always keep new LIVE entries fail-closed.
        """
        from src.broker.read_governor import ReadGovernor

        with self._running_lock:
            if self._is_running:
                logger.warning("[Protection] Watcher run() loop already active in this instance; skipping duplicate launch.")
                return
            self._is_running = True

        next_due = 0.0
        last_signature = None
        last_notice = 0.0
        failure_holdoff = 0.0
        try:
            while True:
                if time.monotonic() < failure_holdoff:
                    await asyncio.sleep(POLL_INTERVAL_SEC)
                    continue
                try:
                    if not self.should_poll(is_market_open_fn):
                        next_due = 0.0
                        last_signature = None
                    else:
                        now = time.monotonic()
                        pending, open_records, signature = self._poll_snapshot()
                        lifecycle_now = is_lifecycle_open()
                        signature = (lifecycle_now, signature)
                        # An exchange opening/closing transition wakes a
                        # scheduled pass without waiting for off-hours cadence.
                        if signature != last_signature or now >= next_due:
                            one_shot = not lifecycle_now and manual_risk_only(pending, open_records)
                            cadence = watcher_cadence_seconds(
                                pending=pending,
                                open_records=open_records,
                                now=self.clock(),
                                market_open=lifecycle_now,
                            )
                            governor = getattr(self.broker, "_read_governor", None)
                            if not isinstance(governor, ReadGovernor):
                                governor = None
                            wait = 0.0
                            blocked_reason = None
                            if governor is not None:
                                try:
                                    # Validate the account binding first, without issuing a GET.
                                    check_binding = getattr(self.broker, "_get_active_read_governor", None)
                                    if callable(check_binding):
                                        governor = check_binding()
                                    wait = governor.seconds_until_capacity(
                                        required=supervision_read_requirement(len(pending)),
                                        # Every collection GET inside
                                        # check_once() uses NORMAL admission.
                                        # Requesting urgent PREVIEW here while
                                        # transmitting NORMAL caused 5 locally
                                        # generated HTTP-429 errors per poll.
                                        priority=supervision_preflight_priority(
                                            pending, open_records
                                        ),
                                    )
                                except Exception as exc:
                                    wait = 60.0
                                    blocked_reason = "Local broker read-budget verification unavailable"
                                    if now >= last_notice:
                                        logger.error("[Protection] Broker governor preflight failed: %s", type(exc).__name__)
                            if wait > 0:
                                blocked_reason = blocked_reason or "Broker GET admission deferred; fresh position evidence unavailable"
                                gate = getattr(self.broker, "reconciliation_gate", None)
                                if gate is not None and hasattr(gate, "halt_new_entries"):
                                    state = getattr(gate, "state", None)
                                    state_value = getattr(state, "value", state)
                                    if getattr(gate, "is_accepting_entries", False) or str(state_value).upper() != "BLOCKED":
                                        gate.halt_new_entries(blocked_reason)
                                if now >= last_notice:
                                    logger.warning(
                                        "[Protection] Governor-aware supervision deferred for %.1fs; "
                                        "no broker GET sent; entry gate remains closed", wait,
                                    )
                                    last_notice = now + max(60.0, min(wait, 600.0))
                                next_due = now + max(POLL_INTERVAL_SEC, min(wait, 60.0))
                                last_signature = signature
                            else:
                                self._supervision_read_complete = False
                                await asyncio.to_thread(self.check_once)
                                completed = getattr(self, "_supervision_read_complete", False) is True
                                if one_shot and completed:
                                    next_due = float("inf")
                                    logger.info(
                                        "[Protection] Closed-session manual-risk check completed; "
                                        "next routine check at reopening. External manual trades after "
                                        "this snapshot require operator verification or an explicit recheck."
                                    )
                                else:
                                    next_due = time.monotonic() + (60.0 if one_shot else cadence)
                                # Keep the pre-pass signature: a new order or cancellation
                                # arriving during the worker must not be swallowed by it.
                                last_signature = signature
                except Exception as exc:
                    logger.error("[Protection] Watcher loop error: %s", type(exc).__name__)
                    gate = getattr(self.broker, "reconciliation_gate", None)
                    if gate is not None and getattr(gate, "is_accepting_entries", False):
                        gate.halt_new_entries("Protection watcher scheduling failure; broker status unverified")
                    next_due = time.monotonic() + 60.0
                    failure_holdoff = next_due
                await asyncio.sleep(POLL_INTERVAL_SEC)
        finally:
            with self._running_lock:
                self._is_running = False
