UDITBOT PR #91 CHANGED-FILES ZIP — 18 November 2026
Repo: https://github.com/uditraikhere11-glitch/uditbot
Base main: 11d2c4c3c48264a03e498761b1e5158c8eb6706a
PR #91 HEAD: 1e1d9fcf259058980fb28722b0d38c7e29f56fd2
Files included: 11
This file contains complete replacement files for every PR #91 changed path,
plus this README; NOT a standalone installer, and NO .env, tokens, DB or sessions.
R06/R07/R08/R09 revisions:
- Align GET supervision preflight with admission priority; avoid 10s GET storms.
- Conservative 120s polling for independently DB-acknowledged legacy holdings
  with no active protective order/cancel; 300s after hours.
- Preserve reserved startup funds identity probe under hard governor GET limits.
- Distinguish synthetic local 429 from real broker throttling.
- Verify settled YESBANK holdings exactly and recover only after durable proof.
- New-day CNC positive positions may exist before settled Demat holdings;
  this must NOT establish recovered historical settled shares.
- Entry gate stays CLOSED on any unavailable/contradictory broker evidence.
Offline tests: python -m unittest discover -s tests -p 'test_*.py' -q
Do not copy files over LIVE VM before owner-approved GitHub PR merge and
staging/production acceptance. Never erase or reset the governor or journal.
Files:
1. src/broker/dhan_client.py
2. src/broker/read_governor.py
3. src/engine/holding_quantity.py
4. src/engine/protection_watcher.py
5. src/engine/reconciliation.py
6. src/engine/watch_poll_policy.py
7. tests/test_manual_risk_session_polling.py
8. tests/test_r02_adaptive_watcher.py
9. tests/test_r06_reconciliation_recovery.py
10. tests/test_r07_startup_funds_reserve.py
11. tests/test_v14_protection_notify_final.py
