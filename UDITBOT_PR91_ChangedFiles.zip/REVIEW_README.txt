UDITBOT PR #91 -- EXACT CHANGED FILES REVIEW ZIP
Base main: 11d2c4c3c48264a03e498761b1e5158c8eb6706a
Candidate PR head: c69aad022bf959a2a84a235f9098e395f990a4dc
Created: 2026-11-18
Repository: https://github.com/uditraikhere11-glitch/uditbot/pull/91

This archive contains complete replacement text for all 11 changed source and
test paths at the verified PR head. The existing repository at base main is
required; this archive is NOT a standalone installation.

Purpose: fix reconciliation / Dhan GET budget exhaustion without relaxing
emergency STOP, order protection, or broker evidence verification.

PRODUCTION WARNING: Do not replace running files, reset the read-governor
database, delete SQLite journal state, or activate trading from this ZIP.
A GitHub-approved PR, isolated regression tests, and broker-authoritative
production verification are required before deployment.

Tests:
  python -m unittest -q tests.test_r06_reconciliation_recovery tests.test_r07_startup_funds_reserve
  python -m unittest discover -s tests -p 'test_*.py' -q

File inventory:
1. src/broker/dhan_client.py
2. src/broker/read_governor.py
3. src/engine/holding_quantity.py
4. src/engine/protection_watcher.py
5. src/engine/reconciliation.py
6. src/engine/watch_poll_policy.py
7. tests/test_manual_risk_session_polling.py
8. tests/test_r02_adaptive_watcher.py
9. tests/test_r06_reconciliation_recovery.py
10. tests/test_r07_startup_funds_reserve.py
11. tests/test_v14_protection_notify_final.py

The ZIP contains no runtime database, Dhan token, Telegram session, .env,
password, or VM backup.
