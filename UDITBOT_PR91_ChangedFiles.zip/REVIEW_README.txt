UDITBOT PR91 EXACT CHANGED-FILES REVIEW ZIP
2026-11-18
GitHub PR: https://github.com/uditraikhere11-glitch/uditbot/pull/91
PR head: f0e552ab52deeab7271e1d1a91b8ebbd35fdf617
Base main: 11d2c4c3c48264a03e498761b1e5158c8eb6706a
Files: 11 full replacement files (not fragments).
Changes R06-R10: governor scheduling/priority, durable YESBANK recovery,
correct startup funds reserve, genuine vs local HTTP429, after-hours market
hours bounded polling, Dhan same-day CNC positive positions vs settled Demat
holdings (never infer historical settlement from today's BUY), and bounded
SQLite WAL contention retries. Hard GET limits, broker evidence, emergency
STOP, entry-gate fail closed, order mutation protections preserved.
This is NOT a standalone installer. No VM runtime data, secret or credentials.
DO NOT deploy/merge without owner's approval and staged and LIVE verification.
Files:
1. src/broker/dhan_client.py
2. src/broker/read_governor.py
3. src/engine/holding_quantity.py
4. src/engine/protection_watcher.py
5. src/engine/reconciliation.py
6. src/engine/watch_poll_policy.py
7. tests/test_manual_risk_session_polling.py
8. tests/test_r02_adaptive_watcher.py
9. tests/test_r06_reconciliation_recovery.py
10. tests/test_r07_startup_funds_reserve.py
11. tests/test_v14_protection_notify_final.py
