UDITBOT PR #91 — EXACT COMPLETE CHANGED-FILES ZIP
Reviewed snapshot date: 18 November 2026
Repository: https://github.com/uditraikhere11-glitch/uditbot
PR URL: https://github.com/uditraikhere11-glitch/uditbot/pull/91
PR HEAD: 8dd6b4c3ccd575599e3a7dd4e098afa0b4011e9d
BASE main: 11d2c4c3c48264a03e498761b1e5158c8eb6706a
Offline CI: combined release 1,171 tests passed; AMO suite passed.
Includes 11 complete changed files, plus README. Not a standalone installer.
Includes fixes for GET budget feedback loop, preflight priority, local synthetic
429, funds startup reserve, correct CNC settled/T1 and same-day positions,
evidence-gated YESBANK historical recovery, 120/300s polling, WAL contention
retries under 750ms, and regression tests. Emergency STOP and trading entry
gate remain fail closed on missing broker evidence. Do not delete read-governor
journals, historical trade journals, tokens, broker orders or OCO state.
No secret .env, token, session or live data included.
DO NOT DEPLOY OR MERGE UNTIL OWNER APPROVAL AND PRODUCTION READ-ONLY CHECK.
Files:
1. src/broker/dhan_client.py
2. src/broker/read_governor.py
3. src/engine/holding_quantity.py
4. src/engine/protection_watcher.py
5. src/engine/reconciliation.py
6. src/engine/watch_poll_policy.py
7. tests/test_manual_risk_session_polling.py
8. tests/test_r02_adaptive_watcher.py
9. tests/test_r06_reconciliation_recovery.py
10. tests/test_r07_startup_funds_reserve.py
11. tests/test_v14_protection_notify_final.py
